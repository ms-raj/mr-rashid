export type FuelType = 'Petrol' | 'Diesel' | 'Electric' | 'CNG' | 'Hybrid';

export type TransmissionType = 'Manual' | 'Automatic' | 'e-CVT' | 'Direct Drive';

export type AvailabilityStatus = 'In Stock' | 'Fast Delivery' | 'Booking Open' | 'Out of Stock';

export interface VehicleCategory {
  id: string;
  name: string;
  slug: string;
  shortDescription: string;
  iconName: string;
  heroImage: string;
  order: number;
}

export interface Vehicle {
  id: string;
  name: string;
  slug: string;
  brand: string;
  categoryId: string;
  categoryName: string;
  modelYear: number;
  price: number;
  originalPrice?: number;
  emiStarting: number;
  availability: AvailabilityStatus;
  featured: boolean;
  published: boolean;
  fuelType: FuelType;
  transmission: TransmissionType;
  seatingCapacity: number;
  engineOrMotor: string;
  power: string;
  torque: string;
  mileageOrRange: string;
  batteryCapacity?: string;
  chargingTime?: string;
  topSpeed: string;
  groundClearance?: string;
  dimensions?: string;
  warranty: string;
  description: string;
  features: string[];
  images: string[];
  colorOptions?: { name: string; hex: string }[];
}

export type LeadStatus = 'New' | 'Contacted' | 'Follow-Up' | 'Interested' | 'Converted' | 'Closed';

export type EnquiryType = 'Price Quote' | 'Test Drive' | 'Finance' | 'Exchange' | 'Offer' | 'General';

export interface Lead {
  id: string;
  customerName: string;
  mobile: string;
  email: string;
  vehicleId?: string;
  vehicleName?: string;
  enquiryType: EnquiryType;
  status: LeadStatus;
  message: string;
  createdAt: string;
  notes?: string;
}

export type TestDriveStatus = 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled';

export interface TestDriveRequest {
  id: string;
  customerName: string;
  mobile: string;
  email: string;
  vehicleId: string;
  vehicleName: string;
  preferredDate: string;
  preferredTime: string;
  locationType: 'Showroom' | 'Doorstep';
  address?: string;
  status: TestDriveStatus;
  message?: string;
  createdAt: string;
  notes?: string;
}

export interface VehicleExchangeRequest {
  id: string;
  customerName: string;
  mobile: string;
  currentVehicleMake: string;
  currentVehicleModel: string;
  registrationYear: string;
  condition: 'Fair' | 'Good' | 'Excellent';
  estimatedValue?: number;
  preferredNewVehicleId?: string;
  preferredNewVehicleName?: string;
  createdAt: string;
  status: LeadStatus;
  notes?: string;
}

export type OfferCategory =
  | 'Festival Offers'
  | 'Exchange Offers'
  | 'Finance Offers'
  | 'EV Offers'
  | 'Accessories Offers'
  | 'Limited-Time Offers';

export interface SpecialOffer {
  id: string;
  title: string;
  category: OfferCategory;
  bannerUrl: string;
  badge: string;
  discountText: string;
  description: string;
  validityDate: string;
  published: boolean;
  applicableVehicleIds?: string[];
}

export interface CustomerReview {
  id: string;
  customerName: string;
  photoUrl: string;
  vehiclePurchased: string;
  rating: number;
  reviewText: string;
  date: string;
  approved: boolean;
  featured: boolean;
  isGoogleReview?: boolean;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'Showroom' | 'Vehicles' | 'Delivery' | 'Events' | 'Customer Deliveries' | 'Team';
  imageUrl: string;
  caption?: string;
}

export interface ShowroomSettings {
  name: string;
  tagline: string;
  logoUrl: string;
  phone: string;
  whatsappNumber: string;
  email: string;
  address: string;
  city: string;
  state: string;
  pincode: string;
  googleMapsShareUrl: string;
  googleMapsEmbedUrl: string;
  openingHours: { days: string; time: string }[];
  socialLinks: { platform: string; url: string }[];
  aboutStory: string;
  mission: string;
  editableStats: { label: string; value: string; suffix?: string }[];
}

export interface SeoSettings {
  title: string;
  metaDescription: string;
  keywords: string[];
  ogImageUrl: string;
}
