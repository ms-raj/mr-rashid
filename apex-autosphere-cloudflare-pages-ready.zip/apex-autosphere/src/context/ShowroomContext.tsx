import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Vehicle,
  VehicleCategory,
  SpecialOffer,
  CustomerReview,
  GalleryItem,
  ShowroomSettings,
  SeoSettings,
  Lead,
  LeadStatus,
  EnquiryType,
  TestDriveRequest,
  TestDriveStatus,
} from '../types';
import {
  INITIAL_CATEGORIES,
  INITIAL_VEHICLES,
  INITIAL_OFFERS,
  INITIAL_REVIEWS,
  INITIAL_GALLERY,
  INITIAL_SETTINGS,
  INITIAL_SEO,
  INITIAL_LEADS,
  INITIAL_TEST_DRIVES,
} from '../data/initialData';

interface ShowroomContextType {
  vehicles: Vehicle[];
  categories: VehicleCategory[];
  offers: SpecialOffer[];
  reviews: CustomerReview[];
  gallery: GalleryItem[];
  leads: Lead[];
  testDrives: TestDriveRequest[];
  settings: ShowroomSettings;
  seo: SeoSettings;

  // Navigation & Modals
  activeTab: string;
  setActiveTab: (tab: string, categoryFilter?: string) => void;
  activeCategoryFilter: string;
  setActiveCategoryFilter: (catId: string) => void;

  selectedVehicle: Vehicle | null;
  setSelectedVehicle: (vehicle: Vehicle | null) => void;

  isTestDriveModalOpen: boolean;
  testDriveVehicle: Vehicle | null;
  openTestDriveModal: (vehicle?: Vehicle | null) => void;
  closeTestDriveModal: () => void;

  isEnquiryModalOpen: boolean;
  enquiryVehicle: Vehicle | null;
  enquiryType: EnquiryType;
  openEnquiryModal: (vehicle?: Vehicle | null, type?: EnquiryType) => void;
  closeEnquiryModal: () => void;

  // Admin Auth
  isAdminAuthenticated: boolean;
  loginAdmin: (password: string) => boolean;
  logoutAdmin: () => void;

  // CRUD Leads & Test Drives
  createLead: (data: {
    customerName: string;
    mobile: string;
    email: string;
    vehicleId?: string;
    vehicleName?: string;
    enquiryType: EnquiryType;
    message: string;
  }) => Lead;
  updateLeadStatus: (leadId: string, status: LeadStatus, notes?: string) => void;
  deleteLead: (leadId: string) => void;

  createTestDrive: (data: {
    customerName: string;
    mobile: string;
    email: string;
    vehicleId: string;
    vehicleName: string;
    preferredDate: string;
    preferredTime: string;
    locationType: 'Showroom' | 'Doorstep';
    address?: string;
    message?: string;
  }) => TestDriveRequest;
  updateTestDriveStatus: (requestId: string, status: TestDriveStatus, notes?: string) => void;
  deleteTestDrive: (requestId: string) => void;

  // CRUD Vehicles
  createVehicle: (vehicle: Omit<Vehicle, 'id' | 'slug'>) => Vehicle;
  updateVehicle: (id: string, updates: Partial<Vehicle>) => void;
  deleteVehicle: (id: string) => void;
  duplicateVehicle: (id: string) => void;

  // CRUD Categories
  createCategory: (cat: Omit<VehicleCategory, 'id' | 'slug'>) => void;
  updateCategory: (id: string, updates: Partial<VehicleCategory>) => void;
  deleteCategory: (id: string) => void;

  // CRUD Offers
  createOffer: (offer: Omit<SpecialOffer, 'id'>) => void;
  updateOffer: (id: string, updates: Partial<SpecialOffer>) => void;
  deleteOffer: (id: string) => void;

  // CRUD Reviews
  createReview: (review: Omit<CustomerReview, 'id' | 'date'>) => void;
  updateReview: (id: string, updates: Partial<CustomerReview>) => void;
  deleteReview: (id: string) => void;

  // Showroom & SEO Settings
  updateSettings: (updates: Partial<ShowroomSettings>) => void;
  updateSeo: (updates: Partial<SeoSettings>) => void;

  // Storage and reset
  resetToDemoData: () => void;
  exportDataJson: () => string;
  importDataJson: (json: string) => boolean;
}

const STORAGE_PREFIX = 'apex_autosphere_';

function loadFromStorage<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(STORAGE_PREFIX + key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (e) {
    console.warn(`Failed to parse storage item ${key}`, e);
    return defaultValue;
  }
}

function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
  } catch (e) {
    console.warn(`Failed to save storage item ${key}`, e);
  }
}

const ShowroomContext = createContext<ShowroomContextType | undefined>(undefined);

export const ShowroomProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [vehicles, setVehicles] = useState<Vehicle[]>(() =>
    loadFromStorage('vehicles', INITIAL_VEHICLES)
  );
  const [categories, setCategories] = useState<VehicleCategory[]>(() =>
    loadFromStorage('categories', INITIAL_CATEGORIES)
  );
  const [offers, setOffers] = useState<SpecialOffer[]>(() =>
    loadFromStorage('offers', INITIAL_OFFERS)
  );
  const [reviews, setReviews] = useState<CustomerReview[]>(() =>
    loadFromStorage('reviews', INITIAL_REVIEWS)
  );
  const [gallery, setGallery] = useState<GalleryItem[]>(() =>
    loadFromStorage('gallery', INITIAL_GALLERY)
  );
  const [leads, setLeads] = useState<Lead[]>(() =>
    loadFromStorage('leads', INITIAL_LEADS)
  );
  const [testDrives, setTestDrives] = useState<TestDriveRequest[]>(() =>
    loadFromStorage('test_drives', INITIAL_TEST_DRIVES)
  );
  const [settings, setSettings] = useState<ShowroomSettings>(() =>
    loadFromStorage('settings', INITIAL_SETTINGS)
  );
  const [seo, setSeo] = useState<SeoSettings>(() =>
    loadFromStorage('seo', INITIAL_SEO)
  );

  // UI state
  const [activeTab, setActiveTabState] = useState<string>('home');
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>('all');
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);

  const [isTestDriveModalOpen, setIsTestDriveModalOpen] = useState<boolean>(false);
  const [testDriveVehicle, setTestDriveVehicle] = useState<Vehicle | null>(null);

  const [isEnquiryModalOpen, setIsEnquiryModalOpen] = useState<boolean>(false);
  const [enquiryVehicle, setEnquiryVehicle] = useState<Vehicle | null>(null);
  const [enquiryType, setEnquiryType] = useState<EnquiryType>('General');

  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('apex_admin_auth') === 'true';
  });

  // Sync to local storage whenever state changes
  useEffect(() => saveToStorage('vehicles', vehicles), [vehicles]);
  useEffect(() => saveToStorage('categories', categories), [categories]);
  useEffect(() => saveToStorage('offers', offers), [offers]);
  useEffect(() => saveToStorage('reviews', reviews), [reviews]);
  useEffect(() => saveToStorage('gallery', gallery), [gallery]);
  useEffect(() => saveToStorage('leads', leads), [leads]);
  useEffect(() => saveToStorage('test_drives', testDrives), [testDrives]);
  useEffect(() => saveToStorage('settings', settings), [settings]);
  useEffect(() => saveToStorage('seo', seo), [seo]);

  // Page title sync
  useEffect(() => {
    document.title = seo.title || settings.name;
  }, [seo.title, settings.name]);

  const setActiveTab = (tab: string, categoryFilter?: string) => {
    setActiveTabState(tab);
    if (categoryFilter) {
      setActiveCategoryFilter(categoryFilter);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openTestDriveModal = (vehicle?: Vehicle | null) => {
    setTestDriveVehicle(vehicle || null);
    setIsTestDriveModalOpen(true);
  };

  const closeTestDriveModal = () => {
    setIsTestDriveModalOpen(false);
  };

  const openEnquiryModal = (vehicle?: Vehicle | null, type: EnquiryType = 'Price Quote') => {
    setEnquiryVehicle(vehicle || null);
    setEnquiryType(type);
    setIsEnquiryModalOpen(true);
  };

  const closeEnquiryModal = () => {
    setIsEnquiryModalOpen(false);
  };

  const loginAdmin = (password: string) => {
    // Default demo master password
    if (password === 'admin123' || password === 'apex2026') {
      setIsAdminAuthenticated(true);
      sessionStorage.setItem('apex_admin_auth', 'true');
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    setIsAdminAuthenticated(false);
    sessionStorage.removeItem('apex_admin_auth');
  };

  // Leads
  const createLead = (data: {
    customerName: string;
    mobile: string;
    email: string;
    vehicleId?: string;
    vehicleName?: string;
    enquiryType: EnquiryType;
    message: string;
  }): Lead => {
    const newLead: Lead = {
      id: 'lead-' + Date.now(),
      customerName: data.customerName,
      mobile: data.mobile,
      email: data.email,
      vehicleId: data.vehicleId,
      vehicleName: data.vehicleName,
      enquiryType: data.enquiryType,
      status: 'New',
      message: data.message,
      createdAt: new Date().toISOString(),
      notes: '',
    };
    setLeads(prev => [newLead, ...prev]);
    return newLead;
  };

  const updateLeadStatus = (leadId: string, status: LeadStatus, notes?: string) => {
    setLeads(prev =>
      prev.map(l =>
        l.id === leadId
          ? {
              ...l,
              status,
              notes: notes !== undefined ? notes : l.notes,
            }
          : l
      )
    );
  };

  const deleteLead = (leadId: string) => {
    setLeads(prev => prev.filter(l => l.id !== leadId));
  };

  // Test Drives
  const createTestDrive = (data: {
    customerName: string;
    mobile: string;
    email: string;
    vehicleId: string;
    vehicleName: string;
    preferredDate: string;
    preferredTime: string;
    locationType: 'Showroom' | 'Doorstep';
    address?: string;
    message?: string;
  }): TestDriveRequest => {
    const newReq: TestDriveRequest = {
      id: 'td-' + Date.now(),
      customerName: data.customerName,
      mobile: data.mobile,
      email: data.email,
      vehicleId: data.vehicleId,
      vehicleName: data.vehicleName,
      preferredDate: data.preferredDate,
      preferredTime: data.preferredTime,
      locationType: data.locationType,
      address: data.address,
      message: data.message,
      status: 'Pending',
      createdAt: new Date().toISOString(),
      notes: '',
    };
    setTestDrives(prev => [newReq, ...prev]);

    // Also auto-record a Lead entry for seamless tracking
    createLead({
      customerName: data.customerName,
      mobile: data.mobile,
      email: data.email,
      vehicleId: data.vehicleId,
      vehicleName: data.vehicleName,
      enquiryType: 'Test Drive',
      message: `Test Drive requested for ${data.preferredDate} at ${data.preferredTime} (${data.locationType}). ${data.message || ''}`,
    });

    return newReq;
  };

  const updateTestDriveStatus = (requestId: string, status: TestDriveStatus, notes?: string) => {
    setTestDrives(prev =>
      prev.map(r =>
        r.id === requestId
          ? {
              ...r,
              status,
              notes: notes !== undefined ? notes : r.notes,
            }
          : r
      )
    );
  };

  const deleteTestDrive = (requestId: string) => {
    setTestDrives(prev => prev.filter(r => r.id !== requestId));
  };

  // Vehicles
  const createVehicle = (vehicleData: Omit<Vehicle, 'id' | 'slug'>): Vehicle => {
    const slug = vehicleData.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
    const newVehicle: Vehicle = {
      ...vehicleData,
      id: 'v-' + Date.now(),
      slug: slug || 'vehicle-' + Date.now(),
    };
    setVehicles(prev => [newVehicle, ...prev]);
    return newVehicle;
  };

  const updateVehicle = (id: string, updates: Partial<Vehicle>) => {
    setVehicles(prev =>
      prev.map(v => {
        if (v.id === id) {
          const updated = { ...v, ...updates };
          if (updates.name && updates.name !== v.name) {
            updated.slug = updates.name
              .toLowerCase()
              .replace(/[^a-z0-9]+/g, '-')
              .replace(/(^-|-$)+/g, '');
          }
          return updated;
        }
        return v;
      })
    );
  };

  const deleteVehicle = (id: string) => {
    setVehicles(prev => prev.filter(v => v.id !== id));
  };

  const duplicateVehicle = (id: string) => {
    const source = vehicles.find(v => v.id === id);
    if (!source) return;
    const duplicated: Vehicle = {
      ...source,
      id: 'v-' + Date.now(),
      name: `${source.name} (Copy)`,
      slug: `${source.slug}-copy-${Date.now().toString().slice(-4)}`,
      published: false,
    };
    setVehicles(prev => [duplicated, ...prev]);
  };

  // Categories
  const createCategory = (catData: Omit<VehicleCategory, 'id' | 'slug'>) => {
    const id = catData.name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)+/g, '');
    const newCat: VehicleCategory = {
      ...catData,
      id: id || 'cat-' + Date.now(),
      slug: id || 'cat-' + Date.now(),
    };
    setCategories(prev => [...prev, newCat]);
  };

  const updateCategory = (id: string, updates: Partial<VehicleCategory>) => {
    setCategories(prev => prev.map(c => (c.id === id ? { ...c, ...updates } : c)));
  };

  const deleteCategory = (id: string) => {
    setCategories(prev => prev.filter(c => c.id !== id));
  };

  // Offers
  const createOffer = (offerData: Omit<SpecialOffer, 'id'>) => {
    const newOffer: SpecialOffer = {
      ...offerData,
      id: 'offer-' + Date.now(),
    };
    setOffers(prev => [newOffer, ...prev]);
  };

  const updateOffer = (id: string, updates: Partial<SpecialOffer>) => {
    setOffers(prev => prev.map(o => (o.id === id ? { ...o, ...updates } : o)));
  };

  const deleteOffer = (id: string) => {
    setOffers(prev => prev.filter(o => o.id !== id));
  };

  // Reviews
  const createReview = (reviewData: Omit<CustomerReview, 'id' | 'date'>) => {
    const newRev: CustomerReview = {
      ...reviewData,
      id: 'rev-' + Date.now(),
      date: new Date().toLocaleDateString('en-GB', {
        day: '2-digit',
        month: 'long',
        year: 'numeric',
      }),
    };
    setReviews(prev => [newRev, ...prev]);
  };

  const updateReview = (id: string, updates: Partial<CustomerReview>) => {
    setReviews(prev => prev.map(r => (r.id === id ? { ...r, ...updates } : r)));
  };

  const deleteReview = (id: string) => {
    setReviews(prev => prev.filter(r => r.id !== id));
  };

  // Settings
  const updateSettings = (updates: Partial<ShowroomSettings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  };

  const updateSeo = (updates: Partial<SeoSettings>) => {
    setSeo(prev => ({ ...prev, ...updates }));
  };

  // Storage reset
  const resetToDemoData = () => {
    setVehicles(INITIAL_VEHICLES);
    setCategories(INITIAL_CATEGORIES);
    setOffers(INITIAL_OFFERS);
    setReviews(INITIAL_REVIEWS);
    setGallery(INITIAL_GALLERY);
    setLeads(INITIAL_LEADS);
    setTestDrives(INITIAL_TEST_DRIVES);
    setSettings(INITIAL_SETTINGS);
    setSeo(INITIAL_SEO);

    localStorage.removeItem(STORAGE_PREFIX + 'vehicles');
    localStorage.removeItem(STORAGE_PREFIX + 'categories');
    localStorage.removeItem(STORAGE_PREFIX + 'offers');
    localStorage.removeItem(STORAGE_PREFIX + 'reviews');
    localStorage.removeItem(STORAGE_PREFIX + 'gallery');
    localStorage.removeItem(STORAGE_PREFIX + 'leads');
    localStorage.removeItem(STORAGE_PREFIX + 'test_drives');
    localStorage.removeItem(STORAGE_PREFIX + 'settings');
    localStorage.removeItem(STORAGE_PREFIX + 'seo');
  };

  const exportDataJson = (): string => {
    const payload = {
      vehicles,
      categories,
      offers,
      reviews,
      gallery,
      leads,
      testDrives,
      settings,
      seo,
      exportedAt: new Date().toISOString(),
    };
    return JSON.stringify(payload, null, 2);
  };

  const importDataJson = (jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString);
      if (Array.isArray(data.vehicles)) setVehicles(data.vehicles);
      if (Array.isArray(data.categories)) setCategories(data.categories);
      if (Array.isArray(data.offers)) setOffers(data.offers);
      if (Array.isArray(data.reviews)) setReviews(data.reviews);
      if (Array.isArray(data.gallery)) setGallery(data.gallery);
      if (Array.isArray(data.leads)) setLeads(data.leads);
      if (Array.isArray(data.testDrives)) setTestDrives(data.testDrives);
      if (data.settings) setSettings(data.settings);
      if (data.seo) setSeo(data.seo);
      return true;
    } catch (e) {
      console.error('Failed to import JSON data', e);
      return false;
    }
  };

  return (
    <ShowroomContext.Provider
      value={{
        vehicles,
        categories,
        offers,
        reviews,
        gallery,
        leads,
        testDrives,
        settings,
        seo,
        activeTab,
        setActiveTab,
        activeCategoryFilter,
        setActiveCategoryFilter,
        selectedVehicle,
        setSelectedVehicle,
        isTestDriveModalOpen,
        testDriveVehicle,
        openTestDriveModal,
        closeTestDriveModal,
        isEnquiryModalOpen,
        enquiryVehicle,
        enquiryType,
        openEnquiryModal,
        closeEnquiryModal,
        isAdminAuthenticated,
        loginAdmin,
        logoutAdmin,
        createLead,
        updateLeadStatus,
        deleteLead,
        createTestDrive,
        updateTestDriveStatus,
        deleteTestDrive,
        createVehicle,
        updateVehicle,
        deleteVehicle,
        duplicateVehicle,
        createCategory,
        updateCategory,
        deleteCategory,
        createOffer,
        updateOffer,
        deleteOffer,
        createReview,
        updateReview,
        deleteReview,
        updateSettings,
        updateSeo,
        resetToDemoData,
        exportDataJson,
        importDataJson,
      }}
    >
      {children}
    </ShowroomContext.Provider>
  );
};

export const useShowroom = () => {
  const context = useContext(ShowroomContext);
  if (!context) {
    throw new Error('useShowroom must be used within a ShowroomProvider');
  }
  return context;
};
