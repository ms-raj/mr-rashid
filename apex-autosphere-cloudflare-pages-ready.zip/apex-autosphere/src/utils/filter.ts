import { Vehicle } from '../types';

export interface VehicleFilterOptions {
  categoryId?: string;
  fuelType?: string;
  brand?: string;
  transmission?: string;
  minPrice?: number;
  maxPrice?: number;
  seatingCapacity?: number;
  availability?: string;
  searchQuery?: string;
  sortBy?: 'featured' | 'price-low' | 'price-high' | 'name-asc' | 'model-year';
}

/**
 * Pure function to filter and sort vehicle inventory
 */
export function filterVehicles(
  vehicles: Vehicle[],
  filters: VehicleFilterOptions
): Vehicle[] {
  let result = [...vehicles];

  // 1. Only published vehicles
  result = result.filter(v => v.published);

  // 2. Category filter
  if (filters.categoryId && filters.categoryId !== 'all') {
    result = result.filter(v => v.categoryId === filters.categoryId);
  }

  // 3. Fuel type filter
  if (filters.fuelType && filters.fuelType !== 'all') {
    result = result.filter(
      v => v.fuelType.toLowerCase() === filters.fuelType!.toLowerCase()
    );
  }

  // 4. Brand filter
  if (filters.brand && filters.brand !== 'all') {
    result = result.filter(
      v => v.brand.toLowerCase() === filters.brand!.toLowerCase()
    );
  }

  // 5. Transmission filter
  if (filters.transmission && filters.transmission !== 'all') {
    result = result.filter(
      v => v.transmission.toLowerCase() === filters.transmission!.toLowerCase()
    );
  }

  // 6. Price range
  if (filters.minPrice !== undefined && filters.minPrice > 0) {
    result = result.filter(v => v.price >= filters.minPrice!);
  }
  if (filters.maxPrice !== undefined && filters.maxPrice > 0) {
    result = result.filter(v => v.price <= filters.maxPrice!);
  }

  // 7. Seating capacity
  if (filters.seatingCapacity !== undefined && filters.seatingCapacity > 0) {
    result = result.filter(v => v.seatingCapacity >= filters.seatingCapacity!);
  }

  // 8. Availability status
  if (filters.availability && filters.availability !== 'all') {
    result = result.filter(v => v.availability === filters.availability);
  }

  // 9. Search query (matches name, brand, category, description, features)
  if (filters.searchQuery && filters.searchQuery.trim().length > 0) {
    const q = filters.searchQuery.toLowerCase().trim();
    result = result.filter(
      v =>
        v.name.toLowerCase().includes(q) ||
        v.brand.toLowerCase().includes(q) ||
        v.categoryName.toLowerCase().includes(q) ||
        v.fuelType.toLowerCase().includes(q) ||
        v.description.toLowerCase().includes(q) ||
        v.features.some(f => f.toLowerCase().includes(q))
    );
  }

  // 10. Sorting
  const sort = filters.sortBy || 'featured';
  result.sort((a, b) => {
    switch (sort) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'name-asc':
        return a.name.localeCompare(b.name);
      case 'model-year':
        return b.modelYear - a.modelYear;
      case 'featured':
      default:
        // Featured vehicles first, then by price descending
        if (a.featured !== b.featured) {
          return a.featured ? -1 : 1;
        }
        return b.price - a.price;
    }
  });

  return result;
}

/**
 * Extracts distinct brands from list of vehicles
 */
export function getAvailableBrands(vehicles: Vehicle[]): string[] {
  const brands = new Set<string>();
  vehicles.forEach(v => {
    if (v.brand) brands.add(v.brand);
  });
  return Array.from(brands).sort();
}
