import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateEmi,
  formatCurrency,
  calculateExchangeValuation,
  generateWhatsAppUrl,
  generateVehicleWhatsAppMessage,
} from './calculator';
import { filterVehicles } from './filter';
import { Vehicle } from '../types';

test('calculateEmi computes correct monthly payment for standard loan', () => {
  // Price: 10,00,000, Down payment: 2,00,000 -> Loan: 8,00,000
  // 8.5% interest, 60 months
  const result = calculateEmi(1000000, 200000, 8.5, 60);
  assert.equal(result.loanAmount, 800000);
  assert.ok(result.monthlyEmi > 16000 && result.monthlyEmi < 17000);
  assert.ok(result.totalInterest > 150000);
  assert.equal(result.totalPayable, result.monthlyEmi * 60 + 200000);
});

test('calculateEmi handles zero interest properly without division by zero', () => {
  const result = calculateEmi(600000, 0, 0, 60);
  assert.equal(result.loanAmount, 600000);
  assert.equal(result.monthlyEmi, 10000);
  assert.equal(result.totalInterest, 0);
  assert.equal(result.totalPayable, 600000);
});

test('calculateEmi handles 100% down payment', () => {
  const result = calculateEmi(500000, 500000, 9.0, 36);
  assert.equal(result.loanAmount, 0);
  assert.equal(result.monthlyEmi, 0);
  assert.equal(result.totalInterest, 0);
  assert.equal(result.totalPayable, 500000);
});

test('formatCurrency outputs correctly formatted Indian Rupee strings', () => {
  assert.equal(formatCurrency(250000), '₹2,50,000');
  assert.equal(formatCurrency(1500000), '₹15,00,000');
  assert.equal(formatCurrency(0), '₹0');
});

test('calculateExchangeValuation considers condition and age depreciation', () => {
  const excellentVal = calculateExchangeValuation(500000, 2, 'Excellent');
  const goodVal = calculateExchangeValuation(500000, 2, 'Good');
  const fairVal = calculateExchangeValuation(500000, 2, 'Fair');

  assert.ok(excellentVal > goodVal);
  assert.ok(goodVal > fairVal);
  assert.ok(excellentVal > 300000);
});

test('generateWhatsAppUrl builds valid URL with phone number and text', () => {
  const url = generateWhatsAppUrl('+91 98765 43210', 'Test Message');
  assert.ok(url.startsWith('https://wa.me/919876543210?text=Test%20Message'));
});

test('generateVehicleWhatsAppMessage produces exact required enquiry message', () => {
  const msg = generateVehicleWhatsAppMessage('Apex Volt S1 Pro', 135000);
  assert.ok(
    msg.includes(
      'Hello, I am interested in the Apex Volt S1 Pro. Please share the latest price, specifications, finance options and availability.'
    )
  );
  assert.ok(msg.includes('₹1,35,000'));
});

test('filterVehicles filters by category, fuel, and price correctly', () => {
  const mockVehicles: Vehicle[] = [
    {
      id: 'v1',
      name: 'Apex EV SUV',
      slug: 'apex-ev-suv',
      brand: 'Apex Motors',
      categoryId: 'electric-vehicles',
      categoryName: 'Electric Vehicles',
      modelYear: 2026,
      price: 2800000,
      emiStarting: 45000,
      availability: 'In Stock',
      featured: true,
      published: true,
      fuelType: 'Electric',
      transmission: 'Direct Drive',
      seatingCapacity: 5,
      engineOrMotor: 'Permanent Magnet AC',
      power: '204 PS',
      torque: '310 Nm',
      mileageOrRange: '480 km/charge',
      topSpeed: '165 km/h',
      warranty: '8 Years',
      description: 'Futuristic electric SUV',
      features: ['Fast Charging', 'Sunroof', 'ADAS'],
      images: ['https://example.com/img1.jpg'],
    },
    {
      id: 'v2',
      name: 'Apex Classic 350',
      slug: 'apex-classic-350',
      brand: 'Apex Two-Wheelers',
      categoryId: 'bikes-scooters',
      categoryName: 'Bikes & Scooters',
      modelYear: 2025,
      price: 215000,
      emiStarting: 4200,
      availability: 'In Stock',
      featured: false,
      published: true,
      fuelType: 'Petrol',
      transmission: 'Manual',
      seatingCapacity: 2,
      engineOrMotor: '349cc Single Cylinder',
      power: '20.2 bhp',
      torque: '27 Nm',
      mileageOrRange: '38 km/l',
      topSpeed: '120 km/h',
      warranty: '3 Years',
      description: 'Classic cruiser bike',
      features: ['Dual ABS', 'Alloy Wheels'],
      images: ['https://example.com/img2.jpg'],
    },
    {
      id: 'v3',
      name: 'Draft Truck',
      slug: 'draft-truck',
      brand: 'Apex Commercial',
      categoryId: 'commercial-vehicles',
      categoryName: 'Commercial Vehicles',
      modelYear: 2025,
      price: 900000,
      emiStarting: 18000,
      availability: 'In Stock',
      featured: false,
      published: false, // unpublished
      fuelType: 'Diesel',
      transmission: 'Manual',
      seatingCapacity: 3,
      engineOrMotor: '2.5L Diesel',
      power: '85 hp',
      torque: '220 Nm',
      mileageOrRange: '14 km/l',
      topSpeed: '90 km/h',
      warranty: '3 Years',
      description: 'Draft commercial truck',
      features: ['Power Steering'],
      images: ['https://example.com/img3.jpg'],
    },
  ];

  // Test 1: Only published vehicles returned
  const allPublished = filterVehicles(mockVehicles, {});
  assert.equal(allPublished.length, 2);

  // Test 2: Filter by category
  const evOnly = filterVehicles(mockVehicles, { categoryId: 'electric-vehicles' });
  assert.equal(evOnly.length, 1);
  assert.equal(evOnly[0].id, 'v1');

  // Test 3: Filter by fuel
  const petrolOnly = filterVehicles(mockVehicles, { fuelType: 'Petrol' });
  assert.equal(petrolOnly.length, 1);
  assert.equal(petrolOnly[0].id, 'v2');

  // Test 4: Search query
  const searchResults = filterVehicles(mockVehicles, { searchQuery: 'Sunroof' });
  assert.equal(searchResults.length, 1);
  assert.equal(searchResults[0].id, 'v1');

  // Test 5: Price range
  const priceFiltered = filterVehicles(mockVehicles, { maxPrice: 500000 });
  assert.equal(priceFiltered.length, 1);
  assert.equal(priceFiltered[0].id, 'v2');
});
