/**
 * Pure calculation utilities for EMI, Vehicle Exchange valuation, and WhatsApp message formatting.
 */

export interface EmiCalculationResult {
  loanAmount: number;
  monthlyEmi: number;
  totalInterest: number;
  totalPayable: number;
}

/**
 * Calculates monthly EMI using the standard compounding formula:
 * E = [P * r * (1+r)^n] / [(1+r)^n - 1]
 *
 * @param price Total vehicle on-road or ex-showroom price
 * @param downPayment Upfront payment made by the buyer
 * @param annualInterestRate Annual interest percentage (e.g., 8.5 for 8.5%)
 * @param tenureMonths Loan tenure in months (e.g., 36, 60)
 */
export function calculateEmi(
  price: number,
  downPayment: number,
  annualInterestRate: number,
  tenureMonths: number
): EmiCalculationResult {
  const safePrice = Math.max(0, price);
  const safeDownPayment = Math.min(safePrice, Math.max(0, downPayment));
  const loanAmount = Math.max(0, safePrice - safeDownPayment);

  if (loanAmount === 0 || tenureMonths <= 0) {
    return {
      loanAmount: 0,
      monthlyEmi: 0,
      totalInterest: 0,
      totalPayable: safeDownPayment,
    };
  }

  // Handle 0% special interest rate
  if (annualInterestRate <= 0) {
    const monthly = Math.round(loanAmount / tenureMonths);
    return {
      loanAmount,
      monthlyEmi: monthly,
      totalInterest: 0,
      totalPayable: loanAmount + safeDownPayment,
    };
  }

  const monthlyRate = annualInterestRate / (12 * 100);
  const compoundFactor = Math.pow(1 + monthlyRate, tenureMonths);
  const monthlyEmi = Math.round(
    (loanAmount * monthlyRate * compoundFactor) / (compoundFactor - 1)
  );
  const totalRepayment = monthlyEmi * tenureMonths;
  const totalInterest = Math.max(0, totalRepayment - loanAmount);
  const totalPayable = totalRepayment + safeDownPayment;

  return {
    loanAmount,
    monthlyEmi,
    totalInterest,
    totalPayable,
  };
}

/**
 * Formats an amount into standard Indian Rupee notation (Lakhs/Crores)
 * e.g., 1450000 -> "₹14,50,000"
 */
export function formatCurrency(amount: number): string {
  if (isNaN(amount) || amount === null || amount === undefined) {
    return '₹0';
  }
  const rounded = Math.round(amount);
  return '₹' + rounded.toLocaleString('en-IN');
}

/**
 * Calculates an estimated exchange trade-in valuation for an existing vehicle
 */
export function calculateExchangeValuation(
  originalApproxValue: number,
  vehicleAgeYears: number,
  condition: 'Fair' | 'Good' | 'Excellent'
): number {
  if (originalApproxValue <= 0) return 0;
  
  // Standard automotive annual depreciation model (~12% per year compounding)
  const age = Math.max(0, Math.min(20, vehicleAgeYears));
  const depreciatedBase = originalApproxValue * Math.pow(0.88, age);
  
  // Condition multiplier
  const multipliers: Record<'Fair' | 'Good' | 'Excellent', number> = {
    Excellent: 0.95,
    Good: 0.85,
    Fair: 0.70,
  };
  
  const multiplier = multipliers[condition] || 0.85;
  const estimated = Math.round(depreciatedBase * multiplier / 1000) * 1000;
  return Math.max(15000, estimated);
}

/**
 * Generates the official showroom WhatsApp pre-filled enquiry URL
 */
export function generateWhatsAppUrl(
  whatsappNumber: string,
  message: string
): string {
  // Strip non-numeric characters except +
  const cleanNumber = whatsappNumber.replace(/[^0-9]/g, '');
  const encodedText = encodeURIComponent(message);
  return `https://wa.me/${cleanNumber}?text=${encodedText}`;
}

/**
 * Generates the compliant vehicle enquiry WhatsApp message
 */
export function generateVehicleWhatsAppMessage(
  vehicleName: string,
  price?: number,
  customNote?: string
): string {
  let msg = `Hello, I am interested in the ${vehicleName}. Please share the latest price, specifications, finance options and availability.`;
  if (price && price > 0) {
    msg += ` (Ex-showroom ref: ${formatCurrency(price)})`;
  }
  if (customNote) {
    msg += ` Note: ${customNote}`;
  }
  return msg;
}
