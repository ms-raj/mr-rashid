import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  Car,
  Search,
  Sparkles,
  ShieldCheck,
  CreditCard,
  Headphones,
  ArrowRight,
  Flame,
} from 'lucide-react';

export const Hero: React.FC<{ onSearchSubmit?: (filters: any) => void }> = ({
  onSearchSubmit,
}) => {
  const { categories, setActiveTab, openTestDriveModal } = useShowroom();

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedFuel, setSelectedFuel] = useState<string>('all');
  const [selectedPriceRange, setSelectedPriceRange] = useState<string>('all');

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const filterParams: any = {};
    if (selectedCategory !== 'all') filterParams.categoryId = selectedCategory;
    if (selectedFuel !== 'all') filterParams.fuelType = selectedFuel;

    if (selectedPriceRange === 'under-2l') {
      filterParams.maxPrice = 200000;
    } else if (selectedPriceRange === '2l-10l') {
      filterParams.minPrice = 200000;
      filterParams.maxPrice = 1000000;
    } else if (selectedPriceRange === '10l-25l') {
      filterParams.minPrice = 1000000;
      filterParams.maxPrice = 2500000;
    } else if (selectedPriceRange === 'above-25l') {
      filterParams.minPrice = 2500000;
    }

    if (onSearchSubmit) {
      onSearchSubmit(filterParams);
    } else {
      setActiveTab('vehicles', selectedCategory !== 'all' ? selectedCategory : undefined);
    }
  };

  return (
    <section className="relative overflow-hidden bg-slate-950 text-white min-h-[640px] flex flex-col justify-center border-b border-slate-800">
      {/* Background Cinematic Visual with Vignette & Gradients */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=2000&q=85"
          alt="Luxury automotive showroom display"
          className="w-full h-full object-cover object-center opacity-30 transform scale-105 transition-transform duration-10000"
          loading="eager"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-slate-950/80" />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-950/80 to-transparent" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 w-full">
        <div className="max-w-3xl">
          {/* Top Pill Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold tracking-wide uppercase mb-6 shadow-sm">
            <Flame className="w-3.5 h-3.5 animate-bounce text-amber-400" />
            <span>Authorized Multi-Brand Mobility Dealership</span>
          </div>

          {/* Main Headline */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight mb-6">
            Drive Your Dream.{' '}
            <span className="block text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500">
              Choose Your Vehicle.
            </span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg sm:text-xl text-slate-300 font-normal leading-relaxed mb-8 max-w-2xl">
            Explore Bikes, Cars, E-Rickshaws, Electric Vehicles & Commercial Vehicles Under One
            Roof.
          </p>

          {/* Primary Action Buttons */}
          <div className="flex flex-wrap items-center gap-4 mb-12">
            <button
              onClick={() => setActiveTab('vehicles', 'all')}
              className="px-7 py-3.5 rounded-xl font-bold text-sm sm:text-base text-slate-950 bg-gradient-to-r from-amber-400 via-amber-300 to-amber-500 hover:from-amber-300 hover:to-amber-400 shadow-xl shadow-amber-500/25 transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center gap-2"
            >
              <span>Explore Vehicles</span>
              <ArrowRight className="w-4 h-4 text-slate-950" />
            </button>

            <button
              onClick={() => openTestDriveModal()}
              className="px-7 py-3.5 rounded-xl font-bold text-sm sm:text-base text-white bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-slate-600 shadow-lg transition-all flex items-center gap-2"
            >
              <Car className="w-4 h-4 text-amber-400" />
              <span>Book a Test Drive</span>
            </button>
          </div>

          {/* Trust Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-6 border-t border-slate-800/80">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                <Car className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <span className="block text-xs font-bold text-white">Wide Vehicle Selection</span>
                <span className="block text-[11px] text-slate-400">7 Mobility Hubs</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                <CreditCard className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <span className="block text-xs font-bold text-white">Easy Finance Assistance</span>
                <span className="block text-[11px] text-slate-400">From 6.99% p.a.</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <span className="block text-xs font-bold text-white">Test Drive Available</span>
                <span className="block text-[11px] text-slate-400">Showroom / Doorstep</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
                <ShieldCheck className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <span className="block text-xs font-bold text-white">Trusted Customer Support</span>
                <span className="block text-[11px] text-slate-400">8,500+ Happy Owners</span>
              </div>
            </div>
          </div>
        </div>

        {/* Integrated Vehicle Search/Filter Bar */}
        <div className="mt-12 bg-slate-900/90 backdrop-blur-xl border border-slate-700/80 rounded-2xl p-4 sm:p-6 shadow-2xl">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <Search className="w-4 h-4 text-amber-400" />
              <span>What are you looking for?</span>
            </h2>
            <span className="text-xs text-slate-400 hidden sm:inline">
              Instant multi-vehicle search & on-road pricing
            </span>
          </div>

          <form onSubmit={handleSearch} className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {/* Dropdown 1: Vehicle Type */}
            <div>
              <label
                htmlFor="vehicle-category-select"
                className="block text-xs font-semibold text-slate-300 mb-1"
              >
                Vehicle Type
              </label>
              <select
                id="vehicle-category-select"
                value={selectedCategory}
                onChange={e => setSelectedCategory(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 transition"
              >
                <option value="all">All Vehicle Types</option>
                {categories.map(cat => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Dropdown 2: Fuel Type */}
            <div>
              <label
                htmlFor="fuel-type-select"
                className="block text-xs font-semibold text-slate-300 mb-1"
              >
                Fuel Type
              </label>
              <select
                id="fuel-type-select"
                value={selectedFuel}
                onChange={e => setSelectedFuel(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 transition"
              >
                <option value="all">All Fuel Types</option>
                <option value="Petrol">Petrol</option>
                <option value="Diesel">Diesel</option>
                <option value="Electric">⚡ Electric (EV)</option>
                <option value="CNG">CNG / Bi-Fuel</option>
                <option value="Hybrid">Hybrid</option>
              </select>
            </div>

            {/* Dropdown 3: Price Range */}
            <div>
              <label
                htmlFor="price-range-select"
                className="block text-xs font-semibold text-slate-300 mb-1"
              >
                Price Range
              </label>
              <select
                id="price-range-select"
                value={selectedPriceRange}
                onChange={e => setSelectedPriceRange(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 transition"
              >
                <option value="all">Any Price Range</option>
                <option value="under-2l">Under ₹2,00,000</option>
                <option value="2l-10l">₹2,00,000 - ₹10,00,000</option>
                <option value="10l-25l">₹10,00,000 - ₹25,00,000</option>
                <option value="above-25l">Above ₹25,00,000</option>
              </select>
            </div>

            {/* Button: Search Vehicles */}
            <div className="flex items-end">
              <button
                type="submit"
                className="w-full bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold py-2.5 px-4 rounded-xl text-sm transition shadow-md shadow-amber-400/20 flex items-center justify-center gap-2 active:scale-98"
              >
                <Search className="w-4 h-4 text-slate-950" />
                <span>Search Vehicles</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </section>
  );
};
