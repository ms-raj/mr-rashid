import React from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  ShieldCheck,
  Target,
  Users,
  Building,
  Award,
  Sparkles,
  MapPin,
  Car,
} from 'lucide-react';

export const AboutSection: React.FC = () => {
  const { settings, categories } = useShowroom();

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-16">
          {/* Left Column: Visual Collage */}
          <div className="lg:col-span-5 relative">
            <div className="rounded-3xl overflow-hidden border border-slate-800 shadow-2xl relative">
              <img
                src="https://images.unsplash.com/photo-1556761175-5973dc0f32e7?auto=format&fit=crop&w=1200&q=80"
                alt="Showroom facility and consultants"
                className="w-full h-80 sm:h-96 object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />
            </div>

            {/* Overlaid Floating Badge */}
            <div className="absolute -bottom-6 -right-4 sm:right-6 bg-slate-900 border border-slate-700 rounded-2xl p-4 shadow-2xl max-w-[240px]">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <span className="block text-xs font-bold text-white">Certified Dealership</span>
                  <span className="block text-[11px] text-slate-400">Multi-Brand Mobility</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Story & Mission */}
          <div className="lg:col-span-7 space-y-6">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block">
              About Apex AutoSphere
            </span>

            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              A New Era of Multi-Vehicle Automotive Excellence
            </h2>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              {settings.aboutStory}
            </p>

            <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
                <Target className="w-4 h-4" />
                <span>Our Mission & Core Philosophy</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {settings.mission}
              </p>
            </div>

            <div className="flex items-center gap-3 text-xs text-slate-400 pt-2">
              <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                Flagship Experience Center: {settings.address}, {settings.city}, {settings.state} - {settings.pincode}
              </span>
            </div>
          </div>
        </div>

        {/* Editable Statistics Strip */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl">
          <div className="text-center mb-6">
            <span className="text-xs uppercase font-bold tracking-wider text-slate-400">
              Showroom Milestones & Scale
            </span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {settings.editableStats.map((stat, idx) => (
              <div key={idx} className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80">
                <div className="text-3xl sm:text-4xl font-black text-amber-400 mb-1">
                  {stat.value}
                  <span className="text-xl font-bold text-slate-300 ml-0.5">{stat.suffix}</span>
                </div>
                <div className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          <p className="text-center text-[11px] text-slate-500 mt-6">
            * Milestone metrics are managed and verified through the showroom administration panel.
          </p>
        </div>
      </div>
    </section>
  );
};
