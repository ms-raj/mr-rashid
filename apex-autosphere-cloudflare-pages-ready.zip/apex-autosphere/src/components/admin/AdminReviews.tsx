import React, { useState } from 'react';
import { useShowroom } from '../../context/ShowroomContext';
import { CustomerReview } from '../../types';
import {
  Star,
  Plus,
  Trash2,
  CheckCircle,
  Eye,
  EyeOff,
  Edit2,
  X,
  MessageSquare,
} from 'lucide-react';

export const AdminReviews: React.FC = () => {
  const { reviews, createReview, updateReview, deleteReview } = useShowroom();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingReview, setEditingReview] = useState<CustomerReview | null>(null);

  const [customerName, setCustomerName] = useState('');
  const [vehiclePurchased, setVehiclePurchased] = useState('');
  const [rating, setRating] = useState(5);
  const [reviewText, setReviewText] = useState('');
  const [photoUrl, setPhotoUrl] = useState(
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80'
  );
  const [approved, setApproved] = useState(true);
  const [featured, setFeatured] = useState(false);

  const openAdd = () => {
    setEditingReview(null);
    setCustomerName('');
    setVehiclePurchased('');
    setRating(5);
    setReviewText('');
    setApproved(true);
    setFeatured(false);
    setIsAddModalOpen(true);
  };

  const openEdit = (rev: CustomerReview) => {
    setEditingReview(rev);
    setCustomerName(rev.customerName);
    setVehiclePurchased(rev.vehiclePurchased);
    setRating(rev.rating);
    setReviewText(rev.reviewText);
    setPhotoUrl(rev.photoUrl);
    setApproved(rev.approved);
    setFeatured(rev.featured);
    setIsAddModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !reviewText.trim()) return;

    if (editingReview) {
      updateReview(editingReview.id, {
        customerName,
        vehiclePurchased,
        rating,
        reviewText,
        photoUrl,
        approved,
        featured,
      });
    } else {
      createReview({
        customerName,
        vehiclePurchased,
        rating,
        reviewText,
        photoUrl,
        approved,
        featured,
      });
    }

    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white">Customer Reviews Moderation</h2>
          <p className="text-xs text-slate-400">
            Approve, edit, feature, or remove customer feedback and Google reviews.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition flex items-center justify-center gap-1.5 shadow"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>Add Customer Review</span>
        </button>
      </div>

      {/* Reviews List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {reviews.map(rev => (
          <div
            key={rev.id}
            className="p-5 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between shadow-xl"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-1 text-amber-400">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      className={`w-3.5 h-3.5 ${
                        i < rev.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-700'
                      }`}
                    />
                  ))}
                </div>

                <div className="flex items-center gap-1.5">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      rev.approved
                        ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                        : 'bg-rose-950/80 text-rose-300 border border-rose-500/30'
                    }`}
                  >
                    {rev.approved ? 'Approved' : 'Pending Review'}
                  </span>
                  {rev.featured && (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                      Featured
                    </span>
                  )}
                </div>
              </div>

              <p className="text-xs text-slate-300 italic mb-4 line-clamp-3">
                "{rev.reviewText}"
              </p>
            </div>

            <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <img
                  src={rev.photoUrl}
                  alt={rev.customerName}
                  className="w-8 h-8 rounded-full object-cover border border-slate-700"
                />
                <div>
                  <span className="block text-xs font-bold text-white">{rev.customerName}</span>
                  <span className="block text-[10px] text-amber-400">{rev.vehiclePurchased}</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => updateReview(rev.id, { approved: !rev.approved })}
                  className={`p-1.5 rounded-lg border transition ${
                    rev.approved
                      ? 'text-emerald-400 border-emerald-500/30 hover:bg-emerald-950/30'
                      : 'text-slate-500 border-slate-800 hover:text-emerald-400'
                  }`}
                  title={rev.approved ? 'Unapprove' : 'Approve'}
                >
                  {rev.approved ? <CheckCircle className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>

                <button
                  onClick={() => updateReview(rev.id, { featured: !rev.featured })}
                  className={`p-1.5 rounded-lg border transition ${
                    rev.featured
                      ? 'text-amber-400 border-amber-500/30 bg-amber-500/10'
                      : 'text-slate-500 border-slate-800 hover:text-amber-400'
                  }`}
                  title="Toggle Featured"
                >
                  <Star className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => openEdit(rev)}
                  className="p-1.5 rounded-lg border border-slate-800 text-amber-400 hover:bg-amber-400/10 transition"
                  title="Edit Review"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    if (window.confirm(`Delete review from ${rev.customerName}?`)) {
                      deleteReview(rev.id);
                    }
                  }}
                  className="p-1.5 rounded-lg border border-slate-800 text-rose-400 hover:bg-rose-950/40 transition"
                  title="Delete Review"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Review Modal */}
      {isAddModalOpen && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl my-6">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-950 text-slate-400 hover:text-white flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-xl font-black text-white mb-4">
              {editingReview ? 'Edit Review' : 'Add Verified Customer Review'}
            </h3>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Customer Name *
                </label>
                <input
                  type="text"
                  required
                  value={customerName}
                  onChange={e => setCustomerName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Vehicle Purchased / Tested
                </label>
                <input
                  type="text"
                  value={vehiclePurchased}
                  onChange={e => setVehiclePurchased(e.target.value)}
                  placeholder="e.g. Apex Grandeur Sedan"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Rating</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map(st => (
                    <button
                      key={st}
                      type="button"
                      onClick={() => setRating(st)}
                      className="p-1 focus:outline-none"
                    >
                      <Star
                        className={`w-6 h-6 ${
                          st <= rating ? 'fill-amber-400 text-amber-400' : 'text-slate-700'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs text-slate-400 ml-2">{rating} Stars</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Review Text *
                </label>
                <textarea
                  rows={3}
                  required
                  value={reviewText}
                  onChange={e => setReviewText(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 resize-none"
                />
              </div>

              <div className="flex items-center gap-6">
                <label className="flex items-center gap-2 text-xs font-bold text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={approved}
                    onChange={e => setApproved(e.target.checked)}
                    className="w-4 h-4 accent-amber-400 rounded"
                  />
                  <span>Approved for Public Display</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-bold text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={featured}
                    onChange={e => setFeatured(e.target.checked)}
                    className="w-4 h-4 accent-amber-400 rounded"
                  />
                  <span>Feature on Top Carousel</span>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-800 flex gap-2">
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition"
                >
                  {editingReview ? 'Update Review' : 'Save Review'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="w-28 py-2.5 rounded-xl text-xs font-bold text-slate-400 bg-slate-950 hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
