import React, { useState } from 'react';
import { useShowroom } from '../../context/ShowroomContext';
import { AdminOverview } from './AdminOverview';
import { AdminVehicles } from './AdminVehicles';
import { AdminCategories } from './AdminCategories';
import { AdminLeads } from './AdminLeads';
import { AdminTestDrives } from './AdminTestDrives';
import { AdminOffers } from './AdminOffers';
import { AdminReviews } from './AdminReviews';
import { AdminSettings } from './AdminSettings';
import { AdminSeo } from './AdminSeo';
import {
  Car,
  Layers,
  Users,
  Calendar,
  Tag,
  Star,
  Settings,
  Globe,
  LayoutDashboard,
  LogOut,
  ArrowLeft,
  Lock,
  KeyRound,
  ShieldCheck,
} from 'lucide-react';

export const AdminPortal: React.FC = () => {
  const {
    isAdminAuthenticated,
    loginAdmin,
    logoutAdmin,
    setActiveTab,
    settings,
    leads,
    testDrives,
  } = useShowroom();

  const [currentAdminTab, setCurrentAdminTab] = useState<string>('overview');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const success = loginAdmin(passwordInput.trim());
    if (!success) {
      setLoginError(true);
    } else {
      setLoginError(false);
      setPasswordInput('');
    }
  };

  const newLeadsCount = leads.filter(l => l.status === 'New').length;
  const pendingTestDrivesCount = testDrives.filter(t => t.status === 'Pending').length;

  if (!isAdminAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col justify-center items-center p-4">
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl text-center">
          <div className="w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-400 flex items-center justify-center mx-auto mb-4">
            <Lock className="w-7 h-7" />
          </div>

          <h1 className="text-2xl font-black text-white mb-1">
            Showroom Admin Portal
          </h1>
          <p className="text-xs text-slate-400 mb-6">
            Enter administrative passcode to manage inventory, customer leads, and showroom settings.
          </p>

          <form onSubmit={handleLogin} className="space-y-4 text-left">
            <div>
              <label htmlFor="admin-passcode-input" className="block text-xs font-semibold text-slate-300 mb-1">
                Admin Passcode
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="admin-passcode-input"
                  type="password"
                  value={passwordInput}
                  onChange={e => {
                    setPasswordInput(e.target.value);
                    setLoginError(false);
                  }}
                  placeholder="Enter passcode (Demo: admin123)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                />
              </div>
            </div>

            {loginError && (
              <p className="text-xs text-rose-400">
                Invalid passcode. Use demo passcode: <strong>admin123</strong>
              </p>
            )}

            <button
              type="submit"
              className="w-full py-3 rounded-xl font-bold text-sm text-slate-950 bg-amber-400 hover:bg-amber-300 transition shadow-lg shadow-amber-400/20"
            >
              Unlock Dashboard
            </button>
          </form>

          {/* Quick Demo Credentials Helper */}
          <div className="mt-6 pt-4 border-t border-slate-800 text-left">
            <div className="text-[11px] text-slate-400 mb-2 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>Demo Security Credentials:</span>
            </div>
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300">
              <span>Passcode: <code className="text-amber-400 font-mono font-bold">admin123</code></span>
              <button
                type="button"
                onClick={() => {
                  setPasswordInput('admin123');
                  loginAdmin('admin123');
                }}
                className="text-amber-400 hover:underline font-bold text-xs"
              >
                Auto-Login
              </button>
            </div>
          </div>

          <div className="mt-4">
            <button
              onClick={() => setActiveTab('home')}
              className="text-xs text-slate-500 hover:text-slate-300 transition flex items-center justify-center gap-1 mx-auto"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Return to Public Showroom</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: 'Dashboard Overview', icon: <LayoutDashboard className="w-4 h-4" /> },
    { id: 'vehicles', label: 'Vehicles Inventory', icon: <Car className="w-4 h-4" /> },
    { id: 'categories', label: 'Vehicle Segments', icon: <Layers className="w-4 h-4" /> },
    {
      id: 'leads',
      label: 'Customer Leads',
      icon: <Users className="w-4 h-4" />,
      badge: newLeadsCount > 0 ? newLeadsCount : undefined,
    },
    {
      id: 'test-drives',
      label: 'Test Drive Bookings',
      icon: <Calendar className="w-4 h-4" />,
      badge: pendingTestDrivesCount > 0 ? pendingTestDrivesCount : undefined,
    },
    { id: 'offers', label: 'Offers & Deals', icon: <Tag className="w-4 h-4" /> },
    { id: 'reviews', label: 'Customer Reviews', icon: <Star className="w-4 h-4" /> },
    { id: 'settings', label: 'Showroom Settings', icon: <Settings className="w-4 h-4" /> },
    { id: 'seo', label: 'SEO Settings', icon: <Globe className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col">
      {/* Top Admin Bar */}
      <header className="bg-slate-900 border-b border-slate-800 px-4 sm:px-6 py-3 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setActiveTab('home')}
              className="p-2 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 hover:text-white transition flex items-center gap-1.5 text-xs font-bold border border-slate-800"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Back to Showroom</span>
            </button>
            <div className="h-5 w-px bg-slate-800" />
            <h1 className="text-sm sm:text-base font-extrabold text-white flex items-center gap-2">
              <span className="text-amber-400">{settings.name}</span>
              <span className="text-slate-500 font-normal hidden sm:inline">/ Admin Portal</span>
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <span className="hidden md:inline text-xs text-emerald-400 font-semibold bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-full">
              ● Live Admin Mode
            </span>
            <button
              onClick={logoutAdmin}
              className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-rose-950/50 text-slate-300 hover:text-rose-300 border border-slate-800 hover:border-rose-800/60 text-xs font-bold transition flex items-center gap-1.5"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Log Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Admin Body */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full flex-1">
        {/* Navigation Tabs Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none border-b border-slate-800/80">
          {tabs.map(tab => {
            const isActive = currentAdminTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setCurrentAdminTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition relative ${
                  isActive
                    ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {tab.icon}
                <span>{tab.label}</span>
                {tab.badge && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                      isActive ? 'bg-slate-950 text-amber-400' : 'bg-amber-400 text-slate-950'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Tab Content Display */}
        <main>
          {currentAdminTab === 'overview' && (
            <AdminOverview onNavigateTab={tab => setCurrentAdminTab(tab)} />
          )}
          {currentAdminTab === 'vehicles' && <AdminVehicles />}
          {currentAdminTab === 'categories' && <AdminCategories />}
          {currentAdminTab === 'leads' && <AdminLeads />}
          {currentAdminTab === 'test-drives' && <AdminTestDrives />}
          {currentAdminTab === 'offers' && <AdminOffers />}
          {currentAdminTab === 'reviews' && <AdminReviews />}
          {currentAdminTab === 'settings' && <AdminSettings />}
          {currentAdminTab === 'seo' && <AdminSeo />}
        </main>
      </div>
    </div>
  );
};
