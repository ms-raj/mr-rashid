import React, { useState } from 'react';
import { useShowroom } from '../../context/ShowroomContext';
import { Lead, LeadStatus, EnquiryType } from '../../types';
import { generateWhatsAppUrl } from '../../utils/calculator';
import {
  Users,
  Search,
  Phone,
  MessageSquare,
  Trash2,
  Edit3,
  Calendar,
  CheckCircle2,
  Clock,
  Filter,
} from 'lucide-react';

export const AdminLeads: React.FC = () => {
  const { leads, updateLeadStatus, deleteLead, settings } = useShowroom();

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [editingNotesLeadId, setEditingNotesLeadId] = useState<string | null>(null);
  const [activeNotesText, setActiveNotesText] = useState<string>('');

  const statuses: LeadStatus[] = [
    'New',
    'Contacted',
    'Follow-Up',
    'Interested',
    'Converted',
    'Closed',
  ];

  const filteredLeads = leads.filter(l => {
    const matchesSearch =
      l.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      l.mobile.includes(searchQuery) ||
      (l.vehicleName && l.vehicleName.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesStatus = statusFilter === 'all' || l.status === statusFilter;
    const matchesType = typeFilter === 'all' || l.enquiryType === typeFilter;
    return matchesSearch && matchesStatus && matchesType;
  });

  const getStatusBadge = (status: LeadStatus) => {
    switch (status) {
      case 'New':
        return 'bg-amber-950/80 text-amber-300 border-amber-500/30';
      case 'Contacted':
        return 'bg-blue-950/80 text-blue-300 border-blue-500/30';
      case 'Follow-Up':
        return 'bg-purple-950/80 text-purple-300 border-purple-500/30';
      case 'Interested':
        return 'bg-cyan-950/80 text-cyan-300 border-cyan-500/30';
      case 'Converted':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30';
      case 'Closed':
      default:
        return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  const handleStartEditNotes = (lead: Lead) => {
    setEditingNotesLeadId(lead.id);
    setActiveNotesText(lead.notes || '');
  };

  const handleSaveNotes = (leadId: string) => {
    const lead = leads.find(l => l.id === leadId);
    if (lead) {
      updateLeadStatus(leadId, lead.status, activeNotesText);
    }
    setEditingNotesLeadId(null);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white">Lead & Customer Enquiry Pipeline</h2>
          <p className="text-xs text-slate-400">
            Track customer requests, follow-ups, internal notes, and conversion statuses.
          </p>
        </div>

        <div className="text-xs font-semibold text-slate-400">
          Total Leads: <strong className="text-white">{leads.length}</strong>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search customer, phone, or vehicle..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option value="all">All Statuses ({leads.length})</option>
            {statuses.map(st => (
              <option key={st} value={st}>
                {st} ({leads.filter(l => l.status === st).length})
              </option>
            ))}
          </select>
        </div>

        <div>
          <select
            value={typeFilter}
            onChange={e => setTypeFilter(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option value="all">All Enquiry Types</option>
            <option value="Price Quote">Price Quote</option>
            <option value="Test Drive">Test Drive</option>
            <option value="Finance">Finance</option>
            <option value="Exchange">Exchange</option>
            <option value="Offer">Special Offer</option>
            <option value="General">General Enquiry</option>
          </select>
        </div>
      </div>

      {/* Leads Table */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-3">Vehicle Interested</th>
                <th className="py-3 px-3">Type</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4">Notes & Message</th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredLeads.map(lead => (
                <tr key={lead.id} className="hover:bg-slate-950/40 transition">
                  {/* Customer Contact */}
                  <td className="py-3 px-4">
                    <div className="font-bold text-white text-sm">{lead.customerName}</div>
                    <div className="font-mono text-slate-400 text-xs mt-0.5">{lead.mobile}</div>
                    {lead.email && (
                      <div className="text-[11px] text-slate-500">{lead.email}</div>
                    )}
                  </td>

                  {/* Vehicle */}
                  <td className="py-3 px-3">
                    <span className="font-semibold text-white block">
                      {lead.vehicleName || 'General Enquiry'}
                    </span>
                  </td>

                  {/* Type */}
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded bg-slate-950 text-amber-400 border border-slate-800 text-[10px] font-semibold">
                      {lead.enquiryType}
                    </span>
                  </td>

                  {/* Status Dropdown */}
                  <td className="py-3 px-3">
                    <select
                      value={lead.status}
                      onChange={e => updateLeadStatus(lead.id, e.target.value as LeadStatus)}
                      className={`px-2 py-1 rounded text-[11px] font-bold border focus:outline-none cursor-pointer ${getStatusBadge(
                        lead.status
                      )}`}
                    >
                      {statuses.map(st => (
                        <option key={st} value={st} className="bg-slate-900 text-white">
                          {st}
                        </option>
                      ))}
                    </select>
                  </td>

                  {/* Notes / Message */}
                  <td className="py-3 px-4 max-w-xs">
                    <p className="text-slate-300 line-clamp-2 italic mb-1.5">
                      "{lead.message}"
                    </p>

                    {editingNotesLeadId === lead.id ? (
                      <div className="flex items-center gap-1.5 mt-1">
                        <input
                          type="text"
                          value={activeNotesText}
                          onChange={e => setActiveNotesText(e.target.value)}
                          placeholder="Add team note..."
                          className="w-full bg-slate-950 border border-amber-400 rounded-lg px-2 py-1 text-xs text-white"
                        />
                        <button
                          onClick={() => handleSaveNotes(lead.id)}
                          className="px-2 py-1 rounded-lg bg-amber-400 text-slate-950 font-bold text-[10px]"
                        >
                          Save
                        </button>
                      </div>
                    ) : (
                      <div
                        onClick={() => handleStartEditNotes(lead)}
                        className="text-[11px] text-slate-400 bg-slate-950/80 p-1.5 rounded-lg border border-slate-800 cursor-pointer hover:border-slate-700 flex items-center justify-between"
                      >
                        <span className="truncate">
                          {lead.notes || 'Click to add internal note...'}
                        </span>
                        <Edit3 className="w-3 h-3 text-slate-500 shrink-0 ml-1" />
                      </div>
                    )}
                  </td>

                  {/* Date */}
                  <td className="py-3 px-3 text-slate-400 text-[11px] whitespace-nowrap">
                    {new Date(lead.createdAt).toLocaleDateString('en-IN', {
                      day: '2-digit',
                      month: 'short',
                      year: 'numeric',
                    })}
                  </td>

                  {/* Quick Contact CTAs */}
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <a
                        href={`tel:${lead.mobile}`}
                        className="p-1.5 rounded-lg border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition"
                        title="Call Customer"
                      >
                        <Phone className="w-3.5 h-3.5 text-amber-400" />
                      </a>

                      <a
                        href={generateWhatsAppUrl(
                          lead.mobile,
                          `Hello ${lead.customerName}, thank you for contacting ${settings.name} regarding the ${lead.vehicleName || 'vehicle'}. How can we assist you today?`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg border border-emerald-800/60 text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900 transition"
                        title="Reply on WhatsApp"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      </a>

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete lead from ${lead.customerName}?`)) {
                            deleteLead(lead.id);
                          }
                        }}
                        className="p-1.5 rounded-lg border border-slate-800 text-rose-400 hover:bg-rose-950/40 transition"
                        title="Delete Lead"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
