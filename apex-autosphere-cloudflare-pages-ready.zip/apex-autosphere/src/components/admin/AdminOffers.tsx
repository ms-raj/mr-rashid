import React, { useState } from 'react';
import { useShowroom } from '../../context/ShowroomContext';
import { SpecialOffer, OfferCategory } from '../../types';
import {
  Tag,
  Plus,
  Trash2,
  Eye,
  EyeOff,
  Edit2,
  X,
  Sparkles,
  Calendar,
} from 'lucide-react';

export const AdminOffers: React.FC = () => {
  const { offers, createOffer, updateOffer, deleteOffer, vehicles } = useShowroom();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingOffer, setEditingOffer] = useState<SpecialOffer | null>(null);

  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<OfferCategory>('Festival Offers');
  const [bannerUrl, setBannerUrl] = useState(
    'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80'
  );
  const [badge, setBadge] = useState('Save up to ₹50,000');
  const [discountText, setDiscountText] = useState('Festive Cash Discount + Corporate Benefit');
  const [description, setDescription] = useState('');
  const [validityDate, setValidityDate] = useState('Valid till end of month');
  const [published, setPublished] = useState(true);

  const openAdd = () => {
    setEditingOffer(null);
    setTitle('');
    setCategory('Festival Offers');
    setBannerUrl(
      'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?auto=format&fit=crop&w=1200&q=80'
    );
    setBadge('Special Deal');
    setDiscountText('Instant Cash Savings');
    setDescription('');
    setValidityDate('Valid till stocks last');
    setPublished(true);
    setIsAddModalOpen(true);
  };

  const openEdit = (offer: SpecialOffer) => {
    setEditingOffer(offer);
    setTitle(offer.title);
    setCategory(offer.category);
    setBannerUrl(offer.bannerUrl);
    setBadge(offer.badge);
    setDiscountText(offer.discountText);
    setDescription(offer.description);
    setValidityDate(offer.validityDate);
    setPublished(offer.published);
    setIsAddModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    if (editingOffer) {
      updateOffer(editingOffer.id, {
        title,
        category,
        bannerUrl,
        badge,
        discountText,
        description,
        validityDate,
        published,
      });
    } else {
      createOffer({
        title,
        category,
        bannerUrl,
        badge,
        discountText,
        description,
        validityDate,
        published,
      });
    }

    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white">Promotions & Offers Management</h2>
          <p className="text-xs text-slate-400">
            Publish seasonal campaigns, exchange bonuses, EV subsidies, and finance packages.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition flex items-center justify-center gap-1.5 shadow"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>Create New Offer</span>
        </button>
      </div>

      {/* Offers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {offers.map(offer => (
          <div
            key={offer.id}
            className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden flex flex-col justify-between shadow-xl"
          >
            <div>
              <div className="relative h-44 overflow-hidden bg-slate-950">
                <img
                  src={offer.bannerUrl}
                  alt={offer.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-amber-400 text-slate-950">
                    {offer.badge}
                  </span>
                </div>
                <div className="absolute top-3 right-3 flex items-center gap-1.5">
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-950/80 text-slate-300 border border-slate-800">
                    {offer.category}
                  </span>
                </div>
              </div>

              <div className="p-5">
                <h3 className="text-lg font-bold text-white mb-1">{offer.title}</h3>
                <span className="text-xs font-bold text-emerald-400 block mb-2">
                  {offer.discountText}
                </span>
                <p className="text-xs text-slate-400 line-clamp-2 mb-3">
                  {offer.description}
                </p>
                <div className="text-[11px] text-slate-500 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5" />
                  <span>{offer.validityDate}</span>
                </div>
              </div>
            </div>

            <div className="p-5 pt-0 border-t border-slate-800/80 flex items-center justify-between">
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                  offer.published
                    ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-500/20'
                    : 'bg-slate-950 text-slate-500 border border-slate-800'
                }`}
              >
                {offer.published ? 'Live on Store' : 'Unpublished (Draft)'}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => updateOffer(offer.id, { published: !offer.published })}
                  className="p-1.5 rounded-lg border border-slate-800 text-slate-400 hover:text-white transition"
                  title="Toggle publication"
                >
                  {offer.published ? <Eye className="w-3.5 h-3.5 text-emerald-400" /> : <EyeOff className="w-3.5 h-3.5" />}
                </button>

                <button
                  onClick={() => openEdit(offer)}
                  className="p-1.5 rounded-lg border border-slate-800 text-amber-400 hover:bg-amber-400/10 transition"
                  title="Edit Offer"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    if (window.confirm(`Delete offer: ${offer.title}?`)) {
                      deleteOffer(offer.id);
                    }
                  }}
                  className="p-1.5 rounded-lg border border-slate-800 text-rose-400 hover:bg-rose-950/40 transition"
                  title="Delete Offer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Offer Modal */}
      {isAddModalOpen && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl my-6">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-950 text-slate-400 hover:text-white flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-xl font-black text-white mb-4">
              {editingOffer ? 'Edit Promotion Offer' : 'Create Special Deal'}
            </h3>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Offer Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="e.g. Diwali Mega Cashback"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={e => setCategory(e.target.value as OfferCategory)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="Festival Offers">Festival Offers</option>
                    <option value="Exchange Offers">Exchange Offers</option>
                    <option value="Finance Offers">Finance Offers</option>
                    <option value="EV Offers">EV Offers</option>
                    <option value="Accessories Offers">Accessories Offers</option>
                    <option value="Limited-Time Offers">Limited-Time Offers</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Badge Callout
                  </label>
                  <input
                    type="text"
                    value={badge}
                    onChange={e => setBadge(e.target.value)}
                    placeholder="e.g. Save ₹50,000"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Discount Highlight Text
                </label>
                <input
                  type="text"
                  value={discountText}
                  onChange={e => setDiscountText(e.target.value)}
                  placeholder="e.g. Instant Cash Discount + Free Accessories"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Banner Image URL
                </label>
                <input
                  type="url"
                  value={bannerUrl}
                  onChange={e => setBannerUrl(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Validity Text
                </label>
                <input
                  type="text"
                  value={validityDate}
                  onChange={e => setValidityDate(e.target.value)}
                  placeholder="e.g. Valid till 30th November 2026"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Offer Description
                </label>
                <textarea
                  rows={2}
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Details of what's included..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 resize-none"
                />
              </div>

              <div className="flex items-center gap-3">
                <label className="flex items-center gap-2 text-xs font-bold text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={published}
                    onChange={e => setPublished(e.target.checked)}
                    className="w-4 h-4 accent-amber-400 rounded"
                  />
                  <span>Publish Offer on Website</span>
                </label>
              </div>

              <div className="pt-3 border-t border-slate-800 flex gap-2">
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition"
                >
                  {editingOffer ? 'Update Offer' : 'Save Offer'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="w-28 py-2.5 rounded-xl text-xs font-bold text-slate-400 bg-slate-950 hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
