import React, { useState } from 'react';
import { useShowroom } from '../../context/ShowroomContext';
import { VehicleCategory } from '../../types';
import {
  Layers,
  Plus,
  Trash2,
  Edit2,
  X,
  ArrowUp,
  ArrowDown,
  Car,
} from 'lucide-react';

export const AdminCategories: React.FC = () => {
  const { categories, createCategory, updateCategory, deleteCategory, vehicles } = useShowroom();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingCat, setEditingCat] = useState<VehicleCategory | null>(null);

  const [name, setName] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [iconName, setIconName] = useState('Car');
  const [heroImage, setHeroImage] = useState(
    'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80'
  );

  const openAdd = () => {
    setEditingCat(null);
    setName('');
    setShortDescription('');
    setIconName('Car');
    setHeroImage(
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80'
    );
    setIsAddModalOpen(true);
  };

  const openEdit = (cat: VehicleCategory) => {
    setEditingCat(cat);
    setName(cat.name);
    setShortDescription(cat.shortDescription);
    setIconName(cat.iconName);
    setHeroImage(cat.heroImage);
    setIsAddModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (editingCat) {
      updateCategory(editingCat.id, {
        name,
        shortDescription,
        iconName,
        heroImage,
      });
    } else {
      createCategory({
        name,
        shortDescription,
        iconName,
        heroImage,
        order: categories.length + 1,
      });
    }

    setIsAddModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white">Vehicle Category Management</h2>
          <p className="text-xs text-slate-400">
            Create and organize showroom segments: Bikes, Cars, SUVs, E-Rickshaws, Commercial, EVs.
          </p>
        </div>

        <button
          onClick={openAdd}
          className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition flex items-center justify-center gap-1.5 shadow"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>Add New Category</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((cat, idx) => {
          const vehicleCount = vehicles.filter(v => v.categoryId === cat.id).length;
          return (
            <div
              key={cat.id}
              className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden flex flex-col justify-between shadow-xl"
            >
              <div>
                <div className="relative h-40 overflow-hidden bg-slate-950">
                  <img
                    src={cat.heroImage}
                    alt={cat.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 left-3">
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-400 text-slate-950">
                      Segment #{idx + 1}
                    </span>
                  </div>
                  <div className="absolute top-3 right-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-950/80 text-white border border-slate-700">
                      {vehicleCount} Models
                    </span>
                  </div>
                </div>

                <div className="p-5">
                  <h3 className="text-lg font-bold text-white mb-1">{cat.name}</h3>
                  <p className="text-xs text-slate-400 line-clamp-2 mb-2">
                    {cat.shortDescription}
                  </p>
                  <span className="text-[10px] font-mono text-slate-500">
                    Slug: /vehicles/{cat.slug}
                  </span>
                </div>
              </div>

              <div className="p-4 pt-0 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  onClick={() => openEdit(cat)}
                  className="p-1.5 rounded-lg border border-slate-800 text-amber-400 hover:bg-amber-400/10 transition"
                  title="Edit Category"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>

                <button
                  onClick={() => {
                    if (
                      window.confirm(
                        `Delete category ${cat.name}? (Vehicles in this category won't be deleted)`
                      )
                    ) {
                      deleteCategory(cat.id);
                    }
                  }}
                  className="p-1.5 rounded-lg border border-slate-800 text-rose-400 hover:bg-rose-950/40 transition"
                  title="Delete Category"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Category Modal */}
      {isAddModalOpen && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl my-6">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-950 text-slate-400 hover:text-white flex items-center justify-center"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-xl font-black text-white mb-4">
              {editingCat ? `Edit: ${editingCat.name}` : 'Create Vehicle Category'}
            </h3>

            <form onSubmit={handleSave} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Category Name *
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Electric Scooters"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Short Description
                </label>
                <textarea
                  rows={2}
                  value={shortDescription}
                  onChange={e => setShortDescription(e.target.value)}
                  placeholder="Brief summary of models in this segment..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Banner Image URL
                </label>
                <input
                  type="url"
                  value={heroImage}
                  onChange={e => setHeroImage(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex gap-2">
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition"
                >
                  {editingCat ? 'Save Changes' : 'Create Category'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="w-28 py-2.5 rounded-xl text-xs font-bold text-slate-400 bg-slate-950 hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
