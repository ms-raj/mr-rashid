import React, { useState } from 'react';
import { useShowroom } from '../../context/ShowroomContext';
import { Globe, Save, CheckCircle2, Link, Search } from 'lucide-react';

export const AdminSeo: React.FC = () => {
  const { seo, updateSeo, categories, vehicles } = useShowroom();

  const [formData, setFormData] = useState({
    title: seo.title,
    metaDescription: seo.metaDescription,
    keywordsText: seo.keywords.join(', '),
    ogImageUrl: seo.ogImageUrl,
  });

  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const keywords = formData.keywordsText
      .split(',')
      .map(k => k.trim())
      .filter(k => k.length > 0);

    updateSeo({
      title: formData.title,
      metaDescription: formData.metaDescription,
      keywords,
      ogImageUrl: formData.ogImageUrl,
    });

    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white">Search Engine Optimization (SEO)</h2>
          <p className="text-xs text-slate-400">
            Configure meta tags, open graph preview cards, and view generated canonical slugs.
          </p>
        </div>

        {saved && (
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-xs font-bold">
            <CheckCircle2 className="w-4 h-4" />
            <span>SEO Settings Updated!</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSave} className="space-y-6">
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Global Meta Title Tag *
            </label>
            <input
              type="text"
              required
              value={formData.title}
              onChange={e => setFormData({ ...formData, title: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
            />
            <span className="text-[10px] text-slate-500 mt-1 block">
              Recommended: 50-60 characters (Current: {formData.title.length})
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Meta Description *
            </label>
            <textarea
              rows={3}
              required
              value={formData.metaDescription}
              onChange={e => setFormData({ ...formData, metaDescription: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 resize-none"
            />
            <span className="text-[10px] text-slate-500 mt-1 block">
              Recommended: 120-160 characters (Current: {formData.metaDescription.length})
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              SEO Keywords (Comma-separated)
            </label>
            <input
              type="text"
              value={formData.keywordsText}
              onChange={e => setFormData({ ...formData, keywordsText: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              Open Graph (Social Share Card) Image URL
            </label>
            <input
              type="url"
              value={formData.ogImageUrl}
              onChange={e => setFormData({ ...formData, ogImageUrl: e.target.value })}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl font-bold text-xs text-slate-950 bg-amber-400 hover:bg-amber-300 transition"
          >
            Save SEO Meta Configuration
          </button>
        </div>

        {/* Clean URL Slugs Preview */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Link className="w-4 h-4 text-amber-400" />
            <span>SEO-Friendly URL Structure Preview</span>
          </h3>
          <p className="text-xs text-slate-400">
            Canonical URL patterns automatically mapped for search engines:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-mono text-slate-300">
            <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
              /vehicles
            </div>
            <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
              /vehicles/bikes-scooters
            </div>
            <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
              /vehicles/cars-suvs
            </div>
            <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
              /vehicles/e-rickshaws
            </div>
            <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
              /vehicles/electric-vehicles
            </div>
            <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
              /vehicles/commercial-vehicles
            </div>
            <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
              /vehicle/apex-grandeur-luxury-sedan
            </div>
            <div className="p-2 rounded-lg bg-slate-950 border border-slate-800">
              /offers
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};
