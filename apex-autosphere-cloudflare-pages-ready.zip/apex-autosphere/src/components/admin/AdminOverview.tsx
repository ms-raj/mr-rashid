import React from 'react';
import { useShowroom } from '../../context/ShowroomContext';
import { formatCurrency } from '../../utils/calculator';
import {
  Car,
  Users,
  Calendar,
  Sparkles,
  TrendingUp,
  Tag,
  Clock,
  ArrowUpRight,
  ShieldAlert,
  CheckCircle2,
} from 'lucide-react';

export const AdminOverview: React.FC<{ onNavigateTab: (tab: string) => void }> = ({
  onNavigateTab,
}) => {
  const { vehicles, categories, leads, testDrives, offers, settings } = useShowroom();

  const totalVehicles = vehicles.length;
  const publishedVehicles = vehicles.filter(v => v.published).length;
  const totalLeads = leads.length;
  const newLeadsCount = leads.filter(l => l.status === 'New').length;
  const pendingTestDrives = testDrives.filter(t => t.status === 'Pending').length;
  const activeOffersCount = offers.filter(o => o.published).length;

  const financeLeads = leads.filter(l => l.enquiryType === 'Finance').length;
  const exchangeLeads = leads.filter(l => l.enquiryType === 'Exchange').length;

  const recentLeads = leads.slice(0, 5);

  return (
    <div className="space-y-8">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-500/15 via-slate-900 to-slate-900 border border-amber-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest block mb-1">
            Showroom Management System
          </span>
          <h2 className="text-2xl font-black text-white">
            {settings.name} Operations Hub
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Monitor real-time customer leads, test drive requests, inventory stock levels, and promotions.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigateTab('vehicles')}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition shadow"
          >
            + Add New Vehicle
          </button>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Stat 1: Vehicles */}
        <div
          onClick={() => onNavigateTab('vehicles')}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">Total Vehicles</span>
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Car className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white group-hover:text-amber-400 transition-colors">
            {totalVehicles}
          </div>
          <span className="text-[11px] text-emerald-400 font-semibold block mt-1">
            {publishedVehicles} Published & Live
          </span>
        </div>

        {/* Stat 2: Total Enquiries */}
        <div
          onClick={() => onNavigateTab('leads')}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">Customer Leads</span>
            <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white group-hover:text-blue-400 transition-colors">
            {totalLeads}
          </div>
          <span className="text-[11px] text-amber-400 font-semibold block mt-1">
            {newLeadsCount} New (Needs Follow-up)
          </span>
        </div>

        {/* Stat 3: Test Drives */}
        <div
          onClick={() => onNavigateTab('test-drives')}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">Test Drive Bookings</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white group-hover:text-emerald-400 transition-colors">
            {testDrives.length}
          </div>
          <span className="text-[11px] text-emerald-400 font-semibold block mt-1">
            {pendingTestDrives} Pending Confirmation
          </span>
        </div>

        {/* Stat 4: Active Offers */}
        <div
          onClick={() => onNavigateTab('offers')}
          className="p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition cursor-pointer group"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400">Active Offers</span>
            <div className="w-8 h-8 rounded-lg bg-purple-500/10 text-purple-400 flex items-center justify-center">
              <Tag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white group-hover:text-purple-400 transition-colors">
            {activeOffersCount}
          </div>
          <span className="text-[11px] text-slate-400 block mt-1">
            Across 4 Dealership Campaigns
          </span>
        </div>
      </div>

      {/* Breakdown Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Lead Channels Breakdown */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <h3 className="text-base font-bold text-white mb-4 flex items-center justify-between">
            <span>Enquiry Channels</span>
            <TrendingUp className="w-4 h-4 text-amber-400" />
          </h3>

          <div className="space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Price Quotations:</span>
              <span className="font-bold text-white">
                {leads.filter(l => l.enquiryType === 'Price Quote').length}
              </span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Test Drive Requests:</span>
              <span className="font-bold text-white">
                {leads.filter(l => l.enquiryType === 'Test Drive').length}
              </span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Finance & EMI Enquiries:</span>
              <span className="font-bold text-emerald-400">{financeLeads}</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Vehicle Exchange Evaluations:</span>
              <span className="font-bold text-amber-400">{exchangeLeads}</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-slate-400">Festive Offers & General:</span>
              <span className="font-bold text-white">
                {leads.filter(l => l.enquiryType === 'Offer' || l.enquiryType === 'General').length}
              </span>
            </div>
          </div>
        </div>

        {/* Category Inventory Count */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
          <h3 className="text-base font-bold text-white mb-4 flex items-center justify-between">
            <span>Inventory by Category</span>
            <Car className="w-4 h-4 text-amber-400" />
          </h3>

          <div className="space-y-2.5">
            {categories.map(c => {
              const count = vehicles.filter(v => v.categoryId === c.id).length;
              return (
                <div key={c.id} className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">{c.name}</span>
                  <span className="font-bold px-2 py-0.5 rounded bg-slate-950 text-slate-200 border border-slate-800">
                    {count} {count === 1 ? 'vehicle' : 'vehicles'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Quick Quicklinks */}
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 flex flex-col justify-between">
          <div>
            <h3 className="text-base font-bold text-white mb-2">
              Management Shortcuts
            </h3>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              Quickly jump to inventory updates, review moderation, or showroom contact settings.
            </p>
          </div>

          <div className="space-y-2">
            <button
              onClick={() => onNavigateTab('leads')}
              className="w-full py-2.5 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 text-xs font-semibold text-slate-200 border border-slate-800 flex items-center justify-between transition"
            >
              <span>View All Leads ({leads.length})</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
            </button>

            <button
              onClick={() => onNavigateTab('test-drives')}
              className="w-full py-2.5 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 text-xs font-semibold text-slate-200 border border-slate-800 flex items-center justify-between transition"
            >
              <span>Manage Test Drives ({testDrives.length})</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
            </button>

            <button
              onClick={() => onNavigateTab('settings')}
              className="w-full py-2.5 px-3 rounded-xl bg-slate-950 hover:bg-slate-800 text-xs font-semibold text-slate-200 border border-slate-800 flex items-center justify-between transition"
            >
              <span>Showroom & SEO Settings</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-amber-400" />
            </button>
          </div>
        </div>
      </div>

      {/* Recent Leads Table */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-white">Recent Customer Leads</h3>
          <button
            onClick={() => onNavigateTab('leads')}
            className="text-xs font-bold text-amber-400 hover:underline flex items-center gap-1"
          >
            <span>View All Leads</span>
            <span>→</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Customer Name</th>
                <th className="py-2.5 px-3">Mobile</th>
                <th className="py-2.5 px-3">Vehicle</th>
                <th className="py-2.5 px-3">Type</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {recentLeads.map(lead => (
                <tr key={lead.id} className="hover:bg-slate-950/50 transition">
                  <td className="py-2.5 px-3 font-bold text-white">{lead.customerName}</td>
                  <td className="py-2.5 px-3 font-mono">{lead.mobile}</td>
                  <td className="py-2.5 px-3 truncate max-w-[180px]">
                    {lead.vehicleName || 'General Enquiry'}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="px-2 py-0.5 rounded bg-slate-950 text-amber-400 border border-slate-800 text-[10px] font-semibold">
                      {lead.enquiryType}
                    </span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        lead.status === 'New'
                          ? 'bg-amber-950/80 text-amber-300 border border-amber-500/30'
                          : lead.status === 'Converted'
                          ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {lead.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-500 text-[11px]">
                    {new Date(lead.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
