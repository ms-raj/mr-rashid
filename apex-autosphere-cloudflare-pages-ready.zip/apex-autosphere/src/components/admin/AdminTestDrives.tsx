import React, { useState } from 'react';
import { useShowroom } from '../../context/ShowroomContext';
import { TestDriveStatus } from '../../types';
import { generateWhatsAppUrl } from '../../utils/calculator';
import {
  Calendar,
  Clock,
  MapPin,
  Car,
  Phone,
  MessageSquare,
  Trash2,
  Search,
  CheckCircle2,
} from 'lucide-react';

export const AdminTestDrives: React.FC = () => {
  const { testDrives, updateTestDriveStatus, deleteTestDrive, settings } = useShowroom();
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const statuses: TestDriveStatus[] = ['Pending', 'Confirmed', 'Completed', 'Cancelled'];

  const filtered = testDrives.filter(td => {
    const matchesSearch =
      td.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      td.mobile.includes(searchQuery) ||
      td.vehicleName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || td.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: TestDriveStatus) => {
    switch (status) {
      case 'Pending':
        return 'bg-amber-950/80 text-amber-300 border-amber-500/30';
      case 'Confirmed':
        return 'bg-blue-950/80 text-blue-300 border-blue-500/30';
      case 'Completed':
        return 'bg-emerald-950/80 text-emerald-300 border-emerald-500/30';
      case 'Cancelled':
      default:
        return 'bg-slate-800 text-slate-400 border-slate-700';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white">Test Drive Bookings & Logistics</h2>
          <p className="text-xs text-slate-400">
            Coordinate showroom and doorstep customer drive appointments and vehicle assignment.
          </p>
        </div>
        <div className="text-xs font-semibold text-slate-400">
          Total Bookings: <strong className="text-white">{testDrives.length}</strong>
        </div>
      </div>

      {/* Search & Filter */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search booking customer, phone, or vehicle..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div>
          <select
            value={statusFilter}
            onChange={e => setStatusFilter(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option value="all">All Drive Statuses</option>
            {statuses.map(st => (
              <option key={st} value={st}>
                {st} ({testDrives.filter(t => t.status === st).length})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Test Drives Table */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-3">Vehicle</th>
                <th className="py-3 px-3">Schedule</th>
                <th className="py-3 px-3">Location</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map(td => (
                <tr key={td.id} className="hover:bg-slate-950/40 transition">
                  <td className="py-3 px-4">
                    <div className="font-bold text-white text-sm">{td.customerName}</div>
                    <div className="font-mono text-slate-400 text-xs mt-0.5">{td.mobile}</div>
                    {td.email && <div className="text-[11px] text-slate-500">{td.email}</div>}
                  </td>

                  <td className="py-3 px-3">
                    <span className="font-semibold text-white block">{td.vehicleName}</span>
                    {td.message && (
                      <span className="text-[11px] text-slate-400 italic line-clamp-1">
                        "{td.message}"
                      </span>
                    )}
                  </td>

                  <td className="py-3 px-3">
                    <div className="flex items-center gap-1 font-semibold text-white">
                      <Calendar className="w-3.5 h-3.5 text-amber-400" />
                      <span>{td.preferredDate}</span>
                    </div>
                    <div className="flex items-center gap-1 text-slate-400 text-[11px] mt-0.5">
                      <Clock className="w-3 h-3 text-slate-500" />
                      <span>{td.preferredTime}</span>
                    </div>
                  </td>

                  <td className="py-3 px-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold inline-block mb-0.5 ${
                        td.locationType === 'Doorstep'
                          ? 'bg-amber-400/10 text-amber-300 border border-amber-400/30'
                          : 'bg-slate-950 text-slate-300 border border-slate-800'
                      }`}
                    >
                      {td.locationType}
                    </span>
                    {td.address && (
                      <div className="text-[11px] text-slate-400 truncate max-w-xs" title={td.address}>
                        {td.address}
                      </div>
                    )}
                  </td>

                  <td className="py-3 px-3">
                    <select
                      value={td.status}
                      onChange={e => updateTestDriveStatus(td.id, e.target.value as TestDriveStatus)}
                      className={`px-2 py-1 rounded text-[11px] font-bold border focus:outline-none cursor-pointer ${getStatusColor(
                        td.status
                      )}`}
                    >
                      {statuses.map(st => (
                        <option key={st} value={st} className="bg-slate-900 text-white">
                          {st}
                        </option>
                      ))}
                    </select>
                  </td>

                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <a
                        href={`tel:${td.mobile}`}
                        className="p-1.5 rounded-lg border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800 transition"
                        title="Call Customer"
                      >
                        <Phone className="w-3.5 h-3.5 text-amber-400" />
                      </a>

                      <a
                        href={generateWhatsAppUrl(
                          td.mobile,
                          `Hello ${td.customerName}, this is ${settings.name} confirming your test drive appointment for the ${td.vehicleName} on ${td.preferredDate} at ${td.preferredTime}.`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg border border-emerald-800/60 text-emerald-300 bg-emerald-950/40 hover:bg-emerald-900 transition"
                        title="Confirm on WhatsApp"
                      >
                        <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                      </a>

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete test drive request from ${td.customerName}?`)) {
                            deleteTestDrive(td.id);
                          }
                        }}
                        className="p-1.5 rounded-lg border border-slate-800 text-rose-400 hover:bg-rose-950/40 transition"
                        title="Delete Request"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
