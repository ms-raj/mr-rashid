import React, { useState } from 'react';
import { useShowroom } from '../../context/ShowroomContext';
import { Vehicle, FuelType, TransmissionType, AvailabilityStatus } from '../../types';
import { formatCurrency } from '../../utils/calculator';
import {
  Car,
  Plus,
  Edit2,
  Trash2,
  Copy,
  Eye,
  EyeOff,
  Star,
  Search,
  X,
  Check,
  Sparkles,
} from 'lucide-react';

export const AdminVehicles: React.FC = () => {
  const {
    vehicles,
    categories,
    createVehicle,
    updateVehicle,
    deleteVehicle,
    duplicateVehicle,
  } = useShowroom();

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [editingVehicle, setEditingVehicle] = useState<Vehicle | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form State for Add / Edit
  const [formData, setFormData] = useState<{
    name: string;
    brand: string;
    categoryId: string;
    modelYear: number;
    price: number;
    originalPrice?: number;
    emiStarting: number;
    availability: AvailabilityStatus;
    featured: boolean;
    published: boolean;
    fuelType: FuelType;
    transmission: TransmissionType;
    seatingCapacity: number;
    engineOrMotor: string;
    power: string;
    torque: string;
    mileageOrRange: string;
    batteryCapacity: string;
    chargingTime: string;
    topSpeed: string;
    groundClearance: string;
    dimensions: string;
    warranty: string;
    description: string;
    featuresText: string;
    imageUrl: string;
  }>({
    name: '',
    brand: 'Apex Prestige',
    categoryId: 'cars-suvs',
    modelYear: 2026,
    price: 1500000,
    originalPrice: 1600000,
    emiStarting: 28000,
    availability: 'In Stock',
    featured: false,
    published: true,
    fuelType: 'Petrol',
    transmission: 'Automatic',
    seatingCapacity: 5,
    engineOrMotor: '1.5L Turbo Petrol',
    power: '150 PS',
    torque: '240 Nm',
    mileageOrRange: '18 km/l',
    batteryCapacity: '',
    chargingTime: '',
    topSpeed: '190 km/h',
    groundClearance: '175 mm',
    dimensions: '4500 x 1800 x 1500 mm',
    warranty: '3 Years / 100,000 km',
    description: 'High-performance automobile engineered for luxury and efficiency.',
    featuresText: 'LED Headlamps\nTouchscreen Display\nABS with EBD\nReverse Parking Camera',
    imageUrl: 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80',
  });

  const openAddModal = () => {
    setEditingVehicle(null);
    setFormData({
      name: '',
      brand: 'Apex Prestige',
      categoryId: categories[0]?.id || 'cars-suvs',
      modelYear: 2026,
      price: 1200000,
      originalPrice: 1300000,
      emiStarting: 24000,
      availability: 'In Stock',
      featured: false,
      published: true,
      fuelType: 'Petrol',
      transmission: 'Manual',
      seatingCapacity: 5,
      engineOrMotor: '1.5L Petrol',
      power: '120 PS',
      torque: '175 Nm',
      mileageOrRange: '17.5 km/l',
      batteryCapacity: '',
      chargingTime: '',
      topSpeed: '180 km/h',
      groundClearance: '170 mm',
      dimensions: '4300 x 1790 x 1620 mm',
      warranty: '3 Years Warranty',
      description: 'Reliable, powerful automobile for personal and family travel.',
      featuresText: 'LED Headlamps\nDual Airbags\nABS with EBD\nPower Steering',
      imageUrl: 'https://images.unsplash.com/photo-1555215695-3004980ad54e?auto=format&fit=crop&w=1200&q=80',
    });
    setIsAddModalOpen(true);
  };

  const openEditModal = (vehicle: Vehicle) => {
    setEditingVehicle(vehicle);
    setFormData({
      name: vehicle.name,
      brand: vehicle.brand,
      categoryId: vehicle.categoryId,
      modelYear: vehicle.modelYear,
      price: vehicle.price,
      originalPrice: vehicle.originalPrice,
      emiStarting: vehicle.emiStarting,
      availability: vehicle.availability,
      featured: vehicle.featured,
      published: vehicle.published,
      fuelType: vehicle.fuelType,
      transmission: vehicle.transmission,
      seatingCapacity: vehicle.seatingCapacity,
      engineOrMotor: vehicle.engineOrMotor,
      power: vehicle.power,
      torque: vehicle.torque,
      mileageOrRange: vehicle.mileageOrRange,
      batteryCapacity: vehicle.batteryCapacity || '',
      chargingTime: vehicle.chargingTime || '',
      topSpeed: vehicle.topSpeed,
      groundClearance: vehicle.groundClearance || '',
      dimensions: vehicle.dimensions || '',
      warranty: vehicle.warranty,
      description: vehicle.description,
      featuresText: vehicle.features.join('\n'),
      imageUrl: vehicle.images[0] || '',
    });
    setIsAddModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || formData.price <= 0) return;

    const selectedCat = categories.find(c => c.id === formData.categoryId);
    const categoryName = selectedCat ? selectedCat.name : 'Automobiles';

    const features = formData.featuresText
      .split('\n')
      .map(f => f.trim())
      .filter(f => f.length > 0);

    const images = formData.imageUrl.trim()
      ? [formData.imageUrl.trim()]
      : ['https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80'];

    if (editingVehicle) {
      updateVehicle(editingVehicle.id, {
        ...formData,
        categoryName,
        features,
        images,
      });
    } else {
      createVehicle({
        ...formData,
        categoryName,
        features,
        images,
      });
    }

    setIsAddModalOpen(false);
    setEditingVehicle(null);
  };

  const filteredVehicles = vehicles.filter(v => {
    const matchesSearch =
      v.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      v.brand.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCat = categoryFilter === 'all' || v.categoryId === categoryFilter;
    return matchesSearch && matchesCat;
  });

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-black text-white">Vehicle Inventory Management</h2>
          <p className="text-xs text-slate-400">
            Add, update specifications, adjust pricing & EMIs, and toggle availability.
          </p>
        </div>

        <button
          onClick={openAddModal}
          className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition flex items-center justify-center gap-1.5 shadow"
        >
          <Plus className="w-4 h-4 text-slate-950" />
          <span>Add New Vehicle</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="sm:col-span-2 relative">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by vehicle name or brand..."
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-400"
          />
        </div>

        <div>
          <select
            value={categoryFilter}
            onChange={e => setCategoryFilter(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
          >
            <option value="all">All Categories</option>
            {categories.map(c => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Inventory Table */}
      <div className="rounded-3xl bg-slate-900 border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Vehicle</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3">Fuel / Trans</th>
                <th className="py-3 px-3">Price</th>
                <th className="py-3 px-3">EMI</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredVehicles.map(v => (
                <tr key={v.id} className="hover:bg-slate-950/40 transition">
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <img
                        src={v.images[0] || 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=200&q=80'}
                        alt={v.name}
                        className="w-12 h-9 object-cover rounded-lg border border-slate-800"
                      />
                      <div>
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <span>{v.name}</span>
                          {v.featured && (
                            <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                          )}
                        </div>
                        <span className="text-[11px] text-slate-500">{v.brand} • {v.modelYear}</span>
                      </div>
                    </div>
                  </td>

                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-800 text-[10px]">
                      {v.categoryName}
                    </span>
                  </td>

                  <td className="py-3 px-3 text-[11px]">
                    <span className="font-semibold text-white">{v.fuelType}</span>
                    <span className="block text-slate-500">{v.transmission}</span>
                  </td>

                  <td className="py-3 px-3 font-bold text-white font-mono">
                    {formatCurrency(v.price)}
                  </td>

                  <td className="py-3 px-3 text-emerald-400 font-mono text-[11px]">
                    {formatCurrency(v.emiStarting)}/mo
                  </td>

                  <td className="py-3 px-3">
                    <div className="flex flex-col gap-1 items-start">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          v.availability === 'In Stock'
                            ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/30'
                            : 'bg-amber-950/80 text-amber-300 border border-amber-500/30'
                        }`}
                      >
                        {v.availability}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        {v.published ? 'Live on Site' : 'Draft (Hidden)'}
                      </span>
                    </div>
                  </td>

                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => updateVehicle(v.id, { published: !v.published })}
                        className={`p-1.5 rounded-lg border transition ${
                          v.published
                            ? 'text-emerald-400 border-emerald-500/30 hover:bg-emerald-950/40'
                            : 'text-slate-500 border-slate-800 hover:text-slate-300'
                        }`}
                        title={v.published ? 'Unpublish from store' : 'Publish to store'}
                      >
                        {v.published ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                      </button>

                      <button
                        onClick={() => updateVehicle(v.id, { featured: !v.featured })}
                        className={`p-1.5 rounded-lg border transition ${
                          v.featured
                            ? 'text-amber-400 border-amber-500/30 bg-amber-500/10'
                            : 'text-slate-500 border-slate-800 hover:text-amber-400'
                        }`}
                        title="Toggle Featured badge"
                      >
                        <Star className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => duplicateVehicle(v.id)}
                        className="p-1.5 rounded-lg border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800 transition"
                        title="Duplicate vehicle"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => openEditModal(v)}
                        className="p-1.5 rounded-lg border border-slate-800 text-amber-400 hover:bg-amber-400/10 transition"
                        title="Edit vehicle details"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete ${v.name}?`)) {
                            deleteVehicle(v.id);
                          }
                        }}
                        className="p-1.5 rounded-lg border border-slate-800 text-rose-400 hover:bg-rose-950/40 transition"
                        title="Delete vehicle"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Vehicle Modal */}
      {isAddModalOpen && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6"
          role="dialog"
          aria-modal="true"
        >
          <div className="relative w-full max-w-3xl bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl my-6">
            <button
              onClick={() => setIsAddModalOpen(false)}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-950 text-slate-400 hover:text-white flex items-center justify-center border border-slate-800"
            >
              <X className="w-4 h-4" />
            </button>

            <h3 className="text-xl font-black text-white mb-4">
              {editingVehicle ? `Edit: ${editingVehicle.name}` : 'Add New Vehicle to Inventory'}
            </h3>

            <form onSubmit={handleSave} className="space-y-4 max-h-[75vh] overflow-y-auto pr-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Vehicle Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={e => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g. Apex Falcon 400"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Brand *</label>
                  <input
                    type="text"
                    required
                    value={formData.brand}
                    onChange={e => setFormData({ ...formData, brand: e.target.value })}
                    placeholder="e.g. Apex Prestige"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Category</label>
                  <select
                    value={formData.categoryId}
                    onChange={e => setFormData({ ...formData, categoryId: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    {categories.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Fuel Type</label>
                  <select
                    value={formData.fuelType}
                    onChange={e => setFormData({ ...formData, fuelType: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="Petrol">Petrol</option>
                    <option value="Diesel">Diesel</option>
                    <option value="Electric">⚡ Electric</option>
                    <option value="CNG">CNG / Bi-Fuel</option>
                    <option value="Hybrid">Hybrid</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Transmission</label>
                  <select
                    value={formData.transmission}
                    onChange={e => setFormData({ ...formData, transmission: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="Manual">Manual</option>
                    <option value="Automatic">Automatic</option>
                    <option value="Direct Drive">Direct Drive (EV)</option>
                    <option value="e-CVT">e-CVT</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Ex-Showroom Price (₹) *</label>
                  <input
                    type="number"
                    required
                    value={formData.price}
                    onChange={e => setFormData({ ...formData, price: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Original Price (For Discount)</label>
                  <input
                    type="number"
                    value={formData.originalPrice || ''}
                    onChange={e => setFormData({ ...formData, originalPrice: Number(e.target.value) || undefined })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Starting Monthly EMI (₹)</label>
                  <input
                    type="number"
                    value={formData.emiStarting}
                    onChange={e => setFormData({ ...formData, emiStarting: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Availability</label>
                  <select
                    value={formData.availability}
                    onChange={e => setFormData({ ...formData, availability: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="In Stock">In Stock</option>
                    <option value="Fast Delivery">Fast Delivery</option>
                    <option value="Booking Open">Booking Open</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Seating Capacity</label>
                  <input
                    type="number"
                    value={formData.seatingCapacity}
                    onChange={e => setFormData({ ...formData, seatingCapacity: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Model Year</label>
                  <input
                    type="number"
                    value={formData.modelYear}
                    onChange={e => setFormData({ ...formData, modelYear: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Specs Details */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Engine / Motor</label>
                  <input
                    type="text"
                    value={formData.engineOrMotor}
                    onChange={e => setFormData({ ...formData, engineOrMotor: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Max Power</label>
                  <input
                    type="text"
                    value={formData.power}
                    onChange={e => setFormData({ ...formData, power: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Mileage / Range</label>
                  <input
                    type="text"
                    value={formData.mileageOrRange}
                    onChange={e => setFormData({ ...formData, mileageOrRange: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Image URL */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Primary Image URL (Unsplash or direct image link)
                </label>
                <input
                  type="url"
                  value={formData.imageUrl}
                  onChange={e => setFormData({ ...formData, imageUrl: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Description</label>
                <textarea
                  rows={2}
                  value={formData.description}
                  onChange={e => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 resize-none"
                />
              </div>

              {/* Features (One per line) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Features (One per line)
                </label>
                <textarea
                  rows={3}
                  value={formData.featuresText}
                  onChange={e => setFormData({ ...formData, featuresText: e.target.value })}
                  placeholder="LED Headlights&#10;Digital Cluster&#10;Dual ABS&#10;Cruise Control"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center gap-6 pt-2">
                <label className="flex items-center gap-2 text-xs font-bold text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.published}
                    onChange={e => setFormData({ ...formData, published: e.target.checked })}
                    className="w-4 h-4 accent-amber-400 rounded"
                  />
                  <span>Published (Visible to Customers)</span>
                </label>

                <label className="flex items-center gap-2 text-xs font-bold text-white cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formData.featured}
                    onChange={e => setFormData({ ...formData, featured: e.target.checked })}
                    className="w-4 h-4 accent-amber-400 rounded"
                  />
                  <span>Mark as Featured on Homepage</span>
                </label>
              </div>

              <div className="pt-4 border-t border-slate-800 flex gap-3">
                <button
                  type="submit"
                  className="w-full py-3 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition"
                >
                  {editingVehicle ? 'Save Vehicle Changes' : 'Create Vehicle'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="w-32 py-3 rounded-xl text-xs font-bold text-slate-400 bg-slate-950 hover:bg-slate-800 transition"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
