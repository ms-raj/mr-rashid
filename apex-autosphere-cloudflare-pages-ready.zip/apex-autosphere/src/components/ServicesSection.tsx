import React from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  ShoppingBag,
  Car,
  CreditCard,
  Shield,
  RefreshCw,
  FileCheck2,
  Package,
  Wrench,
  ArrowRight,
} from 'lucide-react';

export const ServicesSection: React.FC = () => {
  const { setActiveTab, openTestDriveModal, openEnquiryModal } = useShowroom();

  const services = [
    {
      title: 'Vehicle Sales',
      description: 'Wide selection of vehicles across 7 categories with transparent ex-showroom and on-road pricing.',
      icon: <ShoppingBag className="w-6 h-6 text-amber-400" />,
      action: () => setActiveTab('vehicles', 'all'),
      actionLabel: 'Browse Inventory',
    },
    {
      title: 'Test Drive',
      description: 'Experience your preferred vehicle at our state-of-the-art showroom or delivered directly to your doorstep.',
      icon: <Car className="w-6 h-6 text-amber-400" />,
      action: () => openTestDriveModal(),
      actionLabel: 'Book Test Drive',
    },
    {
      title: 'Vehicle Finance',
      description: 'Finance assistance and guidance with quick approvals, low interest rates, and flexible tenure.',
      icon: <CreditCard className="w-6 h-6 text-amber-400" />,
      action: () => openEnquiryModal(null, 'Finance'),
      actionLabel: 'Apply for Finance',
    },
    {
      title: 'Insurance Assistance',
      description: 'Comprehensive support with cashless insurance renewals, zero depreciation add-ons, and quick claim settlement.',
      icon: <Shield className="w-6 h-6 text-amber-400" />,
      action: () => openEnquiryModal(null, 'General'),
      actionLabel: 'Get Insurance Quote',
    },
    {
      title: 'Vehicle Exchange',
      description: 'Explore vehicle exchange options with spot market evaluation and exclusive upgrade bonuses.',
      icon: <RefreshCw className="w-6 h-6 text-amber-400" />,
      action: () => openEnquiryModal(null, 'Exchange'),
      actionLabel: 'Evaluate Old Vehicle',
    },
    {
      title: 'Registration Assistance',
      description: 'Complete guidance for RTO registration processes, temporary permits, road tax payment, and VIP number booking.',
      icon: <FileCheck2 className="w-6 h-6 text-amber-400" />,
      action: () => openEnquiryModal(null, 'General'),
      actionLabel: 'RTO Guidance',
    },
    {
      title: 'Accessories & Upgrades',
      description: 'Genuine certified vehicle accessories, alloy wheels, ceramic coatings, seat covers, and electronic add-ons.',
      icon: <Package className="w-6 h-6 text-amber-400" />,
      action: () => openEnquiryModal(null, 'General'),
      actionLabel: 'View Accessories',
    },
    {
      title: 'After-Sales Support',
      description: 'Dedicated customer assistance after purchase, scheduled maintenance tracking, and warranty support.',
      icon: <Wrench className="w-6 h-6 text-amber-400" />,
      action: () => openEnquiryModal(null, 'General'),
      actionLabel: 'Support Desk',
    },
  ];

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
            End-To-End Automotive Solutions
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
            Comprehensive Dealership Services
          </h2>
          <p className="text-base sm:text-lg text-slate-400">
            From vehicle selection and doorstep test drives to instant financing, insurance, and lifetime after-sales care.
          </p>
        </div>

        {/* 8 Services Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((service, idx) => (
            <div
              key={idx}
              className="group p-6 rounded-3xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition-all duration-300 flex flex-col justify-between shadow-xl"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                  {service.icon}
                </div>
                <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors mb-2">
                  {service.title}
                </h3>
                <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-6">
                  {service.description}
                </p>
              </div>

              <button
                onClick={service.action}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-400 hover:text-amber-300 transition group-hover:translate-x-1"
              >
                <span>{service.actionLabel}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
