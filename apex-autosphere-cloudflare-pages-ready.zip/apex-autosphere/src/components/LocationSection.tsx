import React from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  MapPin,
  Phone,
  MessageSquare,
  Mail,
  Clock,
  Navigation,
  ExternalLink,
} from 'lucide-react';
import { generateWhatsAppUrl } from '../utils/calculator';

export const LocationSection: React.FC = () => {
  const { settings } = useShowroom();

  const whatsAppUrl = generateWhatsAppUrl(
    settings.whatsappNumber,
    `Hello ${settings.name}, I would like to visit the showroom. Please share live location and parking details.`
  );

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
            Visit Our Showroom
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
            Flagship Experience Center
          </h2>
          <p className="text-base sm:text-lg text-slate-400">
            Conveniently situated in the prime automotive hub with dedicated customer test-drive tracks, EV charging bays, and lounge.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Left Column: Contact Card & Hours */}
          <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col justify-between shadow-2xl">
            <div className="space-y-6">
              <div>
                <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block mb-1">
                  Showroom Address
                </span>
                <div className="flex items-start gap-3 mt-2">
                  <MapPin className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                  <p className="text-sm sm:text-base text-slate-200 leading-relaxed">
                    {settings.address}, {settings.city}, {settings.state} - {settings.pincode}
                  </p>
                </div>
              </div>

              {/* Phone & WhatsApp */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-800">
                <div>
                  <span className="text-xs font-semibold text-slate-400 block mb-1">
                    Direct Phone Line
                  </span>
                  <a
                    href={`tel:${settings.phone}`}
                    className="text-sm sm:text-base font-bold text-white hover:text-amber-400 transition flex items-center gap-2"
                  >
                    <Phone className="w-4 h-4 text-amber-400" />
                    <span>{settings.phone}</span>
                  </a>
                </div>

                <div>
                  <span className="text-xs font-semibold text-slate-400 block mb-1">
                    WhatsApp Chat
                  </span>
                  <a
                    href={whatsAppUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm sm:text-base font-bold text-emerald-400 hover:text-emerald-300 transition flex items-center gap-2"
                  >
                    <MessageSquare className="w-4 h-4 text-emerald-400" />
                    <span>{settings.whatsappNumber}</span>
                  </a>
                </div>
              </div>

              {/* Email */}
              <div className="pt-4 border-t border-slate-800">
                <span className="text-xs font-semibold text-slate-400 block mb-1">
                  Customer Support Email
                </span>
                <a
                  href={`mailto:${settings.email}`}
                  className="text-sm font-bold text-white hover:text-amber-400 transition flex items-center gap-2"
                >
                  <Mail className="w-4 h-4 text-amber-400" />
                  <span>{settings.email}</span>
                </a>
              </div>

              {/* Opening Hours */}
              <div className="pt-4 border-t border-slate-800">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <span>Showroom Timings</span>
                </span>
                <div className="space-y-1.5 text-xs text-slate-300">
                  {settings.openingHours.map((h, i) => (
                    <div key={i} className="flex justify-between items-center py-1">
                      <span className="text-slate-400">{h.days}:</span>
                      <span className="font-bold text-white">{h.time}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-3 gap-2.5 pt-6 mt-6 border-t border-slate-800">
              <a
                href={settings.googleMapsShareUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 px-3 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition flex items-center justify-center gap-1.5 shadow"
              >
                <Navigation className="w-3.5 h-3.5" />
                <span>Directions</span>
              </a>

              <a
                href={`tel:${settings.phone}`}
                className="py-2.5 px-3 rounded-xl text-xs font-bold text-slate-200 bg-slate-950 hover:bg-slate-800 border border-slate-700 transition flex items-center justify-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>Call Now</span>
              </a>

              <a
                href={whatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 px-3 rounded-xl text-xs font-bold text-emerald-300 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 transition flex items-center justify-center gap-1.5"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>

          {/* Right Column: Google Maps Interactive View */}
          <div className="lg:col-span-7 rounded-3xl overflow-hidden border border-slate-800 bg-slate-900 shadow-2xl relative min-h-[380px] flex flex-col">
            <iframe
              src={settings.googleMapsEmbedUrl}
              title="Apex AutoSphere Showroom Location Map"
              width="100%"
              height="100%"
              style={{ border: 0, minHeight: '380px', flex: 1 }}
              allowFullScreen={true}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              className="grayscale contrast-125 opacity-90"
            />
          </div>
        </div>
      </div>
    </section>
  );
};
