import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import { GalleryItem } from '../types';
import { Image, X, ChevronLeft, ChevronRight, Eye } from 'lucide-react';

export const GallerySection: React.FC = () => {
  const { gallery } = useShowroom();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeLightboxIndex, setActiveLightboxIndex] = useState<number | null>(null);

  const categories = [
    'all',
    'Showroom',
    'Vehicles',
    'Customer Deliveries',
    'Delivery',
    'Team',
  ];

  const filteredItems = gallery.filter(item => {
    if (selectedCategory === 'all') return true;
    return item.category === selectedCategory;
  });

  const currentLightboxItem =
    activeLightboxIndex !== null ? filteredItems[activeLightboxIndex] : null;

  const handleNext = () => {
    if (activeLightboxIndex !== null) {
      setActiveLightboxIndex((activeLightboxIndex + 1) % filteredItems.length);
    }
  };

  const handlePrev = () => {
    if (activeLightboxIndex !== null) {
      setActiveLightboxIndex(
        (activeLightboxIndex - 1 + filteredItems.length) % filteredItems.length
      );
    }
  };

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
            Visual Experience
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
            Showroom & Delivery Gallery
          </h2>
          <p className="text-base sm:text-lg text-slate-400">
            Take a visual tour of our state-of-the-art multi-brand showroom, handover celebrations, and service fleet.
          </p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-10 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold capitalize whitespace-nowrap transition ${
                selectedCategory === cat
                  ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {cat === 'all' ? 'All Photos' : cat}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => setActiveLightboxIndex(idx)}
              className="group relative h-64 sm:h-72 rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 hover:border-amber-400/50 transition-all duration-300 cursor-pointer shadow-xl"
            >
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-108 transition-transform duration-500"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              <div className="absolute top-3 right-3">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-950/80 text-amber-400 border border-slate-700 backdrop-blur-md">
                  {item.category}
                </span>
              </div>

              <div className="absolute bottom-4 left-4 right-4">
                <h3 className="text-base font-bold text-white group-hover:text-amber-400 transition-colors mb-1">
                  {item.title}
                </h3>
                {item.caption && (
                  <p className="text-xs text-slate-300 line-clamp-2">
                    {item.caption}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {currentLightboxItem && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-md flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Photo Lightbox"
        >
          <button
            onClick={() => setActiveLightboxIndex(null)}
            className="absolute top-5 right-5 z-20 w-11 h-11 rounded-full bg-slate-900 text-white hover:bg-slate-800 border border-slate-700 flex items-center justify-center transition"
            aria-label="Close photo lightbox"
          >
            <X className="w-5 h-5" />
          </button>

          {filteredItems.length > 1 && (
            <>
              <button
                onClick={handlePrev}
                className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-slate-900/90 text-white hover:bg-amber-400 hover:text-slate-950 border border-slate-700 flex items-center justify-center transition"
                aria-label="Previous photo"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>
              <button
                onClick={handleNext}
                className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-slate-900/90 text-white hover:bg-amber-400 hover:text-slate-950 border border-slate-700 flex items-center justify-center transition"
                aria-label="Next photo"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </>
          )}

          <div className="max-w-4xl w-full max-h-[85vh] flex flex-col items-center">
            <img
              src={currentLightboxItem.imageUrl}
              alt={currentLightboxItem.title}
              className="max-h-[70vh] w-auto max-w-full rounded-2xl object-contain border border-slate-800 shadow-2xl"
            />
            <div className="text-center mt-4">
              <span className="text-xs font-bold text-amber-400 uppercase tracking-wider block mb-1">
                {currentLightboxItem.category}
              </span>
              <h3 className="text-lg font-bold text-white">{currentLightboxItem.title}</h3>
              {currentLightboxItem.caption && (
                <p className="text-xs text-slate-400 mt-1">{currentLightboxItem.caption}</p>
              )}
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
