import React from 'react';
import { useShowroom } from '../context/ShowroomContext';
import { ArrowRight, Bike, Car, Zap, BatteryCharging, Truck, Boxes } from 'lucide-react';

export const CategorySection: React.FC = () => {
  const { categories, setActiveTab, vehicles } = useShowroom();

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Bike':
        return <Bike className="w-5 h-5 text-amber-400" />;
      case 'Car':
        return <Car className="w-5 h-5 text-amber-400" />;
      case 'Zap':
        return <Zap className="w-5 h-5 text-amber-400" />;
      case 'BatteryCharging':
        return <BatteryCharging className="w-5 h-5 text-emerald-400" />;
      case 'Truck':
        return <Truck className="w-5 h-5 text-amber-400" />;
      case 'Boxes':
      default:
        return <Boxes className="w-5 h-5 text-amber-400" />;
    }
  };

  return (
    <section className="py-20 bg-slate-950 text-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
            Comprehensive Inventory
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
            Explore Our Vehicles
          </h2>
          <p className="text-base sm:text-lg text-slate-400">
            Find the right vehicle for your personal, family or business needs.
          </p>
        </div>

        {/* Large Image-Based Category Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map(cat => {
            const count = vehicles.filter(v => v.categoryId === cat.id && v.published).length;
            return (
              <div
                key={cat.id}
                onClick={() => setActiveTab('vehicles', cat.id)}
                className="group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-800/80 hover:border-amber-500/50 transition-all duration-300 cursor-pointer shadow-xl hover:shadow-2xl hover:shadow-amber-500/10 flex flex-col justify-end min-h-[320px]"
              >
                {/* Background Image with Zoom Effect */}
                <div className="absolute inset-0 z-0 overflow-hidden">
                  <img
                    src={cat.heroImage}
                    alt={cat.name}
                    className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-700 opacity-50 group-hover:opacity-65"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/70 to-transparent" />
                </div>

                {/* Content Overlay */}
                <div className="relative z-10 p-6 flex flex-col justify-end">
                  <div className="flex items-center justify-between mb-2">
                    <div className="w-10 h-10 rounded-xl bg-slate-900/90 backdrop-blur-md border border-slate-700/60 flex items-center justify-center">
                      {getIcon(cat.iconName)}
                    </div>
                    <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-900/80 backdrop-blur-md border border-slate-700/60 text-slate-300">
                      {count} {count === 1 ? 'Model' : 'Models'} Available
                    </span>
                  </div>

                  <h3 className="text-xl sm:text-2xl font-black text-white group-hover:text-amber-400 transition-colors mb-2">
                    {cat.name}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-300 line-clamp-2 mb-4 leading-relaxed">
                    {cat.shortDescription}
                  </p>

                  <div className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-amber-400 group-hover:translate-x-1 transition-transform">
                    <span>Explore Category</span>
                    <ArrowRight className="w-4 h-4" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
