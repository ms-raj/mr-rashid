import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  Star,
  Quote,
  CheckCircle,
  ExternalLink,
  PlusCircle,
  X,
  Sparkles,
} from 'lucide-react';

export const ReviewsSection: React.FC = () => {
  const { reviews, createReview } = useShowroom();

  const [isWriteReviewOpen, setIsWriteReviewOpen] = useState(false);
  const [authorName, setAuthorName] = useState('');
  const [vehicleBought, setVehicleBought] = useState('');
  const [starCount, setStarCount] = useState(5);
  const [reviewContent, setReviewContent] = useState('');
  const [submittedNotice, setSubmittedNotice] = useState(false);

  const approvedReviews = reviews.filter(r => r.approved);

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authorName.trim() || !reviewContent.trim()) return;

    createReview({
      customerName: authorName.trim(),
      photoUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80',
      vehiclePurchased: vehicleBought.trim() || 'Verified Purchase',
      rating: starCount,
      reviewText: reviewContent.trim(),
      approved: true, // auto-approve for preview, can be toggled in admin
      featured: false,
      isGoogleReview: false,
    });

    setSubmittedNotice(true);
    setTimeout(() => {
      setSubmittedNotice(false);
      setIsWriteReviewOpen(false);
      setAuthorName('');
      setVehicleBought('');
      setReviewContent('');
    }, 2000);
  };

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-14">
          <div>
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
              Real Customer Stories
            </span>
            <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
              What Our Customers Say
            </h2>
            <p className="text-base text-slate-400 mt-2 max-w-xl">
              Verified experiences from individual vehicle owners, families, and commercial fleet operators.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsWriteReviewOpen(true)}
              className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-600 text-xs sm:text-sm font-bold text-slate-200 hover:text-white transition flex items-center gap-2"
            >
              <PlusCircle className="w-4 h-4 text-amber-400" />
              <span>Write a Review</span>
            </button>

            <a
              href="https://google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-xs sm:text-sm font-bold text-slate-950 transition flex items-center gap-1.5 shadow"
            >
              <span>Google 4.9 ★</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {approvedReviews.map(review => (
            <div
              key={review.id}
              className="p-6 rounded-3xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between shadow-xl"
            >
              <div>
                {/* Rating Stars */}
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-1 text-amber-400">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < review.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-700'
                        }`}
                      />
                    ))}
                  </div>
                  {review.isGoogleReview && (
                    <span className="text-[10px] font-bold text-blue-400 bg-blue-950/60 border border-blue-800 px-2 py-0.5 rounded">
                      Google Review
                    </span>
                  )}
                </div>

                <p className="text-xs sm:text-sm text-slate-300 italic leading-relaxed mb-6">
                  “{review.reviewText}”
                </p>
              </div>

              {/* Author Info */}
              <div className="flex items-center gap-3 pt-4 border-t border-slate-800/80">
                <img
                  src={review.photoUrl}
                  alt={review.customerName}
                  className="w-10 h-10 rounded-full object-cover border border-slate-700"
                  loading="lazy"
                />
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-white flex items-center gap-1">
                    <span>{review.customerName}</span>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  </h3>
                  <span className="block text-[11px] text-amber-400 font-medium truncate max-w-[170px]">
                    {review.vehiclePurchased}
                  </span>
                  <span className="block text-[10px] text-slate-500">{review.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Write a Review Modal */}
      {isWriteReviewOpen && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4"
          role="dialog"
          aria-modal="true"
          aria-labelledby="write-review-title"
        >
          <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl my-6">
            <button
              onClick={() => setIsWriteReviewOpen(false)}
              className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-950 text-slate-400 hover:text-white flex items-center justify-center"
              aria-label="Close dialog"
            >
              <X className="w-4 h-4" />
            </button>

            {submittedNotice ? (
              <div className="text-center py-8">
                <Sparkles className="w-12 h-12 text-amber-400 mx-auto mb-3" />
                <h3 className="text-xl font-bold text-white mb-2">Thank You for Your Review!</h3>
                <p className="text-sm text-slate-300">
                  Your feedback has been submitted successfully to the showroom.
                </p>
              </div>
            ) : (
              <form onSubmit={handleReviewSubmit} className="space-y-4">
                <h3 id="write-review-title" className="text-xl font-black text-white mb-1">
                  Share Your Experience
                </h3>
                <p className="text-xs text-slate-400 mb-4">
                  Help fellow automobile buyers with your transparent feedback.
                </p>

                <div>
                  <label htmlFor="review-author-name" className="block text-xs font-semibold text-slate-300 mb-1">
                    Your Name *
                  </label>
                  <input
                    id="review-author-name"
                    type="text"
                    required
                    value={authorName}
                    onChange={e => setAuthorName(e.target.value)}
                    placeholder="e.g. Ramesh Kumar"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label htmlFor="review-vehicle-bought" className="block text-xs font-semibold text-slate-300 mb-1">
                    Vehicle Purchased / Tested
                  </label>
                  <input
                    id="review-vehicle-bought"
                    type="text"
                    value={vehicleBought}
                    onChange={e => setVehicleBought(e.target.value)}
                    placeholder="e.g. Apex EV-Matrix SUV or Apex Volt S1"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">Rating</label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3, 4, 5].map(star => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setStarCount(star)}
                        className="p-1 focus:outline-none"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= starCount
                              ? 'fill-amber-400 text-amber-400'
                              : 'text-slate-700'
                          }`}
                        />
                      </button>
                    ))}
                    <span className="text-xs text-slate-400 ml-2">{starCount} out of 5 stars</span>
                  </div>
                </div>

                <div>
                  <label htmlFor="review-message-content" className="block text-xs font-semibold text-slate-300 mb-1">
                    Your Review *
                  </label>
                  <textarea
                    id="review-message-content"
                    rows={4}
                    required
                    value={reviewContent}
                    onChange={e => setReviewContent(e.target.value)}
                    placeholder="Tell us about the vehicle performance, delivery experience, staff courtesy..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 rounded-xl font-bold text-sm text-slate-950 bg-amber-400 hover:bg-amber-300 transition"
                >
                  Post Review
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
