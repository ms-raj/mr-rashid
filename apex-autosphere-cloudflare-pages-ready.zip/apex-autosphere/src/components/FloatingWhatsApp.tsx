import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import { MessageSquare, X, Send, Sparkles } from 'lucide-react';
import { generateWhatsAppUrl, generateVehicleWhatsAppMessage } from '../utils/calculator';

export const FloatingWhatsApp: React.FC = () => {
  const { settings, vehicles } = useShowroom();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedVehicleName, setSelectedVehicleName] = useState('');
  const [customQuery, setCustomQuery] = useState('');

  const handleSend = () => {
    const text = selectedVehicleName
      ? generateVehicleWhatsAppMessage(selectedVehicleName, undefined, customQuery)
      : customQuery || `Hello ${settings.name}, I would like to enquire about vehicle pricing and availability.`;

    const url = generateWhatsAppUrl(settings.whatsappNumber, text);
    window.open(url, '_blank', 'noopener,noreferrer');
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-20 sm:bottom-8 right-5 z-40">
      {/* Quick Chat Popup */}
      {isOpen && (
        <div className="mb-3 w-80 bg-slate-900 border border-slate-700/80 rounded-3xl p-5 shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-bottom-4 duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <MessageSquare className="w-4 h-4" />
              </div>
              <div>
                <span className="block text-xs font-bold text-white">Dealership WhatsApp</span>
                <span className="block text-[10px] text-emerald-400">Online • Quick Response</span>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white p-1"
              aria-label="Close WhatsApp chat popup"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="my-3 space-y-2.5">
            <p className="text-xs text-slate-300">
              Select a vehicle model or type your query below to launch instant WhatsApp chat:
            </p>

            <select
              value={selectedVehicleName}
              onChange={e => setSelectedVehicleName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-400"
            >
              <option value="">General Showroom Query</option>
              {vehicles.map(v => (
                <option key={v.id} value={v.name}>
                  {v.name}
                </option>
              ))}
            </select>

            <textarea
              rows={2}
              value={customQuery}
              onChange={e => setCustomQuery(e.target.value)}
              placeholder="e.g. Share on-road price, current discount..."
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-emerald-400 resize-none"
            />
          </div>

          <button
            onClick={handleSend}
            className="w-full py-2.5 px-3 rounded-xl font-bold text-xs text-slate-950 bg-emerald-400 hover:bg-emerald-300 transition flex items-center justify-center gap-1.5 shadow-lg shadow-emerald-400/20"
          >
            <Send className="w-3.5 h-3.5 text-slate-950" />
            <span>Open WhatsApp Chat</span>
          </button>
        </div>
      )}

      {/* Floating Action Launcher Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-2xl shadow-emerald-500/40 flex items-center justify-center transition-all transform hover:scale-110 active:scale-95 group focus:outline-none"
        aria-label="Chat on WhatsApp"
        title="Chat with Dealership on WhatsApp"
      >
        <MessageSquare className="w-7 h-7 text-white fill-white" />
      </button>
    </div>
  );
};
