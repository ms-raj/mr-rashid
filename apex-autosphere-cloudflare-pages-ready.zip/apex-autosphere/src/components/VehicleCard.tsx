import React from 'react';
import { Vehicle } from '../types';
import { useShowroom } from '../context/ShowroomContext';
import {
  formatCurrency,
  generateWhatsAppUrl,
  generateVehicleWhatsAppMessage,
} from '../utils/calculator';
import {
  Gauge,
  Zap,
  Users,
  MessageSquare,
  Eye,
  Calendar,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

export const VehicleCard: React.FC<{ vehicle: Vehicle }> = ({ vehicle }) => {
  const { setSelectedVehicle, openEnquiryModal, settings } = useShowroom();

  const whatsAppUrl = generateWhatsAppUrl(
    settings.whatsappNumber,
    generateVehicleWhatsAppMessage(vehicle.name, vehicle.price)
  );

  const getFuelBadgeColor = (fuel: string) => {
    switch (fuel) {
      case 'Electric':
        return 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30';
      case 'Hybrid':
        return 'bg-cyan-500/15 text-cyan-400 border-cyan-500/30';
      case 'CNG':
        return 'bg-blue-500/15 text-blue-400 border-blue-500/30';
      case 'Diesel':
        return 'bg-orange-500/15 text-orange-400 border-orange-500/30';
      case 'Petrol':
      default:
        return 'bg-amber-500/15 text-amber-400 border-amber-500/30';
    }
  };

  const getAvailabilityBadge = (status: string) => {
    switch (status) {
      case 'In Stock':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            In Stock
          </span>
        );
      case 'Fast Delivery':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-950/80 text-amber-300 border border-amber-500/30">
            <Sparkles className="w-3 h-3 text-amber-400" />
            Fast Delivery
          </span>
        );
      case 'Booking Open':
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-800 text-slate-300 border border-slate-700">
            Booking Open
          </span>
        );
    }
  };

  return (
    <div className="group rounded-2xl bg-slate-900 border border-slate-800 hover:border-slate-700 transition-all duration-300 overflow-hidden flex flex-col justify-between shadow-xl hover:shadow-2xl hover:shadow-amber-500/5">
      <div>
        {/* Top Image Container */}
        <div
          onClick={() => setSelectedVehicle(vehicle)}
          className="relative h-56 overflow-hidden bg-slate-950 cursor-pointer"
        >
          <img
            src={vehicle.images[0] || 'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80'}
            alt={vehicle.name}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-80" />

          {/* Top Overlays */}
          <div className="absolute top-3 left-3 flex flex-wrap gap-1.5">
            <span
              className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${getFuelBadgeColor(
                vehicle.fuelType
              )} backdrop-blur-md`}
            >
              {vehicle.fuelType}
            </span>
            {vehicle.featured && (
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-400 text-slate-950 shadow-sm">
                Featured
              </span>
            )}
          </div>

          <div className="absolute top-3 right-3">
            {getAvailabilityBadge(vehicle.availability)}
          </div>

          {/* Category Tag bottom right */}
          <div className="absolute bottom-3 left-3 text-[11px] font-semibold text-slate-300 bg-slate-950/80 px-2.5 py-0.5 rounded-md backdrop-blur-md border border-slate-800">
            {vehicle.categoryName}
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">
              {vehicle.brand}
            </span>
            <span className="text-xs text-slate-500 font-medium">
              Model {vehicle.modelYear}
            </span>
          </div>

          <h3
            onClick={() => setSelectedVehicle(vehicle)}
            className="text-lg font-bold text-white hover:text-amber-400 cursor-pointer transition-colors line-clamp-1 mb-3"
            title={vehicle.name}
          >
            {vehicle.name}
          </h3>

          {/* Key Specifications Row */}
          <div className="grid grid-cols-3 gap-2 py-3 px-3 rounded-xl bg-slate-950/60 border border-slate-800/80 mb-4 text-center">
            <div className="flex flex-col items-center">
              <span className="text-[10px] uppercase font-semibold text-slate-500 flex items-center gap-1">
                <Gauge className="w-3 h-3 text-amber-400" />
                {vehicle.fuelType === 'Electric' ? 'Range' : 'Mileage'}
              </span>
              <span className="text-xs font-bold text-slate-200 mt-0.5 truncate max-w-full">
                {vehicle.mileageOrRange.split(' ')[0]}
              </span>
            </div>

            <div className="flex flex-col items-center border-x border-slate-800">
              <span className="text-[10px] uppercase font-semibold text-slate-500 flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-400" />
                Power
              </span>
              <span className="text-xs font-bold text-slate-200 mt-0.5 truncate max-w-full">
                {vehicle.power.split(' ')[0]} {vehicle.power.includes('bhp') ? 'bhp' : vehicle.power.includes('PS') ? 'PS' : 'hp'}
              </span>
            </div>

            <div className="flex flex-col items-center">
              <span className="text-[10px] uppercase font-semibold text-slate-500 flex items-center gap-1">
                <Users className="w-3 h-3 text-amber-400" />
                Seats
              </span>
              <span className="text-xs font-bold text-slate-200 mt-0.5">
                {vehicle.seatingCapacity} Seater
              </span>
            </div>
          </div>

          {/* Price & EMI Section */}
          <div className="flex items-baseline justify-between pt-1 pb-3 border-b border-slate-800/60">
            <div>
              <span className="block text-[11px] font-medium text-slate-400">
                Starting Price
              </span>
              <span className="text-xl font-black text-white">
                {formatCurrency(vehicle.price)}
              </span>
              {vehicle.originalPrice && vehicle.originalPrice > vehicle.price && (
                <span className="text-xs text-slate-500 line-through ml-2">
                  {formatCurrency(vehicle.originalPrice)}
                </span>
              )}
            </div>

            <div className="text-right">
              <span className="block text-[10px] font-medium text-slate-400">
                EMI Starts From
              </span>
              <span className="text-xs font-bold text-emerald-400">
                {formatCurrency(vehicle.emiStarting)}/mo*
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="px-5 pb-5 pt-1 grid grid-cols-3 gap-2">
        <button
          onClick={() => setSelectedVehicle(vehicle)}
          className="col-span-1 py-2 px-2.5 rounded-xl text-xs font-bold text-slate-300 bg-slate-800 hover:bg-slate-700 hover:text-white transition flex items-center justify-center gap-1 shadow-sm"
          title="View detailed vehicle specifications"
        >
          <Eye className="w-3.5 h-3.5" />
          <span>Details</span>
        </button>

        <button
          onClick={() => openEnquiryModal(vehicle, 'Price Quote')}
          className="col-span-1 py-2 px-2.5 rounded-xl text-xs font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition flex items-center justify-center gap-1 shadow-md shadow-amber-400/10 active:scale-95"
          title="Get official on-road price quotation"
        >
          <span>Enquire</span>
        </button>

        <a
          href={whatsAppUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="col-span-1 py-2 px-2.5 rounded-xl text-xs font-bold text-emerald-300 bg-emerald-950/60 border border-emerald-800/60 hover:bg-emerald-900/60 transition flex items-center justify-center gap-1 shadow-sm"
          title="Enquire on WhatsApp"
        >
          <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
          <span>WhatsApp</span>
        </a>
      </div>
    </div>
  );
};
