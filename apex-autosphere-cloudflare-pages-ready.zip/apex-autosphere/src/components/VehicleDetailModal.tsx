import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  formatCurrency,
  generateWhatsAppUrl,
  generateVehicleWhatsAppMessage,
} from '../utils/calculator';
import {
  X,
  Phone,
  MessageSquare,
  Car,
  Tag,
  CheckCircle2,
  Gauge,
  Zap,
  BatteryCharging,
  Clock,
  ShieldCheck,
  Maximize2,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Layers,
  Award,
} from 'lucide-react';

export const VehicleDetailModal: React.FC = () => {
  const {
    selectedVehicle,
    setSelectedVehicle,
    openTestDriveModal,
    openEnquiryModal,
    settings,
  } = useShowroom();

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [selectedColor, setSelectedColor] = useState<string>('');

  if (!selectedVehicle) return null;

  const images = selectedVehicle.images && selectedVehicle.images.length > 0
    ? selectedVehicle.images
    : ['https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1200&q=80'];

  const whatsAppUrl = generateWhatsAppUrl(
    settings.whatsappNumber,
    generateVehicleWhatsAppMessage(
      selectedVehicle.name,
      selectedVehicle.price,
      selectedColor ? `Preferred Color: ${selectedColor}` : undefined
    )
  );

  const handleNextImage = () => {
    setActiveImageIndex(prev => (prev + 1) % images.length);
  };

  const handlePrevImage = () => {
    setActiveImageIndex(prev => (prev - 1 + images.length) % images.length);
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="vehicle-detail-title"
    >
      <div className="relative w-full max-w-5xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Modal Close Button */}
        <button
          onClick={() => setSelectedVehicle(null)}
          className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-slate-950/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700 flex items-center justify-center transition shadow-lg"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Scrollable Container */}
        <div className="max-h-[90vh] overflow-y-auto">
          {/* Top Hero Gallery Section */}
          <div className="relative bg-slate-950">
            {/* Main Image Display */}
            <div className="relative h-72 sm:h-96 md:h-[420px] overflow-hidden flex items-center justify-center">
              <img
                src={images[activeImageIndex]}
                alt={`${selectedVehicle.name} - view ${activeImageIndex + 1}`}
                className="w-full h-full object-cover object-center transition-all duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent opacity-60" />

              {/* Prev / Next controls */}
              {images.length > 1 && (
                <>
                  <button
                    onClick={handlePrevImage}
                    className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-slate-900/80 text-white hover:bg-amber-400 hover:text-slate-950 border border-slate-700 flex items-center justify-center transition shadow"
                    aria-label="Previous image"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleNextImage}
                    className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-slate-900/80 text-white hover:bg-amber-400 hover:text-slate-950 border border-slate-700 flex items-center justify-center transition shadow"
                    aria-label="Next image"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </>
              )}

              {/* Top Badges */}
              <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-400 text-slate-950 shadow-md">
                  {selectedVehicle.categoryName}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-slate-900/90 text-white border border-slate-700 backdrop-blur-md">
                  {selectedVehicle.fuelType}
                </span>
                <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-500/30">
                  {selectedVehicle.availability}
                </span>
              </div>
            </div>

            {/* Thumbnail Navigation Strip */}
            {images.length > 1 && (
              <div className="flex items-center gap-2 p-3 bg-slate-950 border-b border-slate-800 overflow-x-auto">
                {images.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImageIndex(idx)}
                    className={`relative w-20 h-14 rounded-lg overflow-hidden border-2 transition shrink-0 ${
                      activeImageIndex === idx
                        ? 'border-amber-400 scale-105'
                        : 'border-slate-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="thumbnail" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Details Content Container */}
          <div className="p-6 sm:p-8 space-y-8">
            {/* Header: Name, Brand, Price & Action CTAs */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider mb-1">
                  <span>{selectedVehicle.brand}</span>
                  <span>•</span>
                  <span>Model Year {selectedVehicle.modelYear}</span>
                </div>
                <h1
                  id="vehicle-detail-title"
                  className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight"
                >
                  {selectedVehicle.name}
                </h1>
                <p className="text-sm text-slate-400 mt-2 max-w-2xl">
                  {selectedVehicle.description}
                </p>
              </div>

              {/* Price & Monthly EMI Box */}
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 min-w-[280px]">
                <div className="flex items-baseline justify-between mb-1">
                  <span className="text-xs text-slate-400">Starting Ex-Showroom</span>
                  {selectedVehicle.originalPrice && selectedVehicle.originalPrice > selectedVehicle.price && (
                    <span className="text-xs text-slate-500 line-through">
                      {formatCurrency(selectedVehicle.originalPrice)}
                    </span>
                  )}
                </div>
                <div className="text-3xl font-black text-white mb-2">
                  {formatCurrency(selectedVehicle.price)}
                </div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs font-bold w-full justify-between">
                  <span>Estimated EMI</span>
                  <span>{formatCurrency(selectedVehicle.emiStarting)}/month*</span>
                </div>
              </div>
            </div>

            {/* CTAs Row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <button
                onClick={() => {
                  setSelectedVehicle(null);
                  openTestDriveModal(selectedVehicle);
                }}
                className="py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition flex items-center justify-center gap-2 shadow-lg shadow-amber-400/10 active:scale-95"
              >
                <Car className="w-4 h-4 text-slate-950" />
                <span>Book Test Drive</span>
              </button>

              <button
                onClick={() => {
                  setSelectedVehicle(null);
                  openEnquiryModal(selectedVehicle, 'Price Quote');
                }}
                className="py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-white bg-slate-800 hover:bg-slate-700 transition flex items-center justify-center gap-2 border border-slate-700"
              >
                <Tag className="w-4 h-4 text-amber-400" />
                <span>Get On-Road Price</span>
              </button>

              <a
                href={whatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-emerald-300 bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 transition flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4 text-emerald-400" />
                <span>WhatsApp Enquiry</span>
              </a>

              <a
                href={`tel:${settings.phone}`}
                className="py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-slate-200 bg-slate-950 hover:bg-slate-800 border border-slate-700 transition flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4 text-amber-400" />
                <span>Call Now</span>
              </a>
            </div>

            {/* Color Options (if available) */}
            {selectedVehicle.colorOptions && selectedVehicle.colorOptions.length > 0 && (
              <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
                <span className="block text-xs font-bold text-slate-300 uppercase tracking-wider mb-2">
                  Available Exterior Colors: {selectedColor || 'Select a shade'}
                </span>
                <div className="flex items-center gap-3">
                  {selectedVehicle.colorOptions.map(col => (
                    <button
                      key={col.name}
                      onClick={() => setSelectedColor(col.name)}
                      className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-medium transition ${
                        selectedColor === col.name
                          ? 'border-amber-400 bg-amber-400/10 text-white'
                          : 'border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <span
                        className="w-4 h-4 rounded-full border border-slate-600 shrink-0"
                        style={{ backgroundColor: col.hex }}
                      />
                      <span>{col.name}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Vehicle Specifications Grid */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Gauge className="w-5 h-5 text-amber-400" />
                  <span>Technical Specifications</span>
                </h3>
                <span className="text-xs text-slate-500">Official Factory Specifications</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {/* Engine / Motor */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <span className="block text-[11px] font-semibold text-slate-400">
                    Engine / Motor
                  </span>
                  <span className="block text-sm font-bold text-white mt-0.5">
                    {selectedVehicle.engineOrMotor}
                  </span>
                </div>

                {/* Power */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <span className="block text-[11px] font-semibold text-slate-400">Max Power</span>
                  <span className="block text-sm font-bold text-white mt-0.5">
                    {selectedVehicle.power}
                  </span>
                </div>

                {/* Torque */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <span className="block text-[11px] font-semibold text-slate-400">Max Torque</span>
                  <span className="block text-sm font-bold text-white mt-0.5">
                    {selectedVehicle.torque}
                  </span>
                </div>

                {/* Mileage or Range */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <span className="block text-[11px] font-semibold text-slate-400">
                    {selectedVehicle.fuelType === 'Electric' ? 'Certified Range' : 'Fuel Mileage'}
                  </span>
                  <span className="block text-sm font-bold text-emerald-400 mt-0.5">
                    {selectedVehicle.mileageOrRange}
                  </span>
                </div>

                {/* Fuel Type */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <span className="block text-[11px] font-semibold text-slate-400">Fuel Type</span>
                  <span className="block text-sm font-bold text-white mt-0.5">
                    {selectedVehicle.fuelType}
                  </span>
                </div>

                {/* Transmission */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <span className="block text-[11px] font-semibold text-slate-400">Transmission</span>
                  <span className="block text-sm font-bold text-white mt-0.5">
                    {selectedVehicle.transmission}
                  </span>
                </div>

                {/* Seating Capacity */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <span className="block text-[11px] font-semibold text-slate-400">
                    Seating Capacity
                  </span>
                  <span className="block text-sm font-bold text-white mt-0.5">
                    {selectedVehicle.seatingCapacity} Persons
                  </span>
                </div>

                {/* Battery Capacity (only if EV/Hybrid) */}
                {selectedVehicle.batteryCapacity && (
                  <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                    <span className="block text-[11px] font-semibold text-slate-400">
                      Battery Capacity
                    </span>
                    <span className="block text-sm font-bold text-emerald-400 mt-0.5">
                      {selectedVehicle.batteryCapacity}
                    </span>
                  </div>
                )}

                {/* Charging Time (only if EV/Hybrid) */}
                {selectedVehicle.chargingTime && (
                  <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                    <span className="block text-[11px] font-semibold text-slate-400">
                      Charging Time
                    </span>
                    <span className="block text-sm font-bold text-white mt-0.5">
                      {selectedVehicle.chargingTime}
                    </span>
                  </div>
                )}

                {/* Top Speed */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <span className="block text-[11px] font-semibold text-slate-400">Top Speed</span>
                  <span className="block text-sm font-bold text-white mt-0.5">
                    {selectedVehicle.topSpeed}
                  </span>
                </div>

                {/* Ground Clearance */}
                {selectedVehicle.groundClearance && (
                  <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                    <span className="block text-[11px] font-semibold text-slate-400">
                      Ground Clearance
                    </span>
                    <span className="block text-sm font-bold text-white mt-0.5">
                      {selectedVehicle.groundClearance}
                    </span>
                  </div>
                )}

                {/* Dimensions */}
                {selectedVehicle.dimensions && (
                  <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                    <span className="block text-[11px] font-semibold text-slate-400">Dimensions</span>
                    <span className="block text-sm font-bold text-white mt-0.5">
                      {selectedVehicle.dimensions}
                    </span>
                  </div>
                )}

                {/* Warranty */}
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <span className="block text-[11px] font-semibold text-slate-400">
                    Manufacturer Warranty
                  </span>
                  <span className="block text-sm font-bold text-amber-400 mt-0.5">
                    {selectedVehicle.warranty}
                  </span>
                </div>
              </div>
            </div>

            {/* Vehicle Features */}
            {selectedVehicle.features && selectedVehicle.features.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-white flex items-center gap-2 mb-4">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <span>Key Features & Technology</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {selectedVehicle.features.map((feature, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2.5 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span className="text-xs sm:text-sm text-slate-200">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
