import React from 'react';
import { useShowroom } from '../context/ShowroomContext';
import { Phone, MessageSquare, Car, MapPin } from 'lucide-react';
import { generateWhatsAppUrl } from '../utils/calculator';

export const MobileStickyBar: React.FC = () => {
  const { settings, openTestDriveModal, setActiveTab } = useShowroom();

  const whatsAppUrl = generateWhatsAppUrl(
    settings.whatsappNumber,
    `Hello ${settings.name}, I would like to enquire about vehicle pricing and availability.`
  );

  return (
    <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-xl border-t border-slate-800 px-3 py-2 shadow-2xl">
      <div className="grid grid-cols-4 gap-2 text-center">
        {/* 1. Call */}
        <a
          href={`tel:${settings.phone}`}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl text-slate-300 hover:text-white hover:bg-slate-900 transition"
        >
          <Phone className="w-5 h-5 text-amber-400 mb-0.5" />
          <span className="text-[10px] font-bold">Call</span>
        </a>

        {/* 2. WhatsApp */}
        <a
          href={whatsAppUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl text-slate-300 hover:text-white hover:bg-slate-900 transition"
        >
          <MessageSquare className="w-5 h-5 text-emerald-400 mb-0.5" />
          <span className="text-[10px] font-bold">WhatsApp</span>
        </a>

        {/* 3. Test Drive */}
        <button
          onClick={() => openTestDriveModal()}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl bg-amber-400/10 text-amber-300 border border-amber-400/30 transition"
        >
          <Car className="w-5 h-5 text-amber-400 mb-0.5" />
          <span className="text-[10px] font-black">Test Drive</span>
        </button>

        {/* 4. Location */}
        <button
          onClick={() => {
            setActiveTab('contact');
            const locEl = document.getElementById('showroom-location');
            if (locEl) locEl.scrollIntoView({ behavior: 'smooth' });
          }}
          className="flex flex-col items-center justify-center py-1.5 px-1 rounded-xl text-slate-300 hover:text-white hover:bg-slate-900 transition"
        >
          <MapPin className="w-5 h-5 text-amber-400 mb-0.5" />
          <span className="text-[10px] font-bold">Location</span>
        </button>
      </div>
    </div>
  );
};
