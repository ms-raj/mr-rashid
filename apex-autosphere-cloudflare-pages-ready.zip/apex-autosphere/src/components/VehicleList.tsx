import React, { useState, useMemo } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import { VehicleCard } from './VehicleCard';
import { filterVehicles, getAvailableBrands, VehicleFilterOptions } from '../utils/filter';
import {
  Search,
  SlidersHorizontal,
  RotateCcw,
  Car,
  Filter,
  Check,
  ChevronDown,
  Sparkles,
} from 'lucide-react';

export const VehicleList: React.FC<{ initialFilters?: Partial<VehicleFilterOptions> }> = ({
  initialFilters = {},
}) => {
  const { vehicles, categories, activeCategoryFilter, setActiveCategoryFilter } = useShowroom();

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>(
    activeCategoryFilter || initialFilters.categoryId || 'all'
  );
  const [selectedFuel, setSelectedFuel] = useState<string>(initialFilters.fuelType || 'all');
  const [selectedBrand, setSelectedBrand] = useState<string>(initialFilters.brand || 'all');
  const [selectedTransmission, setSelectedTransmission] = useState<string>('all');
  const [selectedAvailability, setSelectedAvailability] = useState<string>('all');
  const [selectedSeating, setSelectedSeating] = useState<number>(0);
  const [priceRange, setPriceRange] = useState<number>(3500000);
  const [sortBy, setSortBy] = useState<'featured' | 'price-low' | 'price-high' | 'name-asc' | 'model-year'>('featured');
  const [showMobileFilters, setShowMobileFilters] = useState(false);

  // Sync with context category if it changes externally
  React.useEffect(() => {
    if (activeCategoryFilter) {
      setSelectedCategory(activeCategoryFilter);
    }
  }, [activeCategoryFilter]);

  const brands = useMemo(() => getAvailableBrands(vehicles), [vehicles]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setActiveCategoryFilter('all');
    setSelectedFuel('all');
    setSelectedBrand('all');
    setSelectedTransmission('all');
    setSelectedAvailability('all');
    setSelectedSeating(0);
    setPriceRange(3500000);
    setSortBy('featured');
  };

  const filteredVehicles = useMemo(() => {
    const options: VehicleFilterOptions = {
      categoryId: selectedCategory !== 'all' ? selectedCategory : undefined,
      fuelType: selectedFuel !== 'all' ? selectedFuel : undefined,
      brand: selectedBrand !== 'all' ? selectedBrand : undefined,
      transmission: selectedTransmission !== 'all' ? selectedTransmission : undefined,
      availability: selectedAvailability !== 'all' ? selectedAvailability : undefined,
      seatingCapacity: selectedSeating > 0 ? selectedSeating : undefined,
      maxPrice: priceRange < 3500000 ? priceRange : undefined,
      searchQuery,
      sortBy,
    };
    return filterVehicles(vehicles, options);
  }, [
    vehicles,
    selectedCategory,
    selectedFuel,
    selectedBrand,
    selectedTransmission,
    selectedAvailability,
    selectedSeating,
    priceRange,
    searchQuery,
    sortBy,
  ]);

  return (
    <section className="py-12 bg-slate-950 text-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Title Header */}
        <div className="mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            Showroom Inventory Catalog
          </div>
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <h1 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                Find Your Perfect Vehicle
              </h1>
              <p className="text-slate-400 text-sm sm:text-base mt-1">
                Filter by segment, fuel type, transmission, seating, and budget across all models.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => setShowMobileFilters(!showMobileFilters)}
                className="lg:hidden flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-sm font-semibold text-slate-200"
              >
                <SlidersHorizontal className="w-4 h-4 text-amber-400" />
                <span>Filters</span>
              </button>
            </div>
          </div>
        </div>

        {/* Quick Category Badges Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-6 scrollbar-none">
          <button
            onClick={() => {
              setSelectedCategory('all');
              setActiveCategoryFilter('all');
            }}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition ${
              selectedCategory === 'all'
                ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
            }`}
          >
            All Vehicles ({vehicles.filter(v => v.published).length})
          </button>
          {categories.map(cat => {
            const count = vehicles.filter(v => v.categoryId === cat.id && v.published).length;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => {
                  setSelectedCategory(cat.id);
                  setActiveCategoryFilter(cat.id);
                }}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition ${
                  isSelected
                    ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {cat.name} ({count})
              </button>
            );
          })}
        </div>

        {/* Search & Filter Control Bar */}
        <div
          className={`bg-slate-900/90 border border-slate-800 rounded-2xl p-5 mb-8 shadow-xl ${
            showMobileFilters ? 'block' : 'hidden lg:block'
          }`}
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            {/* Search Input */}
            <div className="sm:col-span-2 relative">
              <label htmlFor="catalog-search-input" className="block text-xs font-semibold text-slate-400 mb-1">
                Search Model or Keywords
              </label>
              <div className="relative">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  id="catalog-search-input"
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="e.g. Grandeur, EV, 4x4, Titan, Rickshaw..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 transition"
                />
              </div>
            </div>

            {/* Fuel Type */}
            <div>
              <label htmlFor="catalog-fuel-filter" className="block text-xs font-semibold text-slate-400 mb-1">
                Fuel Type
              </label>
              <select
                id="catalog-fuel-filter"
                value={selectedFuel}
                onChange={e => setSelectedFuel(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
              >
                <option value="all">All Fuels</option>
                <option value="Electric">⚡ Electric (EV)</option>
                <option value="Petrol">Petrol</option>
                <option value="Diesel">Diesel</option>
                <option value="CNG">CNG / Bi-Fuel</option>
                <option value="Hybrid">Hybrid</option>
              </select>
            </div>

            {/* Brand Filter */}
            <div>
              <label htmlFor="catalog-brand-filter" className="block text-xs font-semibold text-slate-400 mb-1">
                Brand
              </label>
              <select
                id="catalog-brand-filter"
                value={selectedBrand}
                onChange={e => setSelectedBrand(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
              >
                <option value="all">All Brands</option>
                {brands.map(b => (
                  <option key={b} value={b}>
                    {b}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-3 border-t border-slate-800/80 items-end">
            {/* Transmission */}
            <div>
              <label htmlFor="catalog-trans-filter" className="block text-xs font-semibold text-slate-400 mb-1">
                Transmission
              </label>
              <select
                id="catalog-trans-filter"
                value={selectedTransmission}
                onChange={e => setSelectedTransmission(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
              >
                <option value="all">Any Transmission</option>
                <option value="Manual">Manual</option>
                <option value="Automatic">Automatic</option>
                <option value="Direct Drive">Direct Drive (EV)</option>
                <option value="e-CVT">e-CVT Hybrid</option>
              </select>
            </div>

            {/* Seating Capacity */}
            <div>
              <label htmlFor="catalog-seating-filter" className="block text-xs font-semibold text-slate-400 mb-1">
                Minimum Seating
              </label>
              <select
                id="catalog-seating-filter"
                value={selectedSeating}
                onChange={e => setSelectedSeating(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
              >
                <option value="0">Any Seating</option>
                <option value="2">2+ Seater</option>
                <option value="4">4+ Seater</option>
                <option value="5">5+ Seater</option>
                <option value="7">7+ Seater</option>
              </select>
            </div>

            {/* Sort By */}
            <div>
              <label htmlFor="catalog-sort-filter" className="block text-xs font-semibold text-slate-400 mb-1">
                Sort By
              </label>
              <select
                id="catalog-sort-filter"
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
              >
                <option value="featured">Featured First</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="name-asc">Vehicle Name (A-Z)</option>
                <option value="model-year">Latest Model Year</option>
              </select>
            </div>

            {/* Reset Filter Button */}
            <div>
              <button
                onClick={handleResetFilters}
                className="w-full py-2 px-4 rounded-xl text-xs font-bold text-slate-400 hover:text-white bg-slate-950 hover:bg-slate-800 border border-slate-800 flex items-center justify-center gap-1.5 transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset All Filters</span>
              </button>
            </div>
          </div>
        </div>

        {/* Results Counter */}
        <div className="flex items-center justify-between mb-6">
          <span className="text-sm font-semibold text-slate-300">
            Showing <strong className="text-white">{filteredVehicles.length}</strong> vehicles in showroom
          </span>
          {filteredVehicles.length > 0 && (
            <span className="text-xs text-slate-500">
              Prices shown are starting ex-showroom estimates
            </span>
          )}
        </div>

        {/* Vehicle Cards Grid */}
        {filteredVehicles.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredVehicles.map(vehicle => (
              <VehicleCard key={vehicle.id} vehicle={vehicle} />
            ))}
          </div>
        ) : (
          <div className="rounded-2xl bg-slate-900 border border-slate-800 p-12 text-center max-w-lg mx-auto">
            <div className="w-16 h-16 rounded-full bg-slate-800 flex items-center justify-center mx-auto mb-4 text-slate-400">
              <Car className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2">
              No Vehicles Found
            </h3>
            <p className="text-sm text-slate-400 mb-6">
              We couldn't find any vehicles matching your current filter criteria. Try resetting or adjusting the filters.
            </p>
            <button
              onClick={handleResetFilters}
              className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-sm transition"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
