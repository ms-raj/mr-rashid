import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  Sparkles,
  Calendar,
  Tag,
  ArrowRight,
  Gift,
  CheckCircle2,
  Clock,
} from 'lucide-react';

export const OffersSection: React.FC = () => {
  const { offers, openEnquiryModal } = useShowroom();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const categories = [
    'all',
    'Festival Offers',
    'Exchange Offers',
    'Finance Offers',
    'EV Offers',
  ];

  const filteredOffers = offers.filter(offer => {
    if (!offer.published) return false;
    if (selectedCategory === 'all') return true;
    return offer.category === selectedCategory;
  });

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
            Exclusive Deals & Promotions
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
            Special Showroom Offers
          </h2>
          <p className="text-base sm:text-lg text-slate-400">
            Take advantage of limited-period festive discounts, exchange bonuses, and special subsidised interest rates.
          </p>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto pb-4 mb-10 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold capitalize whitespace-nowrap transition ${
                selectedCategory === cat
                  ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                  : 'bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800'
              }`}
            >
              {cat === 'all' ? 'All Offers' : cat}
            </button>
          ))}
        </div>

        {/* Offer Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredOffers.map(offer => (
            <div
              key={offer.id}
              className="group rounded-3xl bg-slate-900 border border-slate-800 hover:border-amber-500/50 transition-all duration-300 overflow-hidden flex flex-col justify-between shadow-2xl"
            >
              <div>
                {/* Banner Image */}
                <div className="relative h-56 overflow-hidden bg-slate-950">
                  <img
                    src={offer.bannerUrl}
                    alt={offer.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />

                  {/* Badge */}
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 rounded-full text-xs font-black bg-amber-400 text-slate-950 shadow-lg">
                      {offer.badge}
                    </span>
                  </div>

                  <div className="absolute top-4 right-4">
                    <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-slate-900/80 text-slate-300 backdrop-blur-md border border-slate-700">
                      {offer.category}
                    </span>
                  </div>
                </div>

                {/* Offer Content */}
                <div className="p-6 sm:p-8">
                  <h3 className="text-xl sm:text-2xl font-black text-white group-hover:text-amber-400 transition-colors mb-2">
                    {offer.title}
                  </h3>

                  <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-500/20 px-3 py-1 rounded-lg mb-4">
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>{offer.discountText}</span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                    {offer.description}
                  </p>

                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span className="font-semibold">{offer.validityDate}</span>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="px-6 sm:px-8 pb-6 sm:pb-8 pt-0">
                <button
                  onClick={() => openEnquiryModal(null, 'Offer')}
                  className="w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition shadow-md shadow-amber-400/10 flex items-center justify-center gap-2"
                >
                  <Tag className="w-4 h-4 text-slate-950" />
                  <span>Enquire About Offer</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
