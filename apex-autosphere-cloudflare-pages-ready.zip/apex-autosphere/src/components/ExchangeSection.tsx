import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import { calculateExchangeValuation, formatCurrency } from '../utils/calculator';
import {
  RefreshCw,
  Car,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';

export const ExchangeSection: React.FC = () => {
  const { vehicles, createLead } = useShowroom();

  const [customerName, setCustomerName] = useState('');
  const [mobile, setMobile] = useState('');
  const [existingMake, setExistingMake] = useState('');
  const [existingModel, setExistingModel] = useState('');
  const [regYear, setRegYear] = useState('2020');
  const [condition, setCondition] = useState<'Fair' | 'Good' | 'Excellent'>('Good');
  const [approxOriginalPrice, setApproxOriginalPrice] = useState<number>(600000);
  const [preferredVehicleId, setPreferredVehicleId] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const currentYear = 2026;
  const vehicleAge = Math.max(0, currentYear - Number(regYear));
  const estimatedValuation = calculateExchangeValuation(
    approxOriginalPrice,
    vehicleAge,
    condition
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!customerName.trim() || !mobile.trim() || !existingMake.trim() || !existingModel.trim()) {
      setErrorMsg('Please enter your name, mobile, and vehicle make/model details.');
      return;
    }

    const preferredVehicle = vehicles.find(v => v.id === preferredVehicleId);

    createLead({
      customerName: customerName.trim(),
      mobile: mobile.trim(),
      email: '',
      vehicleId: preferredVehicleId || undefined,
      vehicleName: preferredVehicle ? preferredVehicle.name : undefined,
      enquiryType: 'Exchange',
      message: `Exchange Evaluation Request: Existing ${existingMake} ${existingModel} (${regYear}, condition: ${condition}). Estimated Trade-in Value: ${formatCurrency(
        estimatedValuation
      )}. Interested in new vehicle: ${preferredVehicle ? preferredVehicle.name : 'Not yet selected'}.`,
    });

    setIsSubmitted(true);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setCustomerName('');
    setMobile('');
    setExistingMake('');
    setExistingModel('');
  };

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Column: Heading, Value Proposition & Live Valuation Preview */}
          <div className="lg:col-span-5 space-y-6">
            <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block">
              Vehicle Trade-In Program
            </span>

            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              Upgrade Your Ride
            </h2>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed">
              Bring your existing vehicle and explore exchange opportunities for your next vehicle.
              Get competitive spot valuation, transparent pricing, and instant exchange bonus deductions.
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <span className="text-xs sm:text-sm text-slate-200">
                  Any brand, model, or year accepted (Bikes, Cars, Commercial)
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                  <Sparkles className="w-4 h-4" />
                </div>
                <span className="text-xs sm:text-sm text-slate-200">
                  Up to ₹40,000 extra exchange bonus over market price
                </span>
              </div>

              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
                  <ShieldCheck className="w-4 h-4" />
                </div>
                <span className="text-xs sm:text-sm text-slate-200">
                  Hassle-free RTO transfer and ownership name change guarantee
                </span>
              </div>
            </div>

            {/* Live Instant Valuation Card */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 mt-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs uppercase font-bold text-slate-400 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                  Estimated Trade-In Value
                </span>
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                  + ₹40,000 Bonus
                </span>
              </div>
              <div className="text-3xl font-black text-white mb-1">
                {formatCurrency(estimatedValuation)}*
              </div>
              <p className="text-[11px] text-slate-500">
                * Based on {regYear} model in {condition.toLowerCase()} condition. Final inspection takes just 15 minutes at showroom.
              </p>
            </div>
          </div>

          {/* Right Column: Interactive Evaluation Form */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
            {isSubmitted ? (
              <div className="text-center py-10">
                <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto mb-4 text-emerald-400">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-black text-white mb-2">
                  Exchange Evaluation Requested!
                </h3>
                <p className="text-sm text-slate-300 max-w-md mx-auto mb-6">
                  Thank you, <strong>{customerName}</strong>. Our certified automotive evaluation specialist will call you at <strong>{mobile}</strong> to schedule a complimentary vehicle inspection.
                </p>
                <button
                  onClick={handleReset}
                  className="px-6 py-2.5 rounded-xl text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 transition"
                >
                  Submit Another Request
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <h3 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
                  <RefreshCw className="w-5 h-5 text-amber-400" />
                  <span>Request Exchange Evaluation</span>
                </h3>

                {errorMsg && (
                  <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs">
                    {errorMsg}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="exchange-name" className="block text-xs font-semibold text-slate-300 mb-1">
                      Your Name *
                    </label>
                    <input
                      id="exchange-name"
                      type="text"
                      required
                      value={customerName}
                      onChange={e => setCustomerName(e.target.value)}
                      placeholder="e.g. Amit Kapoor"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>

                  <div>
                    <label htmlFor="exchange-mobile" className="block text-xs font-semibold text-slate-300 mb-1">
                      Mobile Number *
                    </label>
                    <input
                      id="exchange-mobile"
                      type="tel"
                      required
                      value={mobile}
                      onChange={e => setMobile(e.target.value)}
                      placeholder="e.g. +91 98765 43210"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="exchange-make" className="block text-xs font-semibold text-slate-300 mb-1">
                      Existing Vehicle Make / Brand *
                    </label>
                    <input
                      id="exchange-make"
                      type="text"
                      required
                      value={existingMake}
                      onChange={e => setExistingMake(e.target.value)}
                      placeholder="e.g. Maruti, Honda, Royal Enfield, Tata..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>

                  <div>
                    <label htmlFor="exchange-model" className="block text-xs font-semibold text-slate-300 mb-1">
                      Existing Vehicle Model *
                    </label>
                    <input
                      id="exchange-model"
                      type="text"
                      required
                      value={existingModel}
                      onChange={e => setExistingModel(e.target.value)}
                      placeholder="e.g. Swift, City, Classic 350, Ace..."
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="exchange-regyear" className="block text-xs font-semibold text-slate-300 mb-1">
                      Registration Year
                    </label>
                    <select
                      id="exchange-regyear"
                      value={regYear}
                      onChange={e => setRegYear(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
                    >
                      {[2025, 2024, 2023, 2022, 2021, 2020, 2019, 2018, 2017, 2016, 2015, 2014, 2012, 2010].map(
                        yr => (
                          <option key={yr} value={yr}>
                            {yr}
                          </option>
                        )
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Vehicle Condition
                    </label>
                    <div className="grid grid-cols-3 gap-1.5">
                      {(['Fair', 'Good', 'Excellent'] as const).map(cond => (
                        <button
                          key={cond}
                          type="button"
                          onClick={() => setCondition(cond)}
                          className={`py-2 rounded-xl text-xs font-bold transition border ${
                            condition === cond
                              ? 'bg-amber-400 text-slate-950 border-amber-400 shadow-sm'
                              : 'bg-slate-950 text-slate-300 border-slate-800'
                          }`}
                        >
                          {cond}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <label htmlFor="exchange-preferred-vehicle" className="block text-xs font-semibold text-slate-300 mb-1">
                    Preferred New Showroom Vehicle
                  </label>
                  <select
                    id="exchange-preferred-vehicle"
                    value={preferredVehicleId}
                    onChange={e => setPreferredVehicleId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
                  >
                    <option value="">Select your target new vehicle...</option>
                    {vehicles.map(v => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.categoryName} - {formatCurrency(v.price)})
                      </option>
                    ))}
                  </select>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl font-bold text-sm text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 transition shadow-lg shadow-amber-400/20 active:scale-98 mt-2"
                >
                  Request Exchange Evaluation
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
