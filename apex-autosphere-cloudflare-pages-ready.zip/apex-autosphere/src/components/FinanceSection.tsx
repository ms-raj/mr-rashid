import React from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  CreditCard,
  Clock,
  FileCheck,
  ShieldCheck,
  ArrowRight,
  Landmark,
  BadgePercent,
  CheckCircle2,
} from 'lucide-react';

export const FinanceSection: React.FC = () => {
  const { openEnquiryModal } = useShowroom();

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
            Financial Advisory
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
            Easy Finance Options
          </h2>
          <p className="text-base sm:text-lg text-slate-400">
            Make your vehicle purchase easier with convenient finance assistance.
          </p>
        </div>

        {/* 4 Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* Card 1: Flexible Tenure */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition-all group">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mb-5 group-hover:scale-110 transition-transform">
              <Clock className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
              Flexible Tenure
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Choose loan repayment terms from 12 months up to 84 months customized around your monthly cash flow.
            </p>
          </div>

          {/* Card 2: Down Payment Assistance */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition-all group">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mb-5 group-hover:scale-110 transition-transform">
              <CreditCard className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
              Down Payment Assistance
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Explore minimal upfront payment plans, special festive finance schemes, and flexible deposit options.
            </p>
          </div>

          {/* Card 3: Finance Guidance */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition-all group">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mb-5 group-hover:scale-110 transition-transform">
              <BadgePercent className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
              Finance Guidance
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Compare interest rate slabs across 15+ leading partnered banks and NBFCs with unbiased expert advisory.
            </p>
          </div>

          {/* Card 4: Documentation Support */}
          <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition-all group">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 mb-5 group-hover:scale-110 transition-transform">
              <FileCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white mb-2 group-hover:text-amber-400 transition-colors">
              Documentation Support
            </h3>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              Enjoy door-to-door documentation pickup, fast digital verification, and minimal paperwork hassle.
            </p>
          </div>
        </div>

        {/* Partner Banks Strip & CTA */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Landmark className="w-5 h-5 text-amber-400" />
              <h4 className="text-base sm:text-lg font-bold text-white">
                Tie-ups with Top Lending Institutions
              </h4>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 max-w-xl">
              HDFC Bank, ICICI Bank, SBI, Axis Bank, Kotak Mahindra, Tata Capital, Bajaj Finserv & leading nationalized banks.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
            <button
              onClick={() => openEnquiryModal(null, 'Finance')}
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl font-bold text-sm text-slate-950 bg-amber-400 hover:bg-amber-300 transition shadow-lg shadow-amber-400/20 flex items-center justify-center gap-2"
            >
              <span>Check Finance Options</span>
              <ArrowRight className="w-4 h-4 text-slate-950" />
            </button>
          </div>
        </div>

        {/* Disclaimer */}
        <p className="text-center text-xs text-slate-500 mt-6">
          * Final loan terms, interest rates, and processing conditions are subject to lender approval and credit evaluation.
        </p>
      </div>
    </section>
  );
};
