import React from 'react';
import {
  Layers,
  FileText,
  BadgeDollarSign,
  CreditCard,
  Headphones,
  HeartHandshake,
} from 'lucide-react';

export const WhyChooseUs: React.FC = () => {
  const pillars = [
    {
      title: 'Wide Vehicle Selection',
      desc: 'Multiple vehicle categories in one showroom: bikes, scooters, executive cars, 4x4 SUVs, e-rickshaws, and commercial haulers.',
      icon: <Layers className="w-6 h-6 text-amber-400" />,
    },
    {
      title: 'Transparent Information',
      desc: 'Clear vehicle details and pricing information with zero hidden charges or unexpected documentation surprises.',
      icon: <FileText className="w-6 h-6 text-amber-400" />,
    },
    {
      title: 'Competitive Pricing',
      desc: 'Attractive pricing and offers guaranteed with direct manufacturer tie-ups and volume procurement benefits.',
      icon: <BadgeDollarSign className="w-6 h-6 text-amber-400" />,
    },
    {
      title: 'Easy Finance Assistance',
      desc: 'Support throughout the finance process from pre-approval to final vehicle registration with 15+ trusted banks.',
      icon: <CreditCard className="w-6 h-6 text-amber-400" />,
    },
    {
      title: 'Professional Support',
      desc: 'Customer assistance before and after purchase led by factory-certified product specialists and technical advisors.',
      icon: <Headphones className="w-6 h-6 text-amber-400" />,
    },
    {
      title: 'Customer First',
      desc: 'Focused on a smooth buying experience with doorstep test drives, transparent trade-in quotes, and VIP handover ceremonies.',
      icon: <HeartHandshake className="w-6 h-6 text-amber-400" />,
    },
  ];

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
            Dealership Trust & Excellence
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
            Why Choose Apex AutoSphere
          </h2>
          <p className="text-base sm:text-lg text-slate-400">
            A customer-centric automobile showroom dedicated to honesty, variety, and lasting relationship value.
          </p>
        </div>

        {/* 6 Premium Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pillars.map((pillar, idx) => (
            <div
              key={idx}
              className="group p-6 sm:p-8 rounded-3xl bg-slate-900 border border-slate-800 hover:border-amber-500/40 transition-all duration-300 shadow-xl"
            >
              <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                {pillar.icon}
              </div>
              <h3 className="text-xl font-bold text-white group-hover:text-amber-400 transition-colors mb-2.5">
                {pillar.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                {pillar.desc}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
