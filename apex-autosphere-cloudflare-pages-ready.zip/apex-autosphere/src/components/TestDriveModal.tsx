import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  X,
  Car,
  Calendar,
  Clock,
  MapPin,
  CheckCircle2,
  Phone,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { generateWhatsAppUrl } from '../utils/calculator';

export const TestDriveModal: React.FC = () => {
  const {
    isTestDriveModalOpen,
    closeTestDriveModal,
    testDriveVehicle,
    vehicles,
    createTestDrive,
    settings,
  } = useShowroom();

  const [fullName, setFullName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [selectedVehicleId, setSelectedVehicleId] = useState(testDriveVehicle?.id || '');
  const [preferredDate, setPreferredDate] = useState('');
  const [preferredTime, setPreferredTime] = useState('11:00 AM');
  const [locationType, setLocationType] = useState<'Showroom' | 'Doorstep'>('Showroom');
  const [doorstepAddress, setDoorstepAddress] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Sync default selected vehicle if passed
  React.useEffect(() => {
    if (testDriveVehicle) {
      setSelectedVehicleId(testDriveVehicle.id);
    } else if (vehicles.length > 0 && !selectedVehicleId) {
      setSelectedVehicleId(vehicles[0].id);
    }
  }, [testDriveVehicle, vehicles]);

  if (!isTestDriveModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!fullName.trim() || !mobile.trim()) {
      setErrorMsg('Please enter your full name and mobile number.');
      return;
    }

    const vehicleObj = vehicles.find(v => v.id === selectedVehicleId);
    const vehicleName = vehicleObj ? vehicleObj.name : 'General Test Drive';

    createTestDrive({
      customerName: fullName.trim(),
      mobile: mobile.trim(),
      email: email.trim(),
      vehicleId: selectedVehicleId,
      vehicleName,
      preferredDate: preferredDate || new Date().toISOString().split('T')[0],
      preferredTime,
      locationType,
      address: locationType === 'Doorstep' ? doorstepAddress : undefined,
      message: message.trim(),
    });

    setIsSubmitted(true);
  };

  const handleResetAndClose = () => {
    setIsSubmitted(false);
    setFullName('');
    setMobile('');
    setEmail('');
    setMessage('');
    closeTestDriveModal();
  };

  const selectedVehicleObj = vehicles.find(v => v.id === selectedVehicleId);

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-6"
      role="dialog"
      aria-modal="true"
      aria-labelledby="test-drive-title"
    >
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700/80 rounded-3xl shadow-2xl overflow-hidden my-6">
        {/* Close Button */}
        <button
          onClick={handleResetAndClose}
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-slate-950/80 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-700 flex items-center justify-center transition shadow"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        {isSubmitted ? (
          /* Success Screen */
          <div className="p-8 sm:p-10 text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto mb-4 text-emerald-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <h3 className="text-2xl font-black text-white mb-3">
              Booking Received!
            </h3>

            <p className="text-sm sm:text-base text-slate-300 mb-6 leading-relaxed">
              “Thank you! Your test-drive request has been received. Our team will contact you shortly.”
            </p>

            <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 text-left text-xs space-y-2 mb-6">
              <div className="flex justify-between">
                <span className="text-slate-500">Vehicle:</span>
                <span className="font-bold text-white">
                  {selectedVehicleObj?.name || 'Selected Vehicle'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Scheduled Date & Time:</span>
                <span className="font-bold text-white">
                  {preferredDate || 'Tomorrow'} at {preferredTime}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Test Drive Location:</span>
                <span className="font-bold text-amber-400">{locationType}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href={generateWhatsAppUrl(
                  settings.whatsappNumber,
                  `Hello ${settings.name}, I just submitted a test drive request for ${selectedVehicleObj?.name || 'a vehicle'} on ${preferredDate} at ${preferredTime}.`
                )}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-emerald-300 bg-emerald-950/80 border border-emerald-800 flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Confirm on WhatsApp</span>
              </a>

              <button
                onClick={handleResetAndClose}
                className="w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          /* Form Screen */
          <div className="p-6 sm:p-8">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Complimentary Drive Experience</span>
            </div>

            <h2 id="test-drive-title" className="text-2xl sm:text-3xl font-black text-white tracking-tight mb-2">
              Experience It Before You Buy It
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mb-6">
              Book a free test drive at our air-conditioned showroom or right at your doorstep.
            </p>

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs mb-4">
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Full Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="testdrive-fullname" className="block text-xs font-semibold text-slate-300 mb-1">
                    Full Name *
                  </label>
                  <input
                    id="testdrive-fullname"
                    type="text"
                    required
                    value={fullName}
                    onChange={e => setFullName(e.target.value)}
                    placeholder="e.g. Rahul Sharma"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                  />
                </div>

                <div>
                  <label htmlFor="testdrive-mobile" className="block text-xs font-semibold text-slate-300 mb-1">
                    Mobile Number *
                  </label>
                  <input
                    id="testdrive-mobile"
                    type="tel"
                    required
                    value={mobile}
                    onChange={e => setMobile(e.target.value)}
                    placeholder="e.g. +91 98765 43210"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                  />
                </div>
              </div>

              {/* Email & Vehicle */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="testdrive-email" className="block text-xs font-semibold text-slate-300 mb-1">
                    Email Address
                  </label>
                  <input
                    id="testdrive-email"
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="e.g. rahul@example.com"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                  />
                </div>

                <div>
                  <label htmlFor="testdrive-vehicle-select" className="block text-xs font-semibold text-slate-300 mb-1">
                    Vehicle Model *
                  </label>
                  <select
                    id="testdrive-vehicle-select"
                    value={selectedVehicleId}
                    onChange={e => setSelectedVehicleId(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 transition"
                  >
                    {vehicles.map(v => (
                      <option key={v.id} value={v.id}>
                        {v.name} ({v.categoryName})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Date & Time Slot */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="testdrive-date" className="block text-xs font-semibold text-slate-300 mb-1">
                    Preferred Date
                  </label>
                  <input
                    id="testdrive-date"
                    type="date"
                    value={preferredDate}
                    onChange={e => setPreferredDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
                  />
                </div>

                <div>
                  <label htmlFor="testdrive-time" className="block text-xs font-semibold text-slate-300 mb-1">
                    Preferred Time Slot
                  </label>
                  <select
                    id="testdrive-time"
                    value={preferredTime}
                    onChange={e => setPreferredTime(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-amber-400 transition"
                  >
                    <option value="10:00 AM">10:00 AM - 12:00 PM (Morning)</option>
                    <option value="12:00 PM">12:00 PM - 02:00 PM (Noon)</option>
                    <option value="02:00 PM">02:00 PM - 04:00 PM (Afternoon)</option>
                    <option value="04:00 PM">04:00 PM - 06:30 PM (Evening)</option>
                  </select>
                </div>
              </div>

              {/* Location Preference */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Test Drive Location
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setLocationType('Showroom')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                      locationType === 'Showroom'
                        ? 'bg-amber-400/10 border-amber-400 text-amber-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Showroom Visit</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setLocationType('Doorstep')}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                      locationType === 'Doorstep'
                        ? 'bg-amber-400/10 border-amber-400 text-amber-300'
                        : 'bg-slate-950 border-slate-800 text-slate-400'
                    }`}
                  >
                    <Car className="w-3.5 h-3.5" />
                    <span>Doorstep Delivery</span>
                  </button>
                </div>
              </div>

              {locationType === 'Doorstep' && (
                <div>
                  <label htmlFor="testdrive-doorstep-address" className="block text-xs font-semibold text-slate-300 mb-1">
                    Your Home or Office Address for Doorstep Test Drive
                  </label>
                  <input
                    id="testdrive-doorstep-address"
                    type="text"
                    value={doorstepAddress}
                    onChange={e => setDoorstepAddress(e.target.value)}
                    placeholder="Building name, street, locality..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                  />
                </div>
              )}

              {/* Message */}
              <div>
                <label htmlFor="testdrive-notes" className="block text-xs font-semibold text-slate-300 mb-1">
                  Special Request or Notes (Optional)
                </label>
                <textarea
                  id="testdrive-notes"
                  rows={2}
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder="e.g. Please bring automatic variant or discuss finance terms..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-xl font-bold text-sm text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 transition shadow-lg shadow-amber-400/20 active:scale-98"
              >
                Book My Test Drive
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
