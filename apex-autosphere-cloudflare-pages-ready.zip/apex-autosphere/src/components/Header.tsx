import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  Phone,
  MessageSquare,
  Car,
  Menu,
  X,
  Clock,
  ShieldCheck,
  ChevronDown,
  Sparkles,
  Settings,
} from 'lucide-react';
import { generateWhatsAppUrl } from '../utils/calculator';

export const Header: React.FC = () => {
  const {
    settings,
    activeTab,
    setActiveTab,
    categories,
    openTestDriveModal,
    isAdminAuthenticated,
  } = useShowroom();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [categoriesDropdownOpen, setCategoriesDropdownOpen] = useState(false);

  const handleNav = (tab: string, catId?: string) => {
    setActiveTab(tab, catId);
    setMobileMenuOpen(false);
    setCategoriesDropdownOpen(false);
  };

  const whatsAppGeneralUrl = generateWhatsAppUrl(
    settings.whatsappNumber,
    `Hello ${settings.name}, I would like to enquire about vehicle availability and current showroom offers.`
  );

  return (
    <header className="sticky top-0 z-50 bg-slate-950/95 backdrop-blur-md border-b border-slate-800/80 transition-all">
      {/* Top Announcement Bar */}
      <div className="bg-gradient-to-r from-amber-600/20 via-slate-900 to-amber-600/20 border-b border-amber-500/20 px-4 py-1.5 text-xs text-slate-300">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-amber-400 font-medium">
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              Festive Offers Active: Up to ₹75,000 Total Benefits
            </span>
            <span className="hidden md:flex items-center gap-1 text-slate-400">
              <Clock className="w-3.5 h-3.5" />
              Mon-Sat: 9:00 AM - 8:30 PM
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline text-slate-400">
              Assistance:{' '}
              <a
                href={`tel:${settings.phone}`}
                className="text-slate-200 hover:text-amber-400 font-semibold transition"
              >
                {settings.phone}
              </a>
            </span>
            <button
              onClick={() => handleNav('admin')}
              className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded text-xs transition border ${
                isAdminAuthenticated
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-slate-200'
              }`}
              title="Manage vehicles, leads, test drives & showroom settings"
            >
              <Settings className="w-3 h-3" />
              <span>Admin Portal</span>
              {isAdminAuthenticated && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Main Nav Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Showroom Name */}
          <button
            onClick={() => handleNav('home')}
            className="flex items-center gap-3 text-left group focus:outline-none"
          >
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20 group-hover:scale-105 transition-transform">
              <Car className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <span className="block text-xl font-extrabold tracking-tight text-white group-hover:text-amber-400 transition-colors">
                {settings.name}
              </span>
              <span className="block text-xs text-slate-400 font-medium tracking-wider uppercase">
                Multi-Vehicle Automotive Hub
              </span>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden xl:flex items-center space-x-1 lg:space-x-2">
            <button
              onClick={() => handleNav('home')}
              className={`px-3 py-2 rounded-lg text-sm font-semibold transition ${
                activeTab === 'home'
                  ? 'text-amber-400 bg-amber-500/10'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Home
            </button>

            {/* Vehicles Dropdown */}
            <div className="relative group">
              <button
                onClick={() => handleNav('vehicles', 'all')}
                className={`flex items-center gap-1 px-3 py-2 rounded-lg text-sm font-semibold transition ${
                  activeTab === 'vehicles'
                    ? 'text-amber-400 bg-amber-500/10'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <span>Vehicles</span>
                <ChevronDown className="w-4 h-4 transition-transform group-hover:rotate-180" />
              </button>

              <div className="absolute top-full left-0 mt-1 w-64 rounded-xl bg-slate-900/95 backdrop-blur-xl border border-slate-800 shadow-2xl p-2 hidden group-hover:block transition-all">
                <button
                  onClick={() => handleNav('vehicles', 'all')}
                  className="w-full text-left px-3 py-2 rounded-lg text-sm font-semibold text-slate-200 hover:bg-slate-800 hover:text-amber-400 transition"
                >
                  All Vehicles
                </button>
                <div className="my-1 border-t border-slate-800" />
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => handleNav('vehicles', cat.id)}
                    className="w-full text-left px-3 py-2 rounded-lg text-sm text-slate-300 hover:bg-slate-800 hover:text-amber-400 transition flex items-center justify-between"
                  >
                    <span>{cat.name}</span>
                    <span className="text-xs text-slate-500">→</span>
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={() => handleNav('vehicles', 'bikes-scooters')}
              className="px-2.5 py-2 rounded-lg text-sm text-slate-300 hover:text-white hover:bg-slate-800/60 transition"
            >
              Bikes
            </button>

            <button
              onClick={() => handleNav('vehicles', 'cars-suvs')}
              className="px-2.5 py-2 rounded-lg text-sm text-slate-300 hover:text-white hover:bg-slate-800/60 transition"
            >
              Cars
            </button>

            <button
              onClick={() => handleNav('vehicles', 'e-rickshaws')}
              className="px-2.5 py-2 rounded-lg text-sm text-slate-300 hover:text-white hover:bg-slate-800/60 transition"
            >
              E-Rickshaw
            </button>

            <button
              onClick={() => handleNav('vehicles', 'electric-vehicles')}
              className="px-2.5 py-2 rounded-lg text-sm text-emerald-400 hover:text-emerald-300 hover:bg-emerald-950/40 transition font-medium"
            >
              ⚡ EV
            </button>

            <button
              onClick={() => handleNav('vehicles', 'commercial-vehicles')}
              className="px-2.5 py-2 rounded-lg text-sm text-slate-300 hover:text-white hover:bg-slate-800/60 transition"
            >
              Commercial
            </button>

            <button
              onClick={() => handleNav('offers')}
              className={`px-2.5 py-2 rounded-lg text-sm font-semibold transition ${
                activeTab === 'offers'
                  ? 'text-amber-400 bg-amber-500/10'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Offers
            </button>

            <button
              onClick={() => handleNav('services')}
              className={`px-2.5 py-2 rounded-lg text-sm font-semibold transition ${
                activeTab === 'services'
                  ? 'text-amber-400 bg-amber-500/10'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Services
            </button>

            <button
              onClick={() => handleNav('about')}
              className={`px-2.5 py-2 rounded-lg text-sm font-semibold transition ${
                activeTab === 'about'
                  ? 'text-amber-400 bg-amber-500/10'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              About Us
            </button>

            <button
              onClick={() => handleNav('contact')}
              className={`px-2.5 py-2 rounded-lg text-sm font-semibold transition ${
                activeTab === 'contact'
                  ? 'text-amber-400 bg-amber-500/10'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
              }`}
            >
              Contact
            </button>
          </nav>

          {/* Right-Side CTAs */}
          <div className="hidden lg:flex items-center gap-2.5">
            <a
              href={`tel:${settings.phone}`}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-slate-200 bg-slate-900 border border-slate-800 hover:border-slate-700 hover:bg-slate-800 transition shadow-sm"
              title="Call Dealership"
            >
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <span>Call Now</span>
            </a>

            <a
              href={whatsAppGeneralUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-emerald-300 bg-emerald-950/60 border border-emerald-800/60 hover:bg-emerald-900/60 transition shadow-sm"
              title="Chat on WhatsApp"
            >
              <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
              <span>WhatsApp</span>
            </a>

            <button
              onClick={() => openTestDriveModal()}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 transition shadow-lg shadow-amber-500/20 active:scale-95"
            >
              <Car className="w-3.5 h-3.5 text-slate-950" />
              <span>Book Test Drive</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 xl:hidden">
            <button
              onClick={() => openTestDriveModal()}
              className="sm:hidden px-2.5 py-1.5 rounded-lg text-xs font-bold text-slate-950 bg-amber-400"
            >
              Test Drive
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-slate-950 border-b border-slate-800 px-4 pt-2 pb-6 space-y-3">
          <div className="grid grid-cols-2 gap-2 pt-2">
            <button
              onClick={() => handleNav('home')}
              className={`p-2.5 rounded-xl text-left text-sm font-semibold transition ${
                activeTab === 'home'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'bg-slate-900 text-slate-200'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => handleNav('vehicles', 'all')}
              className={`p-2.5 rounded-xl text-left text-sm font-semibold transition ${
                activeTab === 'vehicles'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'bg-slate-900 text-slate-200'
              }`}
            >
              All Vehicles
            </button>
          </div>

          <div className="border-t border-slate-800/80 pt-3">
            <span className="text-xs uppercase tracking-wider text-slate-400 font-bold block mb-2">
              Vehicle Categories
            </span>
            <div className="grid grid-cols-2 gap-2">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => handleNav('vehicles', cat.id)}
                  className="p-2 rounded-lg text-left text-xs text-slate-300 bg-slate-900/60 hover:bg-slate-800 hover:text-amber-400 transition"
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>

          <div className="border-t border-slate-800/80 pt-3 grid grid-cols-4 gap-2 text-center text-xs">
            <button
              onClick={() => handleNav('offers')}
              className="py-2 rounded-lg bg-slate-900 text-slate-300 hover:text-amber-400"
            >
              Offers
            </button>
            <button
              onClick={() => handleNav('services')}
              className="py-2 rounded-lg bg-slate-900 text-slate-300 hover:text-amber-400"
            >
              Services
            </button>
            <button
              onClick={() => handleNav('about')}
              className="py-2 rounded-lg bg-slate-900 text-slate-300 hover:text-amber-400"
            >
              About Us
            </button>
            <button
              onClick={() => handleNav('contact')}
              className="py-2 rounded-lg bg-slate-900 text-slate-300 hover:text-amber-400"
            >
              Contact
            </button>
          </div>

          <div className="border-t border-slate-800/80 pt-3 flex flex-col gap-2">
            <button
              onClick={() => {
                openTestDriveModal();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 rounded-xl text-sm font-bold text-slate-950 bg-amber-400 flex items-center justify-center gap-2 shadow"
            >
              <Car className="w-4 h-4" />
              <span>Book a Test Drive</span>
            </button>

            <div className="grid grid-cols-2 gap-2">
              <a
                href={`tel:${settings.phone}`}
                className="py-2 rounded-xl text-xs font-bold text-center text-slate-200 bg-slate-900 border border-slate-800 flex items-center justify-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5 text-amber-400" />
                <span>Call Showroom</span>
              </a>
              <a
                href={whatsAppGeneralUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2 rounded-xl text-xs font-bold text-center text-emerald-300 bg-emerald-950/80 border border-emerald-800 flex items-center justify-center gap-1.5"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                <span>WhatsApp</span>
              </a>
            </div>

            <button
              onClick={() => handleNav('admin')}
              className="w-full py-2 rounded-xl text-xs text-slate-400 bg-slate-900/60 border border-slate-800 hover:text-slate-200 flex items-center justify-center gap-1.5 mt-1"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Admin Portal Dashboard</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
