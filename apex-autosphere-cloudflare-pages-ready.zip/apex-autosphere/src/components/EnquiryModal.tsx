import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  X,
  Tag,
  CheckCircle2,
  Phone,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { generateWhatsAppUrl, generateVehicleWhatsAppMessage } from '../utils/calculator';

export const EnquiryModal: React.FC = () => {
  const {
    isEnquiryModalOpen,
    closeEnquiryModal,
    enquiryVehicle,
    enquiryType,
    createLead,
    settings,
  } = useShowroom();

  const [customerName, setCustomerName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isEnquiryModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!customerName.trim() || !mobile.trim()) {
      setErrorMsg('Please enter your full name and mobile number.');
      return;
    }

    createLead({
      customerName: customerName.trim(),
      mobile: mobile.trim(),
      email: email.trim(),
      vehicleId: enquiryVehicle?.id,
      vehicleName: enquiryVehicle?.name,
      enquiryType,
      message: message.trim() || `Instant enquiry for ${enquiryVehicle ? enquiryVehicle.name : 'showroom vehicle'}.`,
    });

    setIsSubmitted(true);
  };

  const handleResetAndClose = () => {
    setIsSubmitted(false);
    setCustomerName('');
    setMobile('');
    setEmail('');
    setMessage('');
    closeEnquiryModal();
  };

  const whatsAppUrl = generateWhatsAppUrl(
    settings.whatsappNumber,
    enquiryVehicle
      ? generateVehicleWhatsAppMessage(enquiryVehicle.name, enquiryVehicle.price)
      : `Hello ${settings.name}, I am interested in exploring ${enquiryType} options.`
  );

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="enquiry-modal-title"
    >
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-3xl p-6 sm:p-8 shadow-2xl my-6">
        <button
          onClick={handleResetAndClose}
          className="absolute top-4 right-4 w-9 h-9 rounded-full bg-slate-950 text-slate-400 hover:text-white flex items-center justify-center border border-slate-800 transition"
          aria-label="Close modal"
        >
          <X className="w-4 h-4" />
        </button>

        {isSubmitted ? (
          <div className="text-center py-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto mb-4 text-emerald-400">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-black text-white mb-2">
              Thank You!
            </h3>
            <p className="text-sm text-slate-300 max-w-md mx-auto mb-6">
              Your <strong>{enquiryType}</strong> request has been successfully received. Our showroom sales advisor will get in touch with you at <strong>{mobile}</strong>.
            </p>

            <div className="flex flex-col sm:flex-row gap-3">
              <a
                href={whatsAppUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-emerald-300 bg-emerald-950/80 border border-emerald-800 flex items-center justify-center gap-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Chat on WhatsApp</span>
              </a>

              <button
                onClick={handleResetAndClose}
                className="w-full py-3 px-4 rounded-xl text-xs sm:text-sm font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 transition"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Dealership Enquiry</span>
            </div>

            <h3 id="enquiry-modal-title" className="text-2xl font-black text-white tracking-tight">
              {enquiryVehicle
                ? `Enquire: ${enquiryVehicle.name}`
                : `Vehicle ${enquiryType} Enquiry`}
            </h3>

            {enquiryVehicle && (
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 flex items-center justify-between">
                <span>{enquiryVehicle.categoryName} • {enquiryVehicle.fuelType}</span>
                <span className="font-bold text-amber-400">₹{enquiryVehicle.price.toLocaleString('en-IN')}</span>
              </div>
            )}

            {errorMsg && (
              <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs">
                {errorMsg}
              </div>
            )}

            <div>
              <label htmlFor="modal-enquiry-name" className="block text-xs font-semibold text-slate-300 mb-1">
                Full Name *
              </label>
              <input
                id="modal-enquiry-name"
                type="text"
                required
                value={customerName}
                onChange={e => setCustomerName(e.target.value)}
                placeholder="e.g. Vikram Batra"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label htmlFor="modal-enquiry-mobile" className="block text-xs font-semibold text-slate-300 mb-1">
                Mobile Number *
              </label>
              <input
                id="modal-enquiry-mobile"
                type="tel"
                required
                value={mobile}
                onChange={e => setMobile(e.target.value)}
                placeholder="e.g. +91 98765 43210"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label htmlFor="modal-enquiry-email" className="block text-xs font-semibold text-slate-300 mb-1">
                Email Address
              </label>
              <input
                id="modal-enquiry-email"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="e.g. vikram@example.com"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label htmlFor="modal-enquiry-message" className="block text-xs font-semibold text-slate-300 mb-1">
                Query / Special Requirements (Optional)
              </label>
              <textarea
                id="modal-enquiry-message"
                rows={2}
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Share your requirements (e.g. best on-road price, corporate discount, immediate delivery)..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 resize-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3.5 rounded-xl font-bold text-sm text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 transition shadow-lg shadow-amber-400/20 active:scale-98"
            >
              Submit Enquiry
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
