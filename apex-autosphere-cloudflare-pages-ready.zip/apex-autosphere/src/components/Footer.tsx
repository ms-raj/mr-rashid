import React from 'react';
import { useShowroom } from '../context/ShowroomContext';
import {
  Car,
  Phone,
  Mail,
  MapPin,
  Clock,
  ArrowRight,
  ShieldCheck,
  Facebook,
  Instagram,
  Youtube,
  Linkedin,
  Settings,
} from 'lucide-react';

export const Footer: React.FC = () => {
  const { settings, categories, setActiveTab } = useShowroom();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800/80 pt-16 pb-24 sm:pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-slate-800">
          {/* Brand Info Column */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20">
                <Car className="w-5 h-5 text-slate-950" />
              </div>
              <span className="text-xl font-extrabold text-white tracking-tight">
                {settings.name}
              </span>
            </div>

            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              Your trusted multi-vehicle destination. Bringing motorcycles, scooters, luxury passenger cars, electric mobility, e-rickshaws, and commercial vehicles under one premier showroom experience.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 hover:border-amber-400 flex items-center justify-center text-slate-400 hover:text-amber-400 transition"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 hover:border-amber-400 flex items-center justify-center text-slate-400 hover:text-amber-400 transition"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 hover:border-amber-400 flex items-center justify-center text-slate-400 hover:text-amber-400 transition"
                aria-label="YouTube"
              >
                <Youtube className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 hover:border-amber-400 flex items-center justify-center text-slate-400 hover:text-amber-400 transition"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links Column */}
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => setActiveTab('home')}
                  className="hover:text-amber-400 transition"
                >
                  Showroom Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('vehicles', 'all')}
                  className="hover:text-amber-400 transition"
                >
                  All Vehicles
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('offers')}
                  className="hover:text-amber-400 transition"
                >
                  Special Offers
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('services')}
                  className="hover:text-amber-400 transition"
                >
                  Dealership Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('about')}
                  className="hover:text-amber-400 transition"
                >
                  About the Showroom
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('contact')}
                  className="hover:text-amber-400 transition"
                >
                  Contact & Location
                </button>
              </li>
              <li>
                <button
                  onClick={() => setActiveTab('admin')}
                  className="text-amber-400/80 hover:text-amber-300 font-semibold flex items-center gap-1 transition"
                >
                  <Settings className="w-3 h-3" />
                  <span>Admin Portal</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Vehicle Categories Column */}
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Vehicle Categories
            </h3>
            <ul className="space-y-2.5 text-xs">
              {categories.map(cat => (
                <li key={cat.id}>
                  <button
                    onClick={() => setActiveTab('vehicles', cat.id)}
                    className="hover:text-amber-400 transition text-left"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Details Column */}
          <div>
            <h3 className="text-xs font-bold text-white uppercase tracking-wider mb-4">
              Contact & Hours
            </h3>
            <div className="space-y-3 text-xs">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>{settings.address}, {settings.city}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <a href={`tel:${settings.phone}`} className="hover:text-white transition">
                  {settings.phone}
                </a>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <a href={`mailto:${settings.email}`} className="hover:text-white transition">
                  {settings.email}
                </a>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Mon-Sat: 9:00 AM - 8:30 PM<br />Sun: 10:00 AM - 7:00 PM</span>
              </div>
            </div>
          </div>
        </div>

        {/* Disclaimer & Copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>
            © {currentYear} {settings.name}. All Rights Reserved.
          </p>

          <div className="flex flex-wrap items-center gap-4 text-[11px]">
            <span>Privacy Policy</span>
            <span>•</span>
            <span>Terms & Conditions</span>
            <span>•</span>
            <span>Disclaimer: Prices & terms subject to confirmation</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
