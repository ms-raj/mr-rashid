import React, { useState, useId } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import { calculateEmi, formatCurrency } from '../utils/calculator';
import {
  Calculator,
  Percent,
  Calendar,
  Wallet,
  DollarSign,
  ArrowRight,
  Info,
  CheckCircle,
} from 'lucide-react';

export const EmiCalculator: React.FC<{ initialPrice?: number; vehicleName?: string }> = ({
  initialPrice = 1200000,
  vehicleName,
}) => {
  const { openEnquiryModal, vehicles } = useShowroom();

  const [price, setPrice] = useState<number>(initialPrice);
  const [downPayment, setDownPayment] = useState<number>(Math.round(initialPrice * 0.2));
  const [interestRate, setInterestRate] = useState<number>(8.5);
  const [tenureMonths, setTenureMonths] = useState<number>(60);
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>('');

  const vehiclePriceInputId = useId();
  const vehiclePriceSliderId = useId();
  const downPaymentInputId = useId();
  const downPaymentSliderId = useId();
  const interestRateInputId = useId();
  const interestRateSliderId = useId();
  const emiVehicleSelectId = useId();

  // Handle vehicle selection from dropdown to prefill price
  const handleVehicleSelect = (id: string) => {
    setSelectedVehicleId(id);
    if (!id) return;
    const v = vehicles.find(item => item.id === id);
    if (v) {
      setPrice(v.price);
      setDownPayment(Math.round(v.price * 0.2));
    }
  };

  const results = calculateEmi(price, downPayment, interestRate, tenureMonths);

  // Percentages for visualization
  const principalPercent = results.totalPayable > 0
    ? Math.round((results.loanAmount / (results.totalPayable - downPayment || 1)) * 100)
    : 80;
  const interestPercent = 100 - principalPercent;

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
            Instant Loan Estimator
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
            Vehicle EMI Calculator
          </h2>
          <p className="text-base sm:text-lg text-slate-400">
            Customize your vehicle price, down payment, interest rate and tenure to estimate your monthly budget.
          </p>
        </div>

        {/* Calculator Main Box */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl max-w-5xl mx-auto">
          {/* Optional: Pick a Vehicle to Populate */}
          <div className="mb-8 p-4 rounded-2xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Calculator className="w-5 h-5 text-amber-400" />
              <label htmlFor={emiVehicleSelectId} className="text-sm font-semibold text-slate-200">
                Want to calculate for a specific vehicle?
              </label>
            </div>
            <select
              id={emiVehicleSelectId}
              value={selectedVehicleId}
              onChange={e => handleVehicleSelect(e.target.value)}
              className="w-full sm:w-auto bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs font-medium text-white focus:outline-none focus:border-amber-400"
            >
              <option value="">Select a vehicle from showroom...</option>
              {vehicles.map(v => (
                <option key={v.id} value={v.id}>
                  {v.name} ({formatCurrency(v.price)})
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Input Controls (Left Column) */}
            <div className="lg:col-span-7 space-y-6">
              {/* 1. Vehicle Price */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label htmlFor={vehiclePriceInputId} className="text-xs sm:text-sm font-bold text-slate-300">
                    Vehicle Price (Ex-Showroom)
                  </label>
                  <span className="text-sm sm:text-base font-black text-amber-400">
                    {formatCurrency(price)}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <input
                    id={vehiclePriceSliderId}
                    type="range"
                    min="50000"
                    max="5000000"
                    step="10000"
                    value={price}
                    aria-label="Vehicle price slider"
                    onChange={e => {
                      const val = Number(e.target.value);
                      setPrice(val);
                      if (downPayment > val) setDownPayment(Math.round(val * 0.2));
                    }}
                    className="w-full accent-amber-400 cursor-pointer h-2 bg-slate-950 rounded-lg"
                  />
                  <input
                    id={vehiclePriceInputId}
                    type="number"
                    min="0"
                    value={price}
                    aria-label="Vehicle price amount"
                    onChange={e => setPrice(Number(e.target.value))}
                    className="w-28 bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-right text-white font-mono focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* 2. Down Payment */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label htmlFor={downPaymentInputId} className="text-xs sm:text-sm font-bold text-slate-300">
                    Down Payment Upfront
                  </label>
                  <span className="text-sm sm:text-base font-black text-slate-200">
                    {formatCurrency(downPayment)}{' '}
                    <span className="text-xs text-slate-500 font-normal">
                      ({price > 0 ? Math.round((downPayment / price) * 100) : 0}%)
                    </span>
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <input
                    id={downPaymentSliderId}
                    type="range"
                    min="0"
                    max={price}
                    step="5000"
                    value={downPayment}
                    aria-label="Down payment slider"
                    onChange={e => setDownPayment(Number(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer h-2 bg-slate-950 rounded-lg"
                  />
                  <input
                    id={downPaymentInputId}
                    type="number"
                    min="0"
                    max={price}
                    value={downPayment}
                    aria-label="Down payment amount"
                    onChange={e => setDownPayment(Number(e.target.value))}
                    className="w-28 bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-right text-white font-mono focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* 3. Interest Rate */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label htmlFor={interestRateInputId} className="text-xs sm:text-sm font-bold text-slate-300">
                    Annual Interest Rate (% p.a.)
                  </label>
                  <span className="text-sm sm:text-base font-black text-slate-200">
                    {interestRate}% p.a.
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <input
                    id={interestRateSliderId}
                    type="range"
                    min="5"
                    max="18"
                    step="0.25"
                    value={interestRate}
                    aria-label="Annual interest rate slider"
                    onChange={e => setInterestRate(Number(e.target.value))}
                    className="w-full accent-amber-400 cursor-pointer h-2 bg-slate-950 rounded-lg"
                  />
                  <input
                    id={interestRateInputId}
                    type="number"
                    step="0.1"
                    min="1"
                    max="30"
                    value={interestRate}
                    aria-label="Annual interest rate percentage"
                    onChange={e => setInterestRate(Number(e.target.value))}
                    className="w-20 bg-slate-950 border border-slate-800 rounded-xl px-2.5 py-1.5 text-xs text-right text-white font-mono focus:border-amber-400 focus:outline-none"
                  />
                </div>
              </div>

              {/* 4. Loan Tenure (Buttons / Quick Selector) */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs sm:text-sm font-bold text-slate-300">
                    Loan Tenure
                  </span>
                  <span className="text-sm sm:text-base font-black text-slate-200">
                    {tenureMonths} Months ({tenureMonths / 12} {tenureMonths === 12 ? 'Year' : 'Years'})
                  </span>
                </div>
                <div className="grid grid-cols-5 gap-2">
                  {[12, 24, 36, 48, 60, 84].slice(0, 5).map(months => (
                    <button
                      key={months}
                      type="button"
                      onClick={() => setTenureMonths(months)}
                      className={`py-2 rounded-xl text-xs font-bold transition border ${
                        tenureMonths === months
                          ? 'bg-amber-400 text-slate-950 border-amber-400 shadow-md'
                          : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {months}m ({months / 12}y)
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Calculations Card (Right Column) */}
            <div className="lg:col-span-5 bg-slate-950 rounded-2xl border border-slate-800 p-6 flex flex-col justify-between">
              <div>
                <span className="text-xs uppercase font-bold tracking-wider text-slate-400 block mb-1">
                  Estimated Monthly Installment
                </span>
                <div className="text-3xl sm:text-4xl font-black text-emerald-400 mb-6">
                  {formatCurrency(results.monthlyEmi)}
                  <span className="text-xs font-normal text-slate-400 ml-1">/ month*</span>
                </div>

                {/* Calculation Details Grid */}
                <div className="space-y-3 pt-4 border-t border-slate-800/80 mb-6">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Net Loan Amount:</span>
                    <span className="font-bold text-white font-mono">
                      {formatCurrency(results.loanAmount)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Total Interest Payable:</span>
                    <span className="font-bold text-amber-400 font-mono">
                      {formatCurrency(results.totalInterest)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400">Total Amount Payable:</span>
                    <span className="font-bold text-white font-mono">
                      {formatCurrency(results.totalPayable)}
                    </span>
                  </div>
                </div>

                {/* Visual Ratio Bar */}
                <div className="mb-6">
                  <div className="flex justify-between text-[11px] text-slate-400 mb-1">
                    <span>Principal ({principalPercent}%)</span>
                    <span>Interest ({interestPercent}%)</span>
                  </div>
                  <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden flex">
                    <div
                      className="bg-emerald-400 h-full transition-all duration-300"
                      style={{ width: `${principalPercent}%` }}
                    />
                    <div
                      className="bg-amber-400 h-full transition-all duration-300"
                      style={{ width: `${interestPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div>
                <button
                  onClick={() => openEnquiryModal(null, 'Finance')}
                  className="w-full py-3.5 px-4 rounded-xl text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 transition shadow-lg shadow-amber-400/20 flex items-center justify-center gap-2 active:scale-98 mb-3"
                >
                  <span>Apply for Finance</span>
                  <ArrowRight className="w-4 h-4 text-slate-950" />
                </button>

                {/* Mandatory Disclaimer */}
                <p className="text-[11px] text-slate-400 text-center leading-relaxed">
                  Final loan terms are subject to lender approval.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
