import React, { useState } from 'react';
import { useShowroom } from '../context/ShowroomContext';
import { EnquiryType } from '../types';
import {
  Send,
  MessageSquare,
  CheckCircle2,
  Phone,
  Mail,
  MapPin,
  Sparkles,
} from 'lucide-react';
import { generateWhatsAppUrl } from '../utils/calculator';

export const ContactSection: React.FC = () => {
  const { createLead, vehicles, settings } = useShowroom();

  const [fullName, setFullName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [selectedVehicleId, setSelectedVehicleId] = useState('');
  const [enquiryType, setEnquiryType] = useState<EnquiryType>('Vehicle Price');
  const [message, setMessage] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!fullName.trim() || !mobile.trim()) {
      setErrorMsg('Please enter your full name and mobile number.');
      return;
    }

    const vehicle = vehicles.find(v => v.id === selectedVehicleId);

    createLead({
      customerName: fullName.trim(),
      mobile: mobile.trim(),
      email: email.trim(),
      vehicleId: selectedVehicleId || undefined,
      vehicleName: vehicle ? vehicle.name : undefined,
      enquiryType,
      message: message.trim() || `Interested in ${enquiryType} for ${vehicle ? vehicle.name : 'showroom vehicle'}.`,
    });

    setIsSubmitted(true);
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setFullName('');
    setMobile('');
    setEmail('');
    setMessage('');
  };

  return (
    <section className="py-20 bg-slate-950 text-white relative border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
            Direct Dealer Assistance
          </span>
          <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
            Contact & Enquiry Center
          </h2>
          <p className="text-base sm:text-lg text-slate-400">
            Have questions about on-road pricing, waiting periods, financing, or corporate fleet bookings? Send us an enquiry.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
          {/* Left Column: Quick Contact Cards */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl">
              <h3 className="text-lg font-bold text-white mb-4">
                Get Immediate Response
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed mb-6">
                Our sales consultants respond within 15 minutes during showroom operating hours.
              </p>

              <div className="space-y-4">
                <a
                  href={`tel:${settings.phone}`}
                  className="flex items-center gap-3 p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-400/50 transition group"
                >
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-xs text-slate-400">Call Us Directly</span>
                    <span className="block text-sm font-bold text-white group-hover:text-amber-400 transition">
                      {settings.phone}
                    </span>
                  </div>
                </a>

                <a
                  href={generateWhatsAppUrl(
                    settings.whatsappNumber,
                    `Hello ${settings.name}, I would like to get in touch regarding a vehicle enquiry.`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-3 rounded-2xl bg-emerald-950/40 border border-emerald-800/40 hover:border-emerald-500/50 transition group"
                >
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
                    <MessageSquare className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-xs text-slate-400">Instant WhatsApp Chat</span>
                    <span className="block text-sm font-bold text-emerald-400">
                      {settings.whatsappNumber}
                    </span>
                  </div>
                </a>

                <a
                  href={`mailto:${settings.email}`}
                  className="flex items-center gap-3 p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-amber-400/50 transition group"
                >
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-xs text-slate-400">Email Enquiries</span>
                    <span className="block text-sm font-bold text-white group-hover:text-amber-400 transition">
                      {settings.email}
                    </span>
                  </div>
                </a>
              </div>
            </div>
          </div>

          {/* Right Column: Contact / Enquiry Form */}
          <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl">
            {isSubmitted ? (
              <div className="text-center py-10">
                <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center mx-auto mb-4 text-emerald-400">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-black text-white mb-2">
                  Enquiry Successfully Sent!
                </h3>
                <p className="text-sm text-slate-300 max-w-md mx-auto mb-6">
                  Thank you, <strong>{fullName}</strong>. Your enquiry has been routed to our dealership advisory team. We will call you at <strong>{mobile}</strong> shortly.
                </p>
                <button
                  onClick={handleReset}
                  className="px-6 py-2.5 rounded-xl text-xs font-bold bg-amber-400 text-slate-950 hover:bg-amber-300 transition"
                >
                  Send Another Enquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <h3 className="text-xl font-bold text-white mb-2">
                  Send Vehicle Enquiry
                </h3>

                {errorMsg && (
                  <div className="p-3 rounded-xl bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs">
                    {errorMsg}
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="contact-fullname" className="block text-xs font-semibold text-slate-300 mb-1">
                      Full Name *
                    </label>
                    <input
                      id="contact-fullname"
                      type="text"
                      required
                      value={fullName}
                      onChange={e => setFullName(e.target.value)}
                      placeholder="e.g. Sanjay Verma"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>

                  <div>
                    <label htmlFor="contact-mobile" className="block text-xs font-semibold text-slate-300 mb-1">
                      Mobile Number *
                    </label>
                    <input
                      id="contact-mobile"
                      type="tel"
                      required
                      value={mobile}
                      onChange={e => setMobile(e.target.value)}
                      placeholder="e.g. +91 98765 43210"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="contact-email" className="block text-xs font-semibold text-slate-300 mb-1">
                      Email Address
                    </label>
                    <input
                      id="contact-email"
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="e.g. sanjay@example.com"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition"
                    />
                  </div>

                  <div>
                    <label htmlFor="contact-vehicle-select" className="block text-xs font-semibold text-slate-300 mb-1">
                      Vehicle Interested In
                    </label>
                    <select
                      id="contact-vehicle-select"
                      value={selectedVehicleId}
                      onChange={e => setSelectedVehicleId(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
                    >
                      <option value="">General Showroom Query</option>
                      {vehicles.map(v => (
                        <option key={v.id} value={v.id}>
                          {v.name} ({v.categoryName})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="contact-enquiry-type" className="block text-xs font-semibold text-slate-300 mb-1">
                    Enquiry Type
                  </label>
                  <select
                    id="contact-enquiry-type"
                    value={enquiryType}
                    onChange={e => setEnquiryType(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-amber-400 transition"
                  >
                    <option value="Vehicle Price">Vehicle Price / On-Road Quotation</option>
                    <option value="Test Drive">Test Drive Booking</option>
                    <option value="Finance">Vehicle Finance & Loan Options</option>
                    <option value="Exchange">Vehicle Exchange & Trade-In</option>
                    <option value="Offer">Current Festive / Discount Offer</option>
                    <option value="General">General Enquiry</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="contact-message" className="block text-xs font-semibold text-slate-300 mb-1">
                    Your Message / Query
                  </label>
                  <textarea
                    id="contact-message"
                    rows={3}
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    placeholder="Tell us what you would like to know (waiting period, accessories, corporate discounts...)"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-600 focus:outline-none focus:border-amber-400 transition resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl font-bold text-sm text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 transition shadow-lg shadow-amber-400/20 active:scale-98 flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4 text-slate-950" />
                  <span>Send Enquiry</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
