import React, { useState } from 'react';
import { ShowroomProvider, useShowroom } from './context/ShowroomContext';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { CategorySection } from './components/CategorySection';
import { VehicleCard } from './components/VehicleCard';
import { VehicleList } from './components/VehicleList';
import { VehicleDetailModal } from './components/VehicleDetailModal';
import { EmiCalculator } from './components/EmiCalculator';
import { TestDriveModal } from './components/TestDriveModal';
import { ExchangeSection } from './components/ExchangeSection';
import { FinanceSection } from './components/FinanceSection';
import { OffersSection } from './components/OffersSection';
import { ServicesSection } from './components/ServicesSection';
import { WhyChooseUs } from './components/WhyChooseUs';
import { AboutSection } from './components/AboutSection';
import { ReviewsSection } from './components/ReviewsSection';
import { GallerySection } from './components/GallerySection';
import { LocationSection } from './components/LocationSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { MobileStickyBar } from './components/MobileStickyBar';
import { EnquiryModal } from './components/EnquiryModal';
import { AdminPortal } from './components/admin/AdminPortal';
import { ArrowRight, Sparkles, Car } from 'lucide-react';

const ShowroomApp: React.FC = () => {
  const { activeTab, setActiveTab, vehicles } = useShowroom();
  const [heroSearchFilters, setHeroSearchFilters] = useState<any>(null);

  if (activeTab === 'admin') {
    return <AdminPortal />;
  }

  // Top featured vehicles for home page showcase
  const featuredVehicles = vehicles
    .filter(v => v.published && v.featured)
    .slice(0, 6);

  const handleHeroSearch = (filters: any) => {
    setHeroSearchFilters(filters);
    setActiveTab('vehicles');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-400 selection:text-slate-950">
      <Header />

      <main className="flex-1">
        {activeTab === 'home' && (
          <>
            <Hero onSearchSubmit={handleHeroSearch} />

            <CategorySection />

            {/* Featured Vehicles Section */}
            <section className="py-20 bg-slate-950 text-white border-t border-slate-800">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
                  <div>
                    <span className="text-xs font-bold text-amber-400 uppercase tracking-widest bg-amber-500/10 border border-amber-500/20 px-3 py-1 rounded-full inline-block mb-3">
                      Handpicked Dealership Highlights
                    </span>
                    <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-white">
                      Featured Vehicles in Showroom
                    </h2>
                    <p className="text-base text-slate-400 mt-2">
                      Explore top-rated cars, electric mobility units, bikes, and commercial haulers ready for immediate delivery.
                    </p>
                  </div>

                  <button
                    onClick={() => setActiveTab('vehicles', 'all')}
                    className="inline-flex items-center gap-2 text-sm font-bold text-amber-400 hover:text-amber-300 transition group"
                  >
                    <span>View All {vehicles.filter(v => v.published).length} Vehicles</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {featuredVehicles.map(v => (
                    <VehicleCard key={v.id} vehicle={v} />
                  ))}
                </div>

                <div className="text-center mt-12">
                  <button
                    onClick={() => setActiveTab('vehicles', 'all')}
                    className="px-8 py-4 rounded-xl text-sm font-bold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 transition shadow-xl shadow-amber-400/20"
                  >
                    Explore Complete Inventory Catalog
                  </button>
                </div>
              </div>
            </section>

            <OffersSection />

            <EmiCalculator />

            <ExchangeSection />

            <FinanceSection />

            <ServicesSection />

            <WhyChooseUs />

            <AboutSection />

            <ReviewsSection />

            <GallerySection />

            <div id="showroom-location">
              <LocationSection />
            </div>

            <ContactSection />
          </>
        )}

        {activeTab === 'vehicles' && (
          <VehicleList initialFilters={heroSearchFilters || {}} />
        )}

        {activeTab === 'offers' && (
          <div className="pt-4">
            <OffersSection />
            <EmiCalculator />
          </div>
        )}

        {activeTab === 'services' && (
          <div className="pt-4">
            <ServicesSection />
            <FinanceSection />
            <ExchangeSection />
            <WhyChooseUs />
          </div>
        )}

        {activeTab === 'about' && (
          <div className="pt-4">
            <AboutSection />
            <WhyChooseUs />
            <GallerySection />
            <ReviewsSection />
          </div>
        )}

        {activeTab === 'contact' && (
          <div className="pt-4">
            <ContactSection />
            <LocationSection />
          </div>
        )}
      </main>

      <Footer />

      {/* Global Modals & Overlays */}
      <VehicleDetailModal />
      <TestDriveModal />
      <EnquiryModal />
      <FloatingWhatsApp />
      <MobileStickyBar />
    </div>
  );
};

export default function App() {
  return (
    <ShowroomProvider>
      <ShowroomApp />
    </ShowroomProvider>
  );
}
