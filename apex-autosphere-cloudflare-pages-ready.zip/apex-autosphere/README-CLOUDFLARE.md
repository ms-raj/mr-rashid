# Deploy Apex AutoSphere to Cloudflare Pages

This is a React + TypeScript + Vite source project. It is **not** a pre-built static
website, so Cloudflare's dashboard **Upload and deploy** screen cannot accept this
source ZIP directly.

## Option A — Cloudflare Pages dashboard (no Wrangler)

1. Install Node.js 22 LTS on your computer.
2. Extract this ZIP.
3. Open a terminal in the extracted project folder and run:

   ```bash
   npm install
   npm run build
   ```

4. Vite creates a `dist` folder. In Cloudflare, create/open a Pages project and
   choose **Upload assets** / **Direct Upload**. Upload the *contents of `dist`*
   (or a ZIP containing those built files), not this source folder.
5. Your deployed site is the static output in `dist`.

## Option B — Deploy with Wrangler

1. Install Node.js 22 LTS.
2. Extract this ZIP and open a terminal in the project folder.
3. Run:

   ```bash
   npm install
   npx wrangler login
   npm run pages:deploy
   ```

4. If Wrangler asks to create a Pages project, use the name
   `apex-autosphere-motors`. If you already created a Pages project with another
   name, change the `--project-name` value in `package.json` to match it.

## Cloudflare build settings (if connecting a Git repository)

- Framework preset: **Vite**
- Build command: `npm run build`
- Build output directory: `dist`
- Root directory: `/`

## Important

- Do not upload `.tsx`, `.ts`, `src/`, or `node_modules` as static assets. Vite
  compiles the source into browser-ready files in `dist/`.
- The original source package has no `dist/` build output. A build must be run
  before direct asset upload.
- Keep API keys and other secrets out of frontend source files. Configure any
  required secrets as Cloudflare environment variables and access them only
  from server-side code. Never put a private key in a `VITE_*` variable.
